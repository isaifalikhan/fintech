// Enhanced Statement Import - Utility Functions

export interface ImportedTransaction {
  id: string;
  date: string;
  amount: number;
  narration: string;
  type: 'debit' | 'credit';
  category?: string;
  confidence?: number;
  isDuplicate?: boolean;
  duplicateMatchId?: string;
  suggestedCategory?: string;
  rawData: Record<string, any>;
}

export interface ColumnMapping {
  date: string;
  amount: string;
  narration: string;
  balance?: string;
  reference?: string;
  type?: string;
}

export interface ImportSession {
  id: string;
  fileName: string;
  accountId: string;
  accountName: string;
  uploadedAt: string;
  status: 'pending' | 'mapping' | 'classifying' | 'reviewing' | 'completed' | 'failed';
  totalRows: number;
  validRows: number;
  duplicates: number;
  errors: number;
  columnMapping?: ColumnMapping;
  transactions: ImportedTransaction[];
}

// CSV Parser with better handling
export const parseCSVFile = async (file: File): Promise<string[][]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split('\n');
        const data: string[][] = [];
        
        for (const line of lines) {
          if (!line.trim()) continue;
          
          // Handle quoted fields with commas
          const row: string[] = [];
          let currentField = '';
          let inQuotes = false;
          
          for (let i = 0; i < line.length; i++) {
            const char = line[i];
            
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              row.push(currentField.trim());
              currentField = '';
            } else {
              currentField += char;
            }
          }
          
          // Add last field
          if (currentField) {
            row.push(currentField.trim());
          }
          
          if (row.length > 0) {
            data.push(row);
          }
        }
        
        resolve(data);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
};

// Auto-detect column mapping with smart algorithms
export const autoDetectColumnMapping = (headers: string[]): ColumnMapping => {
  const mapping: ColumnMapping = {
    date: '',
    amount: '',
    narration: '',
  };
  
  const lowerHeaders = headers.map(h => h.toLowerCase());
  
  // Date column detection
  const datePatterns = ['date', 'transaction date', 'trans date', 'posting date', 'value date', 'txn date'];
  for (let i = 0; i < lowerHeaders.length; i++) {
    if (datePatterns.some(pattern => lowerHeaders[i].includes(pattern))) {
      mapping.date = headers[i];
      break;
    }
  }
  
  // Amount column detection
  const amountPatterns = ['amount', 'value', 'debit', 'credit', 'withdrawal', 'deposit', 'transaction amount'];
  for (let i = 0; i < lowerHeaders.length; i++) {
    if (amountPatterns.some(pattern => lowerHeaders[i].includes(pattern))) {
      if (!mapping.amount) {
        mapping.amount = headers[i];
      }
    }
  }
  
  // Narration/Description column detection
  const narrationPatterns = ['description', 'narration', 'particulars', 'details', 'memo', 'payee', 'transaction details'];
  for (let i = 0; i < lowerHeaders.length; i++) {
    if (narrationPatterns.some(pattern => lowerHeaders[i].includes(pattern))) {
      mapping.narration = headers[i];
      break;
    }
  }
  
  // Balance column detection (optional)
  const balancePatterns = ['balance', 'closing balance', 'available balance', 'running balance'];
  for (let i = 0; i < lowerHeaders.length; i++) {
    if (balancePatterns.some(pattern => lowerHeaders[i].includes(pattern))) {
      mapping.balance = headers[i];
      break;
    }
  }
  
  // Reference column detection (optional)
  const refPatterns = ['reference', 'ref', 'transaction id', 'txn id', 'ref number'];
  for (let i = 0; i < lowerHeaders.length; i++) {
    if (refPatterns.some(pattern => lowerHeaders[i].includes(pattern))) {
      mapping.reference = headers[i];
      break;
    }
  }
  
  // Type column detection (optional)
  const typePatterns = ['type', 'transaction type', 'dr/cr', 'debit/credit'];
  for (let i = 0; i < lowerHeaders.length; i++) {
    if (typePatterns.some(pattern => lowerHeaders[i].includes(pattern))) {
      mapping.type = headers[i];
      break;
    }
  }
  
  return mapping;
};

// Parse date string with multiple format support
export const parseDate = (dateStr: string): string | null => {
  if (!dateStr) return null;
  
  // Try various date formats
  const formats = [
    /(\d{4})-(\d{2})-(\d{2})/, // YYYY-MM-DD
    /(\d{2})\/(\d{2})\/(\d{4})/, // DD/MM/YYYY
    /(\d{2})-(\d{2})-(\d{4})/, // DD-MM-YYYY
    /(\d{2})\/(\d{2})\/(\d{2})/, // DD/MM/YY
  ];
  
  for (const format of formats) {
    const match = dateStr.match(format);
    if (match) {
      if (format === formats[0]) {
        // Already in YYYY-MM-DD format
        return dateStr;
      } else if (format === formats[1] || format === formats[2]) {
        // DD/MM/YYYY or DD-MM-YYYY
        const [, day, month, year] = match;
        return `${year}-${month}-${day}`;
      } else if (format === formats[3]) {
        // DD/MM/YY
        const [, day, month, year] = match;
        const fullYear = parseInt(year) > 50 ? `19${year}` : `20${year}`;
        return `${fullYear}-${month}-${day}`;
      }
    }
  }
  
  return null;
};

// Parse amount with various formats
export const parseAmount = (amountStr: string): number | null => {
  if (!amountStr) return null;
  
  // Remove currency symbols and extra spaces
  let cleanStr = amountStr
    .replace(/[$€£¥₹]/g, '')
    .replace(/,/g, '')
    .replace(/\s/g, '')
    .trim();
  
  // Handle parentheses for negative numbers
  if (cleanStr.startsWith('(') && cleanStr.endsWith(')')) {
    cleanStr = '-' + cleanStr.slice(1, -1);
  }
  
  const amount = parseFloat(cleanStr);
  return isNaN(amount) ? null : amount;
};

// Detect transaction type (debit/credit)
export const detectTransactionType = (
  amount: number,
  typeColumn?: string,
  amountColumn?: string
): 'debit' | 'credit' => {
  // If type column exists, use it
  if (typeColumn) {
    const lower = typeColumn.toLowerCase();
    if (lower.includes('credit') || lower.includes('cr') || lower.includes('deposit')) {
      return 'credit';
    }
    if (lower.includes('debit') || lower.includes('dr') || lower.includes('withdrawal')) {
      return 'debit';
    }
  }
  
  // If amount is negative, it's typically a debit
  if (amount < 0) {
    return 'debit';
  }
  
  // Check if column name indicates type
  if (amountColumn) {
    const lower = amountColumn.toLowerCase();
    if (lower.includes('credit') || lower.includes('deposit')) {
      return 'credit';
    }
    if (lower.includes('debit') || lower.includes('withdrawal')) {
      return 'debit';
    }
  }
  
  // Default to debit for positive amounts (conservative approach)
  return amount > 0 ? 'credit' : 'debit';
};

// Duplicate detection using fuzzy matching
export const findDuplicates = (
  newTransactions: ImportedTransaction[],
  existingTransactions: any[]
): string[] => {
  const duplicateIds: string[] = [];
  
  for (const newTxn of newTransactions) {
    for (const existingTxn of existingTransactions) {
      // Check if dates are within 2 days
      const dateDiff = Math.abs(
        new Date(newTxn.date).getTime() - new Date(existingTxn.date).getTime()
      );
      const daysDiff = dateDiff / (1000 * 60 * 60 * 24);
      
      // Check if amounts match (within 0.01)
      const amountMatch = Math.abs(Math.abs(newTxn.amount) - Math.abs(existingTxn.amount)) < 0.01;
      
      // Check if narrations are similar (simple substring check)
      const narration1 = newTxn.narration.toLowerCase().slice(0, 50);
      const narration2 = existingTxn.narration.toLowerCase().slice(0, 50);
      const narrationSimilar = narration1.includes(narration2) || narration2.includes(narration1);
      
      if (daysDiff <= 2 && amountMatch && narrationSimilar) {
        duplicateIds.push(newTxn.id);
        newTxn.isDuplicate = true;
        newTxn.duplicateMatchId = existingTxn.id;
        break;
      }
    }
  }
  
  return duplicateIds;
};

// Process raw CSV data into transactions
export const processCSVData = (
  data: string[][],
  mapping: ColumnMapping,
  headers: string[]
): ImportedTransaction[] => {
  const transactions: ImportedTransaction[] = [];
  
  // Find column indices
  const dateIndex = headers.indexOf(mapping.date);
  const amountIndex = headers.indexOf(mapping.amount);
  const narrationIndex = headers.indexOf(mapping.narration);
  const typeIndex = mapping.type ? headers.indexOf(mapping.type) : -1;
  const refIndex = mapping.reference ? headers.indexOf(mapping.reference) : -1;
  
  // Skip header row
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    
    // Skip empty rows
    if (row.length === 0 || row.every(cell => !cell.trim())) {
      continue;
    }
    
    const rawData: Record<string, any> = {};
    headers.forEach((header, idx) => {
      rawData[header] = row[idx] || '';
    });
    
    const dateStr = row[dateIndex];
    const amountStr = row[amountIndex];
    const narration = row[narrationIndex] || '';
    const typeStr = typeIndex >= 0 ? row[typeIndex] : '';
    const reference = refIndex >= 0 ? row[refIndex] : '';
    
    const date = parseDate(dateStr);
    const amount = parseAmount(amountStr);
    
    // Skip invalid rows
    if (!date || amount === null) {
      continue;
    }
    
    const type = detectTransactionType(amount, typeStr, mapping.amount);
    
    transactions.push({
      id: `import-${Date.now()}-${i}`,
      date,
      amount: Math.abs(amount),
      narration: narration.trim(),
      type,
      isDuplicate: false,
      rawData,
    });
  }
  
  return transactions;
};

// Calculate import statistics
export const calculateImportStats = (transactions: ImportedTransaction[]) => {
  return {
    total: transactions.length,
    duplicates: transactions.filter(t => t.isDuplicate).length,
    valid: transactions.filter(t => !t.isDuplicate).length,
    totalAmount: transactions
      .filter(t => !t.isDuplicate)
      .reduce((sum, t) => sum + (t.type === 'credit' ? t.amount : -t.amount), 0),
    credits: transactions.filter(t => t.type === 'credit' && !t.isDuplicate).length,
    debits: transactions.filter(t => t.type === 'debit' && !t.isDuplicate).length,
  };
};
