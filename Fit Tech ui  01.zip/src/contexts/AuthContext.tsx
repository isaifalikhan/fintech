import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Organization, UserRole } from '@/services/types';
import { authService, organizationService } from '@/services';
import type { AuthSession } from '@/services';

// Token storage key
const TOKEN_KEY = 'finance_os_token';

interface AuthContextType {
  user: User | null;
  currentOrganization: Organization | null;
  userRole: UserRole | null;
  organizations: Organization[];
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  switchOrganization: (organizationId: string) => void;
  hasPermission: (permission: 'read' | 'write' | 'admin') => boolean;
  getRedirectPath: () => string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [currentOrganization, setCurrentOrganization] = useState<Organization | null>(null);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true); // true for session restore check

  /**
   * Derive a UserRole from an AuthSession.
   * Platform-level users without org memberships get mapped to org-level equivalents.
   */
  const deriveUserRole = (session: AuthSession): UserRole => {
    if (session.membership) {
      return session.membership.role;
    }
    if (session.user.role === 'platform_admin') return 'owner';
    if (session.user.role === 'platform_manager') return 'admin';
    return 'viewer';
  };

  /**
   * Load the organizations list for a user.
   * Platform admins/managers see ALL orgs; regular users see only their memberships.
   */
  const loadOrganizations = async (sessionUser: User): Promise<Organization[]> => {
    if (sessionUser.role === 'platform_admin' || sessionUser.role === 'platform_manager') {
      const res = await organizationService.getAll({ page: 1, pageSize: 100 });
      return res.success ? res.data.items : [];
    }
    const res = await authService.getUserOrganizations(sessionUser.id);
    return res.success ? res.data : [];
  };

  /**
   * Apply a full AuthSession to component state.
   */
  const applySession = async (session: AuthSession) => {
    setUser(session.user);
    setCurrentOrganization(session.organization);
    setUserRole(deriveUserRole(session));

    const orgs = await loadOrganizations(session.user);
    setOrganizations(orgs);
  };

  // ── Session restore on mount ───────────────────────────────────
  useEffect(() => {
    const restoreSession = async () => {
      const token = localStorage.getItem(TOKEN_KEY);
      if (!token) {
        setIsLoading(false);
        return;
      }
      try {
        const response = await authService.getSession(token);
        if (response.success && response.data) {
          await applySession(response.data);
        } else {
          localStorage.removeItem(TOKEN_KEY);
        }
      } catch {
        localStorage.removeItem(TOKEN_KEY);
      }
      setIsLoading(false);
    };
    restoreSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Public API ─────────────────────────────────────────────────

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const response = await authService.login({ email, password });
      if (response.success) {
        localStorage.setItem(TOKEN_KEY, response.data.token);
        await applySession(response.data);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    // Fire-and-forget the service call (keeps interface synchronous)
    authService.logout();
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    setCurrentOrganization(null);
    setUserRole(null);
    setOrganizations([]);
  };

  const switchOrganization = (organizationId: string) => {
    const org = organizations.find((o) => o.id === organizationId);
    if (org && user) {
      setCurrentOrganization(org);
      // Async role lookup — org switches instantly, role resolves ~50ms later
      authService.getUserRole(user.id, organizationId).then((response) => {
        if (response.success && response.data) {
          setUserRole(response.data.role);
        } else {
          setUserRole('viewer');
        }
      });
    }
  };

  const hasPermission = (permission: 'read' | 'write' | 'admin'): boolean => {
    return authService.hasPermission(userRole, permission);
  };

  const getRedirectPath = (): string => {
    if (!user) return '/';
    return authService.getRedirectPath(user);
  };

  const value: AuthContextType = {
    user,
    currentOrganization,
    userRole,
    organizations,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    switchOrganization,
    hasPermission,
    getRedirectPath,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};