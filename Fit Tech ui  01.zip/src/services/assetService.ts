/**
 * Asset & Depreciation Service
 * ==============================
 * CRUD for fixed assets, depreciation schedule management.
 *
 * MIGRATION: Replace method bodies with API calls.
 */

import { Asset, DepreciationSchedule } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse } from './types';

export const assetService = {
  /** TODO: Replace with GET /api/organizations/:orgId/assets */
  async getAll(organizationId: string): Promise<ServiceResponse<Asset[]>> {
    await simulateDelay();
    const assets = dataStore.assets.filter(a => a.organizationId === organizationId);
    return { success: true, data: assets };
  },

  /** TODO: Replace with GET /api/assets/:id */
  async getById(id: string): Promise<ServiceResponse<Asset | null>> {
    await simulateDelay(80);
    const asset = dataStore.assets.find(a => a.id === id) || null;
    return { success: !!asset, data: asset };
  },

  /** TODO: Replace with POST /api/organizations/:orgId/assets */
  async create(organizationId: string, data: Omit<Asset, 'id' | 'organizationId'>): Promise<ServiceResponse<Asset>> {
    await simulateDelay(200);
    const newAsset: Asset = { ...data, id: generateId('asset'), organizationId };
    dataStore.assets.push(newAsset);
    dataStore.notify('assets');
    return { success: true, data: newAsset, message: 'Asset created' };
  },

  /** TODO: Replace with PATCH /api/assets/:id */
  async update(id: string, updates: Partial<Asset>): Promise<ServiceResponse<Asset>> {
    await simulateDelay(150);
    const idx = dataStore.assets.findIndex(a => a.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Asset not found' };
    dataStore.assets[idx] = { ...dataStore.assets[idx], ...updates };
    dataStore.notify('assets');
    return { success: true, data: dataStore.assets[idx] };
  },

  /**
   * Dispose of an asset
   * TODO: Replace with POST /api/assets/:id/dispose
   */
  async dispose(id: string, disposalDate: string, disposalAmount: number): Promise<ServiceResponse<Asset>> {
    await simulateDelay(200);
    const idx = dataStore.assets.findIndex(a => a.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Asset not found' };

    dataStore.assets[idx] = {
      ...dataStore.assets[idx],
      status: 'disposed',
      disposalDate,
      disposalAmount,
    };
    dataStore.notify('assets');
    return { success: true, data: dataStore.assets[idx], message: 'Asset disposed' };
  },

  // ---- DEPRECIATION ----

  /** TODO: Replace with GET /api/assets/:assetId/depreciation */
  async getDepreciationSchedule(assetId: string): Promise<ServiceResponse<DepreciationSchedule[]>> {
    await simulateDelay();
    const schedules = dataStore.depreciationSchedules.filter(d => d.assetId === assetId);
    return { success: true, data: schedules };
  },

  /**
   * Calculate depreciation for an asset
   * BUSINESS LOGIC - calculation stays, data source changes
   */
  calculateMonthlyDepreciation(asset: Asset): number {
    if (asset.status !== 'active') return 0;

    switch (asset.depreciationMethod) {
      case 'straight_line': {
        const depreciableAmount = asset.purchasePrice - asset.salvageValue;
        return depreciableAmount / (asset.usefulLifeYears * 12);
      }
      case 'declining_balance': {
        const rate = 2 / asset.usefulLifeYears; // Double declining
        return (asset.currentValue * rate) / 12;
      }
      default:
        return 0;
    }
  },

  /**
   * Post depreciation for a period
   * TODO: Replace with POST /api/assets/:id/depreciation/post
   */
  async postDepreciation(assetId: string, period: string): Promise<ServiceResponse<DepreciationSchedule>> {
    await simulateDelay(250);

    const asset = dataStore.assets.find(a => a.id === assetId);
    if (!asset) return { success: false, data: null as any, error: 'Asset not found' };

    const monthlyDepr = this.calculateMonthlyDepreciation(asset);
    const closingValue = Math.max(asset.salvageValue, asset.currentValue - monthlyDepr);
    const actualDepr = asset.currentValue - closingValue;

    const schedule: DepreciationSchedule = {
      id: generateId('depr'),
      assetId,
      organizationId: asset.organizationId,
      period,
      openingValue: asset.currentValue,
      depreciationAmount: Math.round(actualDepr * 100) / 100,
      closingValue: Math.round(closingValue * 100) / 100,
      status: 'posted',
    };

    dataStore.depreciationSchedules.push(schedule);

    // Update asset values
    const assetIdx = dataStore.assets.findIndex(a => a.id === assetId);
    dataStore.assets[assetIdx].currentValue = closingValue;
    dataStore.assets[assetIdx].accumulatedDepreciation += actualDepr;

    if (closingValue <= asset.salvageValue) {
      dataStore.assets[assetIdx].status = 'fully_depreciated';
    }

    dataStore.notify('assets');
    dataStore.notify('depreciationSchedules');
    return { success: true, data: schedule, message: 'Depreciation posted' };
  },

  /**
   * Get asset summary stats
   * TODO: Replace with GET /api/organizations/:orgId/assets/summary
   */
  async getSummary(organizationId: string): Promise<ServiceResponse<{
    totalAssets: number;
    totalCurrentValue: number;
    totalPurchaseValue: number;
    totalDepreciation: number;
    byCategory: { category: string; count: number; value: number }[];
  }>> {
    await simulateDelay();

    const assets = dataStore.assets.filter(a => a.organizationId === organizationId);
    const byCategory = new Map<string, { count: number; value: number }>();

    for (const asset of assets) {
      const existing = byCategory.get(asset.category) || { count: 0, value: 0 };
      byCategory.set(asset.category, {
        count: existing.count + 1,
        value: existing.value + asset.currentValue,
      });
    }

    return {
      success: true,
      data: {
        totalAssets: assets.length,
        totalCurrentValue: assets.reduce((s, a) => s + a.currentValue, 0),
        totalPurchaseValue: assets.reduce((s, a) => s + a.purchasePrice, 0),
        totalDepreciation: assets.reduce((s, a) => s + a.accumulatedDepreciation, 0),
        byCategory: Array.from(byCategory.entries()).map(([category, data]) => ({
          category,
          ...data,
        })),
      },
    };
  },
};