/**
 * Category Service
 * =================
 * CRUD for transaction categories with pattern management.
 *
 * MIGRATION: Replace method bodies with API calls.
 */

import { Category } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse } from './types';

export const categoryService = {
  /** TODO: Replace with GET /api/organizations/:orgId/categories */
  async getAll(organizationId: string): Promise<ServiceResponse<Category[]>> {
    await simulateDelay();
    const categories = dataStore.categories.filter(c => c.organizationId === organizationId);
    return { success: true, data: categories };
  },

  /** TODO: Replace with GET /api/categories/:id */
  async getById(id: string): Promise<ServiceResponse<Category | null>> {
    await simulateDelay(80);
    const cat = dataStore.categories.find(c => c.id === id) || null;
    return { success: !!cat, data: cat };
  },

  /** TODO: Replace with POST /api/organizations/:orgId/categories */
  async create(organizationId: string, data: Omit<Category, 'id' | 'organizationId'>): Promise<ServiceResponse<Category>> {
    await simulateDelay(200);
    const newCat: Category = { ...data, id: generateId('cat'), organizationId };
    dataStore.categories.push(newCat);
    dataStore.notify('categories');
    return { success: true, data: newCat, message: 'Category created' };
  },

  /** TODO: Replace with PATCH /api/categories/:id */
  async update(id: string, updates: Partial<Category>): Promise<ServiceResponse<Category>> {
    await simulateDelay(150);
    const idx = dataStore.categories.findIndex(c => c.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Category not found' };
    dataStore.categories[idx] = { ...dataStore.categories[idx], ...updates };
    dataStore.notify('categories');
    return { success: true, data: dataStore.categories[idx] };
  },

  /** TODO: Replace with DELETE /api/categories/:id */
  async delete(id: string): Promise<ServiceResponse<null>> {
    await simulateDelay(150);
    const idx = dataStore.categories.findIndex(c => c.id === id);
    if (idx === -1) return { success: false, data: null, error: 'Category not found' };
    dataStore.categories.splice(idx, 1);
    // Uncategorize transactions that used this category
    dataStore.transactions.forEach(t => {
      if (t.categoryId === id) {
        t.categoryId = undefined;
        t.status = 'pending';
      }
    });
    dataStore.notify('categories');
    dataStore.notify('transactions');
    return { success: true, data: null, message: 'Category deleted' };
  },

  /**
   * Add a learned pattern to a category
   * TODO: Replace with POST /api/categories/:id/patterns
   */
  async addPattern(categoryId: string, pattern: string): Promise<ServiceResponse<Category>> {
    await simulateDelay(100);
    const idx = dataStore.categories.findIndex(c => c.id === categoryId);
    if (idx === -1) return { success: false, data: null as any, error: 'Category not found' };

    if (!dataStore.categories[idx].patterns.includes(pattern)) {
      dataStore.categories[idx].patterns.push(pattern);
    }
    dataStore.notify('categories');
    return { success: true, data: dataStore.categories[idx] };
  },

  /**
   * Remove a pattern from a category
   * TODO: Replace with DELETE /api/categories/:id/patterns/:pattern
   */
  async removePattern(categoryId: string, pattern: string): Promise<ServiceResponse<Category>> {
    await simulateDelay(100);
    const idx = dataStore.categories.findIndex(c => c.id === categoryId);
    if (idx === -1) return { success: false, data: null as any, error: 'Category not found' };

    dataStore.categories[idx].patterns = dataStore.categories[idx].patterns.filter(p => p !== pattern);
    dataStore.notify('categories');
    return { success: true, data: dataStore.categories[idx] };
  },

  /**
   * Get category usage stats
   * TODO: Replace with GET /api/organizations/:orgId/categories/stats
   */
  async getUsageStats(organizationId: string): Promise<ServiceResponse<{
    categoryId: string;
    categoryName: string;
    transactionCount: number;
    totalAmount: number;
    type: string;
  }[]>> {
    await simulateDelay();
    const categories = dataStore.categories.filter(c => c.organizationId === organizationId);
    const orgTxns = dataStore.transactions.filter(t => t.organizationId === organizationId);

    const stats = categories.map(cat => {
      const catTxns = orgTxns.filter(t => t.categoryId === cat.id);
      return {
        categoryId: cat.id,
        categoryName: cat.name,
        transactionCount: catTxns.length,
        totalAmount: catTxns.reduce((s, t) => s + Math.abs(t.amount), 0),
        type: cat.type,
      };
    });

    return { success: true, data: stats };
  },
};