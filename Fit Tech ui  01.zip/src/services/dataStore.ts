/**
 * In-Memory Data Store
 * =====================
 * This is the single source of truth for all application data.
 * It initializes from mockDatabase and supports full CRUD operations.
 *
 * MIGRATION GUIDE: When moving to a real backend, DELETE this file entirely.
 * Each service will replace its dataStore reads/writes with API fetch() calls.
 */

import {
  Organization, User, OrganizationMember, Account, BankAccount,
  Transaction, Category, Department, Project, Asset, DepreciationSchedule,
  InventoryItem, InventoryTransaction, OverheadAllocation,
  RecurringTransaction, Budget, CashFlowForecast, ActiveSession, Notification,
} from '@/services/types';

import {
  mockOrganizations, mockUsers, mockOrganizationMembers, mockAccounts,
  mockBankAccounts, mockTransactions, mockCategories, mockDepartments,
  mockProjects, mockAssets, mockDepreciationSchedule, mockInventoryItems,
  mockInventoryTransactions, mockOverheadAllocations, mockRecurringTransactions,
  mockBudgets, mockCashFlowForecasts, mockActiveSessions, mockNotifications,
} from '@/data/mockDatabase';

// Deep clone helper to avoid mutation of original mock data
function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

// ID generator
let idCounter = Date.now();
export function generateId(prefix: string): string {
  return `${prefix}-${++idCounter}`;
}

// Simulated network delay (configurable)
const SIMULATE_DELAY = true;
const BASE_DELAY_MS = 150; // Low enough to feel snappy, high enough to test loading states

export async function simulateDelay(ms?: number): Promise<void> {
  if (!SIMULATE_DELAY) return;
  const delay = ms ?? BASE_DELAY_MS + Math.random() * 100;
  return new Promise(resolve => setTimeout(resolve, delay));
}

/**
 * The in-memory store. Every service reads/writes here.
 * When you add a real DB, each service's methods will call fetch() instead.
 */
class DataStore {
  organizations: Organization[];
  users: User[];
  organizationMembers: OrganizationMember[];
  accounts: Account[];
  bankAccounts: BankAccount[];
  transactions: Transaction[];
  categories: Category[];
  departments: Department[];
  projects: Project[];
  assets: Asset[];
  depreciationSchedules: DepreciationSchedule[];
  inventoryItems: InventoryItem[];
  inventoryTransactions: InventoryTransaction[];
  overheadAllocations: OverheadAllocation[];
  recurringTransactions: RecurringTransaction[];
  budgets: Budget[];
  cashFlowForecasts: CashFlowForecast[];
  activeSessions: ActiveSession[];
  notifications: Notification[];

  // Event listeners for reactive updates
  private listeners: Map<string, Set<() => void>> = new Map();

  constructor() {
    // Initialize with deep clones of mock data
    this.organizations = deepClone(mockOrganizations);
    this.users = deepClone(mockUsers);
    this.organizationMembers = deepClone(mockOrganizationMembers);
    this.accounts = deepClone(mockAccounts);
    this.bankAccounts = deepClone(mockBankAccounts);
    this.transactions = deepClone(mockTransactions);
    this.categories = deepClone(mockCategories);
    this.departments = deepClone(mockDepartments);
    this.projects = deepClone(mockProjects);
    this.assets = deepClone(mockAssets);
    this.depreciationSchedules = deepClone(mockDepreciationSchedule);
    this.inventoryItems = deepClone(mockInventoryItems);
    this.inventoryTransactions = deepClone(mockInventoryTransactions);
    this.overheadAllocations = deepClone(mockOverheadAllocations);
    this.recurringTransactions = deepClone(mockRecurringTransactions);
    this.budgets = deepClone(mockBudgets);
    this.cashFlowForecasts = deepClone(mockCashFlowForecasts);
    this.activeSessions = deepClone(mockActiveSessions);
    this.notifications = deepClone(mockNotifications);
  }

  /** Subscribe to changes on a specific collection */
  subscribe(collection: string, listener: () => void): () => void {
    if (!this.listeners.has(collection)) {
      this.listeners.set(collection, new Set());
    }
    this.listeners.get(collection)!.add(listener);
    return () => {
      this.listeners.get(collection)?.delete(listener);
    };
  }

  /** Notify listeners that a collection changed */
  notify(collection: string): void {
    this.listeners.get(collection)?.forEach(fn => fn());
  }

  /** Reset store to initial mock data (useful for testing) */
  reset(): void {
    this.organizations = deepClone(mockOrganizations);
    this.users = deepClone(mockUsers);
    this.organizationMembers = deepClone(mockOrganizationMembers);
    this.accounts = deepClone(mockAccounts);
    this.bankAccounts = deepClone(mockBankAccounts);
    this.transactions = deepClone(mockTransactions);
    this.categories = deepClone(mockCategories);
    this.departments = deepClone(mockDepartments);
    this.projects = deepClone(mockProjects);
    this.assets = deepClone(mockAssets);
    this.depreciationSchedules = deepClone(mockDepreciationSchedule);
    this.inventoryItems = deepClone(mockInventoryItems);
    this.inventoryTransactions = deepClone(mockInventoryTransactions);
    this.overheadAllocations = deepClone(mockOverheadAllocations);
    this.recurringTransactions = deepClone(mockRecurringTransactions);
    this.budgets = deepClone(mockBudgets);
    this.cashFlowForecasts = deepClone(mockCashFlowForecasts);
    this.activeSessions = deepClone(mockActiveSessions);
    this.notifications = deepClone(mockNotifications);
  }
}

// Singleton instance
export const dataStore = new DataStore();