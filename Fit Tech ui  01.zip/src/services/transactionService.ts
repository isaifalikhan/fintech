/**
 * Transaction Service
 * ====================
 * Full CRUD + filtering, pagination, bulk ops for transactions.
 *
 * MIGRATION: Replace each method body with the corresponding API call.
 * Function signatures and return types stay identical.
 */

import { Transaction } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse, PaginatedResult, TransactionFilters, BulkOperationResult } from './types';

export const transactionService = {
  /**
   * Get transactions with filtering and pagination
   * TODO: Replace with GET /api/organizations/:orgId/transactions?...query
   */
  async getAll(
    organizationId: string,
    filters: TransactionFilters = {}
  ): Promise<ServiceResponse<PaginatedResult<Transaction>>> {
    await simulateDelay();

    const {
      page = 1, pageSize = 20, sortBy = 'date', sortOrder = 'desc',
      search, categoryId, departmentId, projectId, bankAccountId,
      status, type, minAmount, maxAmount, dateFrom, dateTo, tags,
    } = filters;

    // Filter
    let items = dataStore.transactions.filter(t => t.organizationId === organizationId);

    if (search) {
      const q = search.toLowerCase();
      items = items.filter(t =>
        t.description.toLowerCase().includes(q) ||
        t.narration.toLowerCase().includes(q) ||
        t.tags.some(tag => tag.toLowerCase().includes(q))
      );
    }
    if (categoryId) items = items.filter(t => t.categoryId === categoryId);
    if (departmentId) items = items.filter(t => t.departmentId === departmentId);
    if (projectId) items = items.filter(t => t.projectId === projectId);
    if (bankAccountId) items = items.filter(t => t.bankAccountId === bankAccountId);
    if (status) items = items.filter(t => t.status === status);
    if (type) items = items.filter(t => t.type === type);
    if (minAmount !== undefined) items = items.filter(t => Math.abs(t.amount) >= minAmount);
    if (maxAmount !== undefined) items = items.filter(t => Math.abs(t.amount) <= maxAmount);
    if (dateFrom) items = items.filter(t => t.date >= dateFrom);
    if (dateTo) items = items.filter(t => t.date <= dateTo);
    if (tags && tags.length > 0) {
      items = items.filter(t => tags.some(tag => t.tags.includes(tag)));
    }

    // Sort
    items.sort((a, b) => {
      const aVal = (a as any)[sortBy];
      const bVal = (b as any)[sortBy];
      if (typeof aVal === 'string') {
        return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
    });

    // Paginate
    const total = items.length;
    const totalPages = Math.ceil(total / pageSize);
    const start = (page - 1) * pageSize;
    const paginatedItems = items.slice(start, start + pageSize);

    return {
      success: true,
      data: {
        items: paginatedItems,
        total,
        page,
        pageSize,
        totalPages,
        hasMore: page < totalPages,
      },
    };
  },

  /**
   * Get single transaction by ID
   * TODO: Replace with GET /api/transactions/:id
   */
  async getById(id: string): Promise<ServiceResponse<Transaction | null>> {
    await simulateDelay(100);
    const txn = dataStore.transactions.find(t => t.id === id) || null;
    return { success: !!txn, data: txn, error: txn ? undefined : 'Transaction not found' };
  },

  /**
   * Create a new transaction
   * TODO: Replace with POST /api/organizations/:orgId/transactions
   */
  async create(
    organizationId: string,
    data: Omit<Transaction, 'id' | 'organizationId' | 'createdAt'>
  ): Promise<ServiceResponse<Transaction>> {
    await simulateDelay(200);

    const newTxn: Transaction = {
      ...data,
      id: generateId('txn'),
      organizationId,
      createdAt: new Date().toISOString(),
    };

    dataStore.transactions.unshift(newTxn);
    dataStore.notify('transactions');

    return { success: true, data: newTxn, message: 'Transaction created' };
  },

  /**
   * Update an existing transaction
   * TODO: Replace with PATCH /api/transactions/:id
   */
  async update(id: string, updates: Partial<Transaction>): Promise<ServiceResponse<Transaction>> {
    await simulateDelay(150);

    const idx = dataStore.transactions.findIndex(t => t.id === id);
    if (idx === -1) {
      return { success: false, data: null as any, error: 'Transaction not found' };
    }

    dataStore.transactions[idx] = { ...dataStore.transactions[idx], ...updates };
    dataStore.notify('transactions');

    return { success: true, data: dataStore.transactions[idx], message: 'Transaction updated' };
  },

  /**
   * Delete a transaction
   * TODO: Replace with DELETE /api/transactions/:id
   */
  async delete(id: string): Promise<ServiceResponse<null>> {
    await simulateDelay(150);

    const idx = dataStore.transactions.findIndex(t => t.id === id);
    if (idx === -1) {
      return { success: false, data: null, error: 'Transaction not found' };
    }

    dataStore.transactions.splice(idx, 1);
    dataStore.notify('transactions');

    return { success: true, data: null, message: 'Transaction deleted' };
  },

  /**
   * Bulk categorize transactions
   * TODO: Replace with POST /api/transactions/bulk-categorize
   */
  async bulkCategorize(
    ids: string[],
    categoryId: string,
    classifiedBy: string = 'user'
  ): Promise<ServiceResponse<BulkOperationResult>> {
    await simulateDelay(300);

    let succeeded = 0;
    const errors: { id: string; error: string }[] = [];

    for (const id of ids) {
      const idx = dataStore.transactions.findIndex(t => t.id === id);
      if (idx === -1) {
        errors.push({ id, error: 'Not found' });
      } else {
        dataStore.transactions[idx] = {
          ...dataStore.transactions[idx],
          categoryId,
          status: 'classified',
          classifiedAt: new Date().toISOString(),
          classifiedBy,
        };
        succeeded++;
      }
    }

    dataStore.notify('transactions');

    return {
      success: true,
      data: { succeeded, failed: errors.length, errors },
      message: `${succeeded} transactions categorized`,
    };
  },

  /**
   * Bulk delete transactions
   * TODO: Replace with POST /api/transactions/bulk-delete
   */
  async bulkDelete(ids: string[]): Promise<ServiceResponse<BulkOperationResult>> {
    await simulateDelay(250);

    let succeeded = 0;
    const errors: { id: string; error: string }[] = [];

    for (const id of ids) {
      const idx = dataStore.transactions.findIndex(t => t.id === id);
      if (idx === -1) {
        errors.push({ id, error: 'Not found' });
      } else {
        dataStore.transactions.splice(idx, 1);
        succeeded++;
      }
    }

    dataStore.notify('transactions');

    return {
      success: true,
      data: { succeeded, failed: errors.length, errors },
      message: `${succeeded} transactions deleted`,
    };
  },

  /**
   * Get transaction statistics for an organization
   * TODO: Replace with GET /api/organizations/:orgId/transactions/stats
   */
  async getStats(organizationId: string, dateFrom?: string, dateTo?: string): Promise<ServiceResponse<{
    totalIncome: number;
    totalExpenses: number;
    netAmount: number;
    transactionCount: number;
    pendingCount: number;
    classifiedCount: number;
    avgConfidence: number;
  }>> {
    await simulateDelay();

    let txns = dataStore.transactions.filter(t => t.organizationId === organizationId);
    if (dateFrom) txns = txns.filter(t => t.date >= dateFrom);
    if (dateTo) txns = txns.filter(t => t.date <= dateTo);

    const totalIncome = txns.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0);
    const totalExpenses = txns.filter(t => t.type === 'debit').reduce((s, t) => s + Math.abs(t.amount), 0);
    const pendingCount = txns.filter(t => t.status === 'pending').length;
    const classifiedCount = txns.filter(t => t.status !== 'pending').length;
    const confidences = txns.filter(t => t.confidence !== undefined).map(t => t.confidence!);
    const avgConfidence = confidences.length > 0
      ? confidences.reduce((s, c) => s + c, 0) / confidences.length
      : 0;

    return {
      success: true,
      data: {
        totalIncome,
        totalExpenses,
        netAmount: totalIncome - totalExpenses,
        transactionCount: txns.length,
        pendingCount,
        classifiedCount,
        avgConfidence: Math.round(avgConfidence),
      },
    };
  },
};