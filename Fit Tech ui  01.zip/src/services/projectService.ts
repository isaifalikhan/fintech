/**
 * Project Service
 * ================
 * CRUD for client projects with profitability calculations.
 *
 * MIGRATION: Replace method bodies with API calls.
 */

import { Project } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse, ProjectProfitability } from './types';

export const projectService = {
  /** TODO: Replace with GET /api/organizations/:orgId/projects */
  async getAll(organizationId: string): Promise<ServiceResponse<Project[]>> {
    await simulateDelay();
    const projects = dataStore.projects.filter(p => p.organizationId === organizationId);
    return { success: true, data: projects };
  },

  /** TODO: Replace with GET /api/projects/:id */
  async getById(id: string): Promise<ServiceResponse<Project | null>> {
    await simulateDelay(80);
    const project = dataStore.projects.find(p => p.id === id) || null;
    return { success: !!project, data: project };
  },

  /** TODO: Replace with POST /api/organizations/:orgId/projects */
  async create(organizationId: string, data: Omit<Project, 'id' | 'organizationId'>): Promise<ServiceResponse<Project>> {
    await simulateDelay(200);
    const newProject: Project = { ...data, id: generateId('proj'), organizationId };
    dataStore.projects.push(newProject);
    dataStore.notify('projects');
    return { success: true, data: newProject, message: 'Project created' };
  },

  /** TODO: Replace with PATCH /api/projects/:id */
  async update(id: string, updates: Partial<Project>): Promise<ServiceResponse<Project>> {
    await simulateDelay(150);
    const idx = dataStore.projects.findIndex(p => p.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Project not found' };
    dataStore.projects[idx] = { ...dataStore.projects[idx], ...updates };
    dataStore.notify('projects');
    return { success: true, data: dataStore.projects[idx] };
  },

  /** TODO: Replace with DELETE /api/projects/:id */
  async delete(id: string): Promise<ServiceResponse<null>> {
    await simulateDelay(150);
    const idx = dataStore.projects.findIndex(p => p.id === id);
    if (idx === -1) return { success: false, data: null, error: 'Project not found' };
    dataStore.projects.splice(idx, 1);
    dataStore.notify('projects');
    return { success: true, data: null, message: 'Project deleted' };
  },

  /**
   * Calculate profitability for all projects in an org
   * This is BUSINESS LOGIC that stays the same after migration.
   * Only the data source changes (dataStore → API response).
   * TODO: Data fetching becomes API call, calculation stays here
   */
  async getProfitability(organizationId: string): Promise<ServiceResponse<ProjectProfitability[]>> {
    await simulateDelay();

    const projects = dataStore.projects.filter(p => p.organizationId === organizationId);
    const profitability: ProjectProfitability[] = projects.map(proj => {
      const profit = proj.quotedAmount - proj.actualCost;
      const profitMargin = proj.quotedAmount > 0 ? (profit / proj.quotedAmount) * 100 : 0;
      const budgetVariance = proj.quotedAmount > 0
        ? ((proj.actualCost - proj.quotedAmount) / proj.quotedAmount) * 100
        : 0;

      return {
        projectId: proj.id,
        projectName: proj.name,
        clientName: proj.clientName,
        quotedAmount: proj.quotedAmount,
        actualCost: proj.actualCost,
        profit,
        profitMargin: Math.round(profitMargin * 10) / 10,
        status: proj.status,
        budgetVariance: Math.round(budgetVariance * 10) / 10,
      };
    });

    return { success: true, data: profitability };
  },

  /**
   * Get transactions linked to a project
   * TODO: Replace with GET /api/projects/:id/transactions
   */
  async getProjectTransactions(projectId: string): Promise<ServiceResponse<any[]>> {
    await simulateDelay();
    const txns = dataStore.transactions.filter(t => t.projectId === projectId);
    return { success: true, data: txns };
  },
};