/**
 * Employee Service
 * =================
 * Covers employee-facing features: expenses, payslips, timesheets, directory, announcements.
 * MIGRATION: Replace method bodies with API calls.
 */

import { simulateDelay, generateId } from './dataStore';
import type { ServiceResponse } from './types';

// ── Types ──────────────────────────────────────────────────────

export interface Expense {
  id: string;
  organizationId: string;
  userId: string;
  date: string;
  description: string;
  amount: number;
  currency: string;
  category: string;
  status: 'draft' | 'submitted' | 'approved' | 'rejected' | 'reimbursed';
  receiptUrl?: string;
  notes?: string;
  projectId?: string;
  submittedAt?: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface Payslip {
  id: string;
  organizationId: string;
  userId: string;
  period: string;
  issueDate: string;
  gross: number;
  deductions: { name: string; amount: number }[];
  net: number;
  currency: string;
  status: 'draft' | 'issued' | 'paid';
}

export interface TimesheetEntry {
  id: string;
  organizationId: string;
  userId: string;
  date: string;
  projectId: string;
  projectName: string;
  hours: number;
  description: string;
  billable: boolean;
  status: 'draft' | 'submitted' | 'approved';
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  avatar?: string;
  joinedAt: string;
  status: 'active' | 'away' | 'offline';
}

export interface Announcement {
  id: string;
  organizationId: string;
  title: string;
  content: string;
  author: string;
  category: 'general' | 'hr' | 'finance' | 'project' | 'celebration';
  createdAt: string;
  isPinned: boolean;
}

// ── Seed Data ─────────────────────────────────────────────────

const seedExpenses: Expense[] = [
  { id: 'exp-001', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-03-01', description: 'Client Dinner - Project Alpha', amount: 156.00, currency: 'USD', category: 'Meals & Entertainment', status: 'submitted', submittedAt: '2026-03-02T10:00:00Z' },
  { id: 'exp-002', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-02-28', description: 'Software License - Figma', amount: 299.00, currency: 'USD', category: 'Software', status: 'approved', submittedAt: '2026-03-01T09:00:00Z', reviewedBy: 'user-002', reviewedAt: '2026-03-01T14:00:00Z' },
  { id: 'exp-003', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-02-25', description: 'Uber to Client Office', amount: 42.50, currency: 'USD', category: 'Travel', status: 'reimbursed', submittedAt: '2026-02-26T08:00:00Z', reviewedBy: 'user-002', reviewedAt: '2026-02-26T16:00:00Z' },
  { id: 'exp-004', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-02-20', description: 'Office Supplies', amount: 87.25, currency: 'USD', category: 'Office Supplies', status: 'approved' },
  { id: 'exp-005', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-03-03', description: 'Conference Registration', amount: 450.00, currency: 'USD', category: 'Training', status: 'draft' },
];

const seedPayslips: Payslip[] = [
  { id: 'pay-001', organizationId: 'org-001', userId: 'user-emp-001', period: 'February 2026', issueDate: '2026-02-28', gross: 8500, deductions: [{ name: 'Income Tax', amount: 1275 }, { name: 'Social Security', amount: 340 }, { name: 'Health Insurance', amount: 85 }], net: 6800, currency: 'USD', status: 'paid' },
  { id: 'pay-002', organizationId: 'org-001', userId: 'user-emp-001', period: 'January 2026', issueDate: '2026-01-31', gross: 8500, deductions: [{ name: 'Income Tax', amount: 1275 }, { name: 'Social Security', amount: 340 }, { name: 'Health Insurance', amount: 85 }], net: 6800, currency: 'USD', status: 'paid' },
  { id: 'pay-003', organizationId: 'org-001', userId: 'user-emp-001', period: 'December 2025', issueDate: '2025-12-31', gross: 8500, deductions: [{ name: 'Income Tax', amount: 1275 }, { name: 'Social Security', amount: 340 }, { name: 'Health Insurance', amount: 85 }], net: 6800, currency: 'USD', status: 'paid' },
  { id: 'pay-004', organizationId: 'org-001', userId: 'user-emp-001', period: 'November 2025', issueDate: '2025-11-30', gross: 8500, deductions: [{ name: 'Income Tax', amount: 1275 }, { name: 'Social Security', amount: 340 }, { name: 'Health Insurance', amount: 85 }], net: 6800, currency: 'USD', status: 'paid' },
];

const seedTimesheets: TimesheetEntry[] = [
  { id: 'ts-001', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-03-04', projectId: 'proj-001', projectName: 'Brand Refresh - TechCorp', hours: 6, description: 'UI implementation sprint', billable: true, status: 'draft' },
  { id: 'ts-002', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-03-04', projectId: 'proj-002', projectName: 'Mobile App - StartupXYZ', hours: 2, description: 'Code review & bug fixes', billable: true, status: 'draft' },
  { id: 'ts-003', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-03-03', projectId: 'proj-001', projectName: 'Brand Refresh - TechCorp', hours: 8, description: 'Frontend architecture', billable: true, status: 'submitted' },
  { id: 'ts-004', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-03-02', projectId: 'proj-003', projectName: 'Internal Tools', hours: 4, description: 'Dashboard improvements', billable: false, status: 'approved' },
  { id: 'ts-005', organizationId: 'org-001', userId: 'user-emp-001', date: '2026-03-02', projectId: 'proj-001', projectName: 'Brand Refresh - TechCorp', hours: 4, description: 'Design system tokens', billable: true, status: 'approved' },
];

const seedTeam: TeamMember[] = [
  { id: 'user-001', name: 'John Doe', email: 'john.doe@agency.com', role: 'Owner', department: 'Management', avatar: 'https://i.pravatar.cc/150?u=johndoe', joinedAt: '2024-01-15', status: 'active' },
  { id: 'user-002', name: 'Sarah Smith', email: 'sarah.smith@agency.com', role: 'Admin', department: 'Finance', avatar: 'https://i.pravatar.cc/150?u=sarahsmith', joinedAt: '2024-01-20', status: 'active' },
  { id: 'user-003', name: 'Mike Johnson', email: 'mike.johnson@agency.com', role: 'Viewer', department: 'Design', avatar: 'https://i.pravatar.cc/150?u=mikejohnson', joinedAt: '2024-02-01', status: 'away' },
  { id: 'user-emp-001', name: 'Alex Chen', email: 'alex.chen@agency.com', role: 'Developer', department: 'Development', avatar: 'https://i.pravatar.cc/150?u=alexchen', joinedAt: '2024-03-01', status: 'active' },
  { id: 'user-emp-002', name: 'Lisa Kumar', email: 'lisa.kumar@agency.com', role: 'Designer', department: 'Design', avatar: 'https://i.pravatar.cc/150?u=lisakumar', joinedAt: '2024-03-10', status: 'active' },
  { id: 'user-emp-003', name: 'David Park', email: 'david.park@agency.com', role: 'Developer', department: 'Development', avatar: 'https://i.pravatar.cc/150?u=davidpark', joinedAt: '2024-03-15', status: 'offline' },
  { id: 'user-emp-004', name: 'Rachel Green', email: 'rachel.green@agency.com', role: 'Marketing', department: 'Marketing', avatar: 'https://i.pravatar.cc/150?u=rachelgreen', joinedAt: '2024-04-01', status: 'active' },
];

const seedAnnouncements: Announcement[] = [
  { id: 'ann-001', organizationId: 'org-001', title: 'Q1 2026 All-Hands Meeting', content: 'Join us this Friday for our quarterly all-hands meeting. We will be reviewing Q1 performance, upcoming projects, and team celebrations.', author: 'John Doe', category: 'general', createdAt: '2026-03-03T10:00:00Z', isPinned: true },
  { id: 'ann-002', organizationId: 'org-001', title: 'New Health Insurance Plan', content: 'We are upgrading our health insurance plan effective April 1. Details will be shared via email.', author: 'Sarah Smith', category: 'hr', createdAt: '2026-03-01T14:00:00Z', isPinned: false },
  { id: 'ann-003', organizationId: 'org-001', title: 'Project Alpha Milestone Achieved!', content: 'Congratulations to the Development team for completing the API integration ahead of schedule!', author: 'John Doe', category: 'celebration', createdAt: '2026-02-28T16:00:00Z', isPinned: false },
  { id: 'ann-004', organizationId: 'org-001', title: 'Updated Expense Policy', content: 'Please review the updated expense reimbursement policy. Maximum meal allowance has been increased to $75 per person.', author: 'Sarah Smith', category: 'finance', createdAt: '2026-02-25T09:00:00Z', isPinned: false },
];

// ── Service Methods ───────────────────────────────────────────

export const employeeService = {
  // ── Expenses ──
  async getExpenses(orgId: string, userId: string): Promise<ServiceResponse<Expense[]>> {
    await simulateDelay();
    return { success: true, data: seedExpenses.filter(e => e.organizationId === orgId && e.userId === userId) };
  },

  async createExpense(orgId: string, userId: string, data: Omit<Expense, 'id' | 'organizationId' | 'userId'>): Promise<ServiceResponse<Expense>> {
    await simulateDelay(200);
    const exp: Expense = { ...data, id: generateId('exp'), organizationId: orgId, userId };
    seedExpenses.unshift(exp);
    return { success: true, data: exp, message: 'Expense created' };
  },

  async submitExpense(id: string): Promise<ServiceResponse<Expense>> {
    await simulateDelay(150);
    const exp = seedExpenses.find(e => e.id === id);
    if (!exp) return { success: false, data: null as any, error: 'Not found' };
    exp.status = 'submitted';
    exp.submittedAt = new Date().toISOString();
    return { success: true, data: exp };
  },

  // ── Payslips ──
  async getPayslips(orgId: string, userId: string): Promise<ServiceResponse<Payslip[]>> {
    await simulateDelay();
    return { success: true, data: seedPayslips.filter(p => p.organizationId === orgId && p.userId === userId) };
  },

  // ── Timesheets ──
  async getTimesheets(orgId: string, userId: string): Promise<ServiceResponse<TimesheetEntry[]>> {
    await simulateDelay();
    return { success: true, data: seedTimesheets.filter(t => t.organizationId === orgId && t.userId === userId) };
  },

  async createTimesheetEntry(orgId: string, userId: string, data: Omit<TimesheetEntry, 'id' | 'organizationId' | 'userId'>): Promise<ServiceResponse<TimesheetEntry>> {
    await simulateDelay(200);
    const entry: TimesheetEntry = { ...data, id: generateId('ts'), organizationId: orgId, userId };
    seedTimesheets.unshift(entry);
    return { success: true, data: entry };
  },

  async submitTimesheet(ids: string[]): Promise<ServiceResponse<null>> {
    await simulateDelay(200);
    ids.forEach(id => {
      const entry = seedTimesheets.find(t => t.id === id);
      if (entry) entry.status = 'submitted';
    });
    return { success: true, data: null, message: 'Timesheet submitted' };
  },

  // ── Team Directory ──
  async getTeamDirectory(orgId: string): Promise<ServiceResponse<TeamMember[]>> {
    await simulateDelay();
    return { success: true, data: seedTeam };
  },

  // ── Announcements ──
  async getAnnouncements(orgId: string): Promise<ServiceResponse<Announcement[]>> {
    await simulateDelay();
    return { success: true, data: seedAnnouncements.filter(a => a.organizationId === orgId) };
  },

  // ── Dashboard Summary ──
  async getDashboardSummary(orgId: string, userId: string): Promise<ServiceResponse<{
    hoursThisWeek: number;
    hoursTarget: number;
    pendingExpenses: number;
    pendingExpenseAmount: number;
    activeProjects: number;
    salary: { gross: number; net: number; currency: string };
    weeklyHours: { day: string; hours: number }[];
  }>> {
    await simulateDelay();
    const expenses = seedExpenses.filter(e => e.userId === userId && (e.status === 'draft' || e.status === 'submitted'));
    const timesheets = seedTimesheets.filter(t => t.userId === userId);
    const thisWeekHours = timesheets.reduce((sum, t) => sum + t.hours, 0);
    const latestPay = seedPayslips.find(p => p.userId === userId);

    return {
      success: true,
      data: {
        hoursThisWeek: thisWeekHours,
        hoursTarget: 40,
        pendingExpenses: expenses.length,
        pendingExpenseAmount: expenses.reduce((sum, e) => sum + e.amount, 0),
        activeProjects: new Set(timesheets.map(t => t.projectId)).size,
        salary: latestPay ? { gross: latestPay.gross, net: latestPay.net, currency: latestPay.currency } : { gross: 0, net: 0, currency: 'USD' },
        weeklyHours: [
          { day: 'Mon', hours: 8.5 }, { day: 'Tue', hours: 7.5 }, { day: 'Wed', hours: 8 },
          { day: 'Thu', hours: 6 }, { day: 'Fri', hours: 4.5 }, { day: 'Sat', hours: 0 }, { day: 'Sun', hours: 0 },
        ],
      },
    };
  },
};
