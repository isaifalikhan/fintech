/**
 * Financial Reporting Service
 * ============================
 * Generates P&L, balance sheet, cash flow, and agency-specific reports.
 * Heavy business logic here - this is the 80% that stays after migration.
 *
 * MIGRATION: Only the data-fetching lines change (dataStore → API calls).
 * All calculations, aggregations, and report formatting stay identical.
 */

import { dataStore, simulateDelay } from './dataStore';
import type { ServiceResponse, ProfitLossReport, DashboardSummary, CashFlowSummary } from './types';

export const reportService = {
  /**
   * Generate Dashboard Summary KPIs
   * TODO: Data fetching becomes API call, aggregation logic stays
   */
  async getDashboardSummary(organizationId: string): Promise<ServiceResponse<DashboardSummary>> {
    await simulateDelay(200);

    const txns = dataStore.transactions.filter(t => t.organizationId === organizationId);
    const accounts = dataStore.accounts.filter(a => a.organizationId === organizationId);

    const totalRevenue = txns.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0);
    const totalExpenses = txns.filter(t => t.type === 'debit').reduce((s, t) => s + Math.abs(t.amount), 0);
    const netProfit = totalRevenue - totalExpenses;
    const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

    const cashAccounts = accounts.filter(a => a.subtype === 'bank_account' || a.subtype === 'current_asset');
    const cashOnHand = cashAccounts.reduce((s, a) => s + a.balance, 0);

    const arAccount = accounts.find(a => a.name.toLowerCase().includes('receivable'));
    const apAccount = accounts.find(a => a.name.toLowerCase().includes('payable'));

    const pendingTransactions = txns.filter(t => t.status === 'pending').length;

    return {
      success: true,
      data: {
        totalRevenue,
        totalExpenses,
        netProfit,
        profitMargin: Math.round(profitMargin * 10) / 10,
        cashOnHand,
        accountsReceivable: arAccount?.balance || 0,
        accountsPayable: apAccount?.balance || 0,
        pendingTransactions,
        revenueChange: 12.7, // Would calculate from historical data
        expenseChange: 8.3,
        profitChange: 16.7,
      },
    };
  },

  /**
   * Generate Profit & Loss Report
   * TODO: Data source changes, calculation stays
   */
  async getProfitLoss(organizationId: string, dateFrom?: string, dateTo?: string): Promise<ServiceResponse<ProfitLossReport>> {
    await simulateDelay(300);

    const accounts = dataStore.accounts.filter(a => a.organizationId === organizationId && a.isActive);
    const incomeAccounts = accounts.filter(a => a.type === 'income');
    const cogsAccounts = accounts.filter(a => a.subtype === 'cogs');
    const opexAccounts = accounts.filter(a => a.type === 'expense' && a.subtype !== 'cogs');

    const totalRevenue = incomeAccounts.reduce((s, a) => s + a.balance, 0);
    const totalCOGS = cogsAccounts.reduce((s, a) => s + a.balance, 0);
    const grossProfit = totalRevenue - totalCOGS;
    const totalOpex = opexAccounts.reduce((s, a) => s + a.balance, 0);
    const operatingIncome = grossProfit - totalOpex;

    return {
      success: true,
      data: {
        period: `${dateFrom || 'FY Start'} to ${dateTo || 'Current'}`,
        revenue: incomeAccounts.map(a => ({ accountId: a.id, name: a.name, amount: a.balance })),
        cogs: cogsAccounts.map(a => ({ accountId: a.id, name: a.name, amount: a.balance })),
        operatingExpenses: opexAccounts.map(a => ({ accountId: a.id, name: a.name, amount: a.balance })),
        totalRevenue,
        totalCOGS,
        grossProfit,
        totalOperatingExpenses: totalOpex,
        operatingIncome,
        netIncome: operatingIncome, // Simplified: no non-operating items
      },
    };
  },

  /**
   * Generate Cash Flow Report
   * TODO: Data source changes, aggregation stays
   */
  async getCashFlow(organizationId: string, months: number = 6): Promise<ServiceResponse<CashFlowSummary[]>> {
    await simulateDelay(200);

    const txns = dataStore.transactions.filter(t => t.organizationId === organizationId);

    // Group by month
    const monthMap = new Map<string, { inflow: number; outflow: number }>();
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    for (const txn of txns) {
      const date = new Date(txn.date);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      const existing = monthMap.get(key) || { inflow: 0, outflow: 0 };

      if (txn.type === 'credit') {
        existing.inflow += txn.amount;
      } else {
        existing.outflow += Math.abs(txn.amount);
      }
      monthMap.set(key, existing);
    }

    // Convert to array, sorted, last N months
    const result: CashFlowSummary[] = Array.from(monthMap.entries())
      .sort((a, b) => a[0].localeCompare(b[0]))
      .slice(-months)
      .map(([key, data]) => {
        const monthIdx = parseInt(key.split('-')[1]) - 1;
        return {
          month: monthNames[monthIdx] || key,
          inflow: Math.round(data.inflow),
          outflow: Math.round(data.outflow),
          net: Math.round(data.inflow - data.outflow),
        };
      });

    // If not enough real data, supplement with the mock data from existing api.ts
    if (result.length < months) {
      const supplemental: CashFlowSummary[] = [
        { month: 'Jan', inflow: 125000, outflow: 89000, net: 36000 },
        { month: 'Feb', inflow: 142000, outflow: 95000, net: 47000 },
        { month: 'Mar', inflow: 138000, outflow: 92000, net: 46000 },
        { month: 'Apr', inflow: 165000, outflow: 102000, net: 63000 },
        { month: 'May', inflow: 158000, outflow: 98000, net: 60000 },
        { month: 'Jun', inflow: 178000, outflow: 108000, net: 70000 },
      ];
      return { success: true, data: supplemental.slice(0, months) };
    }

    return { success: true, data: result };
  },

  /**
   * Expense breakdown by category
   * BUSINESS LOGIC
   */
  async getExpenseBreakdown(organizationId: string): Promise<ServiceResponse<{
    categoryId: string;
    categoryName: string;
    amount: number;
    percentage: number;
    color: string;
    transactionCount: number;
  }[]>> {
    await simulateDelay();

    const txns = dataStore.transactions.filter(
      t => t.organizationId === organizationId && t.type === 'debit'
    );
    const categories = dataStore.categories.filter(c => c.organizationId === organizationId);

    const totalExpenses = txns.reduce((s, t) => s + Math.abs(t.amount), 0);

    const breakdown = categories
      .filter(c => c.type === 'expense')
      .map(cat => {
        const catTxns = txns.filter(t => t.categoryId === cat.id);
        const amount = catTxns.reduce((s, t) => s + Math.abs(t.amount), 0);
        return {
          categoryId: cat.id,
          categoryName: cat.name,
          amount,
          percentage: totalExpenses > 0 ? Math.round((amount / totalExpenses) * 1000) / 10 : 0,
          color: cat.color,
          transactionCount: catTxns.length,
        };
      })
      .sort((a, b) => b.amount - a.amount);

    return { success: true, data: breakdown };
  },

  /**
   * Revenue breakdown by client/project
   * BUSINESS LOGIC
   */
  async getRevenueBreakdown(organizationId: string): Promise<ServiceResponse<{
    projectId: string;
    projectName: string;
    clientName: string;
    revenue: number;
    percentage: number;
  }[]>> {
    await simulateDelay();

    const txns = dataStore.transactions.filter(
      t => t.organizationId === organizationId && t.type === 'credit'
    );
    const projects = dataStore.projects.filter(p => p.organizationId === organizationId);
    const totalRevenue = txns.reduce((s, t) => s + t.amount, 0);

    const breakdown = projects.map(proj => {
      const projTxns = txns.filter(t => t.projectId === proj.id);
      const revenue = projTxns.reduce((s, t) => s + t.amount, 0);
      return {
        projectId: proj.id,
        projectName: proj.name,
        clientName: proj.clientName,
        revenue,
        percentage: totalRevenue > 0 ? Math.round((revenue / totalRevenue) * 1000) / 10 : 0,
      };
    }).sort((a, b) => b.revenue - a.revenue);

    return { success: true, data: breakdown };
  },

  /**
   * Cash flow forecast
   * BUSINESS LOGIC - predictive analytics
   */
  async getForecast(organizationId: string, monthsAhead: number = 3): Promise<ServiceResponse<{
    forecasts: { date: string; income: number; expenses: number; net: number; confidence: number }[];
    currentCash: number;
    projectedCash: number;
    burnRate: number;
    runway: number; // months
  }>> {
    await simulateDelay(300);

    const cashForecasts = dataStore.cashFlowForecasts.filter(f => f.organizationId === organizationId);
    const accounts = dataStore.accounts.filter(a => a.organizationId === organizationId);
    const cashAccounts = accounts.filter(a => a.subtype === 'bank_account' || a.subtype === 'current_asset');
    const currentCash = cashAccounts.reduce((s, a) => s + a.balance, 0);

    const txns = dataStore.transactions.filter(t => t.organizationId === organizationId);
    const monthlyExpenses = txns.filter(t => t.type === 'debit').reduce((s, t) => s + Math.abs(t.amount), 0) / 6; // avg over ~6 months
    const burnRate = Math.round(monthlyExpenses);
    const runway = burnRate > 0 ? Math.round((currentCash / burnRate) * 10) / 10 : Infinity;

    const forecasts = cashForecasts.slice(0, monthsAhead).map(f => ({
      date: f.date,
      income: f.forecastedIncome,
      expenses: f.forecastedExpenses,
      net: f.netCashFlow,
      confidence: f.confidence,
    }));

    const projectedCash = currentCash + forecasts.reduce((s, f) => s + f.net, 0);

    return {
      success: true,
      data: {
        forecasts,
        currentCash,
        projectedCash: Math.round(projectedCash),
        burnRate,
        runway,
      },
    };
  },
};
