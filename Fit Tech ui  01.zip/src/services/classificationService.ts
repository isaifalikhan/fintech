/**
 * AI Classification Service
 * ==========================
 * Wraps the classification engine with service-layer patterns.
 * The classification logic itself is in /src/lib/classificationEngine.ts
 *
 * MIGRATION: The classification engine logic stays (it's pure functions).
 * Only the data-fetching (categories, transactions) switches to API calls.
 * For a real AI backend, you might also call an ML endpoint here.
 */

import { Transaction, Category } from '@/services/types';
import { dataStore, simulateDelay } from './dataStore';
import {
  classifyTransaction,
  learnFromFeedback,
  batchClassify,
  ClassificationResult,
  ClassificationRule,
} from '@/lib/classificationEngine';
import type { ServiceResponse, ImportResult } from './types';

// In-memory classification rules (would be stored in DB after migration)
let classificationRules: ClassificationRule[] = [];

export const classificationService = {
  /**
   * Classify a single transaction
   * TODO: Could optionally call an ML API endpoint for enhanced classification
   */
  async classify(
    organizationId: string,
    narration: string,
    amount: number,
    type: 'debit' | 'credit'
  ): Promise<ServiceResponse<ClassificationResult>> {
    await simulateDelay(200);

    const categories = dataStore.categories.filter(c => c.organizationId === organizationId);
    const previousTxns = dataStore.transactions.filter(t => t.organizationId === organizationId);

    const result = classifyTransaction(narration, amount, type, categories, previousTxns, classificationRules);
    return { success: true, data: result };
  },

  /**
   * Batch classify multiple transactions (e.g., after import)
   * TODO: Could batch-call ML API endpoint
   */
  async batchClassify(
    organizationId: string,
    transactions: Array<{ narration: string; amount: number; type: 'debit' | 'credit' }>
  ): Promise<ServiceResponse<Map<number, ClassificationResult>>> {
    await simulateDelay(500);

    const categories = dataStore.categories.filter(c => c.organizationId === organizationId);
    const previousTxns = dataStore.transactions.filter(t => t.organizationId === organizationId);

    const results = batchClassify(transactions, categories, previousTxns, classificationRules);
    return { success: true, data: results };
  },

  /**
   * Learn from user feedback (when user corrects a classification)
   * This updates category patterns so future classifications improve.
   * TODO: Would also POST feedback to ML API for model retraining
   */
  async learnFromCorrection(
    organizationId: string,
    transactionId: string,
    correctCategoryId: string
  ): Promise<ServiceResponse<{ updated: boolean }>> {
    await simulateDelay(150);

    const txn = dataStore.transactions.find(t => t.id === transactionId);
    if (!txn) return { success: false, data: { updated: false }, error: 'Transaction not found' };

    const categories = dataStore.categories.filter(c => c.organizationId === organizationId);
    const previousCategoryId = txn.categoryId || null;

    // Update category patterns
    const updatedCategories = learnFromFeedback(
      txn.narration,
      correctCategoryId,
      previousCategoryId,
      categories
    );

    // Apply updated categories back to store
    for (const updated of updatedCategories) {
      const idx = dataStore.categories.findIndex(c => c.id === updated.id);
      if (idx !== -1) {
        dataStore.categories[idx] = updated;
      }
    }

    // Update the transaction itself
    const txnIdx = dataStore.transactions.findIndex(t => t.id === transactionId);
    if (txnIdx !== -1) {
      dataStore.transactions[txnIdx] = {
        ...dataStore.transactions[txnIdx],
        categoryId: correctCategoryId,
        status: 'classified',
        classifiedAt: new Date().toISOString(),
        classifiedBy: 'user',
        confidence: 100, // User-confirmed
      };
    }

    // Add a classification rule for this pattern
    const rule: ClassificationRule = {
      id: `rule-${Date.now()}`,
      pattern: txn.narration,
      categoryId: correctCategoryId,
      confidence: 95,
      matchCount: 1,
      createdFrom: 'user',
      lastUsed: new Date().toISOString(),
    };
    classificationRules.push(rule);

    dataStore.notify('categories');
    dataStore.notify('transactions');

    return { success: true, data: { updated: true }, message: 'Classification updated and learned' };
  },

  /**
   * Get classification rules
   * TODO: Replace with GET /api/organizations/:orgId/classification-rules
   */
  async getRules(): Promise<ServiceResponse<ClassificationRule[]>> {
    await simulateDelay();
    return { success: true, data: [...classificationRules] };
  },

  /**
   * Add manual classification rule
   * TODO: Replace with POST /api/organizations/:orgId/classification-rules
   */
  async addRule(rule: Omit<ClassificationRule, 'id'>): Promise<ServiceResponse<ClassificationRule>> {
    await simulateDelay(150);
    const newRule: ClassificationRule = { ...rule, id: `rule-${Date.now()}` };
    classificationRules.push(newRule);
    return { success: true, data: newRule, message: 'Rule added' };
  },

  /**
   * Delete a classification rule
   * TODO: Replace with DELETE /api/classification-rules/:id
   */
  async deleteRule(ruleId: string): Promise<ServiceResponse<null>> {
    await simulateDelay(100);
    classificationRules = classificationRules.filter(r => r.id !== ruleId);
    return { success: true, data: null, message: 'Rule deleted' };
  },

  /**
   * Get classification stats
   * BUSINESS LOGIC
   */
  async getStats(organizationId: string): Promise<ServiceResponse<{
    totalTransactions: number;
    autoClassified: number;
    userClassified: number;
    pending: number;
    avgConfidence: number;
    accuracyRate: number;
    rulesCount: number;
  }>> {
    await simulateDelay();

    const txns = dataStore.transactions.filter(t => t.organizationId === organizationId);
    const autoClassified = txns.filter(t => t.classifiedBy === 'auto').length;
    const userClassified = txns.filter(t => t.classifiedBy && t.classifiedBy !== 'auto').length;
    const pending = txns.filter(t => t.status === 'pending').length;
    const confidences = txns.filter(t => t.confidence !== undefined).map(t => t.confidence!);
    const avgConfidence = confidences.length > 0
      ? Math.round(confidences.reduce((s, c) => s + c, 0) / confidences.length)
      : 0;

    return {
      success: true,
      data: {
        totalTransactions: txns.length,
        autoClassified,
        userClassified,
        pending,
        avgConfidence,
        accuracyRate: 94.2, // Would be calculated from user corrections
        rulesCount: classificationRules.length,
      },
    };
  },
};