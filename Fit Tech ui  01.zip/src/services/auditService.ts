/**
 * Audit Log Service
 * ==================
 * Read-only access to audit trail entries.
 * MIGRATION: Replace method bodies with API calls.
 */

import { simulateDelay } from './dataStore';
import type { ServiceResponse } from './types';

export interface AuditLogEntry {
  id: string;
  organizationId: string;
  userId: string;
  userName: string;
  action: string;
  resource: string;
  resourceId: string;
  details: string;
  ipAddress: string;
  timestamp: string;
  severity: 'info' | 'warning' | 'critical';
}

// Seed data — will be replaced by real DB
const seedLogs: AuditLogEntry[] = [
  { id: 'audit-001', organizationId: 'org-001', userId: 'user-001', userName: 'John Doe', action: 'CREATE', resource: 'Transaction', resourceId: 'txn-050', details: 'Created transaction "Office Supplies" for $234.00', ipAddress: '192.168.1.100', timestamp: '2026-03-04T14:30:00Z', severity: 'info' },
  { id: 'audit-002', organizationId: 'org-001', userId: 'user-002', userName: 'Sarah Smith', action: 'UPDATE', resource: 'Budget', resourceId: 'budget-001', details: 'Updated Marketing Budget Q1 amount from $25,000 to $30,000', ipAddress: '192.168.1.105', timestamp: '2026-03-04T13:15:00Z', severity: 'info' },
  { id: 'audit-003', organizationId: 'org-001', userId: 'user-001', userName: 'John Doe', action: 'BULK_CLASSIFY', resource: 'Transaction', resourceId: 'batch-012', details: 'Auto-classified 45 transactions via AI engine', ipAddress: '192.168.1.100', timestamp: '2026-03-04T11:00:00Z', severity: 'info' },
  { id: 'audit-004', organizationId: 'org-001', userId: 'user-004', userName: 'Emma Wilson', action: 'DELETE', resource: 'Account', resourceId: 'acc-temp', details: 'Deleted temporary holding account', ipAddress: '192.168.1.108', timestamp: '2026-03-03T16:45:00Z', severity: 'warning' },
  { id: 'audit-005', organizationId: 'org-001', userId: 'user-001', userName: 'John Doe', action: 'IMPORT', resource: 'Statement', resourceId: 'import-007', details: 'Imported 128 transactions from Chase Business CSV', ipAddress: '192.168.1.100', timestamp: '2026-03-03T10:20:00Z', severity: 'info' },
  { id: 'audit-006', organizationId: 'org-001', userId: 'user-002', userName: 'Sarah Smith', action: 'INVITE', resource: 'Member', resourceId: 'user-emp-005', details: 'Invited new team member rachel.green@agency.com', ipAddress: '192.168.1.105', timestamp: '2026-03-02T14:00:00Z', severity: 'info' },
  { id: 'audit-007', organizationId: 'org-001', userId: 'user-001', userName: 'John Doe', action: 'ROLE_CHANGE', resource: 'Member', resourceId: 'user-003', details: 'Changed Mike Johnson role from viewer to admin', ipAddress: '192.168.1.100', timestamp: '2026-03-02T09:30:00Z', severity: 'critical' },
  { id: 'audit-008', organizationId: 'org-001', userId: 'user-001', userName: 'John Doe', action: 'SETTINGS', resource: 'Organization', resourceId: 'org-001', details: 'Updated fiscal year start to April 1', ipAddress: '192.168.1.100', timestamp: '2026-03-01T11:00:00Z', severity: 'warning' },
];

export const auditService = {
  async getAll(organizationId: string, filters?: { severity?: string; action?: string; search?: string }): Promise<ServiceResponse<AuditLogEntry[]>> {
    await simulateDelay();
    let logs = seedLogs.filter(l => l.organizationId === organizationId);
    if (filters?.severity) logs = logs.filter(l => l.severity === filters.severity);
    if (filters?.action) logs = logs.filter(l => l.action === filters.action);
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      logs = logs.filter(l => l.details.toLowerCase().includes(q) || l.userName.toLowerCase().includes(q));
    }
    return { success: true, data: logs };
  },
};
