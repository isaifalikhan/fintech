/**
 * Recurring Transaction Service
 * ==============================
 * CRUD for recurring/scheduled transactions.
 * MIGRATION: Replace method bodies with API calls.
 */

import { RecurringTransaction } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse } from './types';

export const recurringTransactionService = {
  async getAll(organizationId: string): Promise<ServiceResponse<RecurringTransaction[]>> {
    await simulateDelay();
    return { success: true, data: dataStore.recurringTransactions.filter(r => r.organizationId === organizationId) };
  },

  async create(organizationId: string, data: Omit<RecurringTransaction, 'id' | 'organizationId'>): Promise<ServiceResponse<RecurringTransaction>> {
    await simulateDelay(200);
    const item: RecurringTransaction = { ...data, id: generateId('rec'), organizationId };
    dataStore.recurringTransactions.push(item);
    dataStore.notify('recurringTransactions');
    return { success: true, data: item, message: 'Recurring transaction created' };
  },

  async update(id: string, updates: Partial<RecurringTransaction>): Promise<ServiceResponse<RecurringTransaction>> {
    await simulateDelay(150);
    const idx = dataStore.recurringTransactions.findIndex(r => r.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Not found' };
    dataStore.recurringTransactions[idx] = { ...dataStore.recurringTransactions[idx], ...updates };
    dataStore.notify('recurringTransactions');
    return { success: true, data: dataStore.recurringTransactions[idx] };
  },

  async delete(id: string): Promise<ServiceResponse<null>> {
    await simulateDelay(150);
    const idx = dataStore.recurringTransactions.findIndex(r => r.id === id);
    if (idx === -1) return { success: false, data: null, error: 'Not found' };
    dataStore.recurringTransactions.splice(idx, 1);
    dataStore.notify('recurringTransactions');
    return { success: true, data: null, message: 'Deleted' };
  },

  async toggle(id: string): Promise<ServiceResponse<RecurringTransaction>> {
    await simulateDelay(100);
    const idx = dataStore.recurringTransactions.findIndex(r => r.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Not found' };
    dataStore.recurringTransactions[idx].isActive = !dataStore.recurringTransactions[idx].isActive;
    dataStore.notify('recurringTransactions');
    return { success: true, data: dataStore.recurringTransactions[idx] };
  },
};
