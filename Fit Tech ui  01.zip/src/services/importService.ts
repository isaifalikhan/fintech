/**
 * Statement Import Service
 * =========================
 * Handles multi-currency bank statement imports with format detection,
 * column mapping, duplicate detection, and auto-classification.
 *
 * MIGRATION: File upload becomes real multipart/form-data POST.
 * Processing logic (parsing, dedup, classification) could stay client-side
 * or move to a server-side worker. The interface stays the same.
 */

import { Transaction } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import { classificationService } from './classificationService';
import type { ServiceResponse, ImportPreview, ImportResult, ImportHistoryRecord } from './types';

export const importService = {
  /**
   * Parse and preview a bank statement file
   * TODO: Replace with POST /api/imports/preview (multipart file upload)
   */
  async previewFile(file: File): Promise<ServiceResponse<ImportPreview>> {
    await simulateDelay(800);

    // In mock mode, generate a realistic preview
    const fileName = file.name;
    const isCSV = fileName.endsWith('.csv');

    return {
      success: true,
      data: {
        uploadId: generateId('upload'),
        fileName,
        totalRows: 247,
        columns: isCSV
          ? [
              { name: 'Date', type: 'date', sampleValues: ['2026-01-13', '2026-01-12', '2026-01-11'] },
              { name: 'Description', type: 'string', sampleValues: ['ACH CREDIT ACME CORP', 'ADOBE CREATIVE CLOUD', 'GOOGLE ADS'] },
              { name: 'Debit', type: 'number', sampleValues: ['', '79.99', '2850.00'] },
              { name: 'Credit', type: 'number', sampleValues: ['15000.00', '', ''] },
              { name: 'Balance', type: 'number', sampleValues: ['85000.00', '84920.01', '82070.01'] },
            ]
          : [
              { name: 'Transaction Date', type: 'date', sampleValues: ['13/01/2026', '12/01/2026'] },
              { name: 'Narration', type: 'string', sampleValues: ['Payment received', 'Monthly subscription'] },
              { name: 'Amount', type: 'number', sampleValues: ['15000.00', '-79.99'] },
            ],
        suggestedMapping: isCSV
          ? { date: 'Date', description: 'Description', amountOut: 'Debit', amountIn: 'Credit', balance: 'Balance' }
          : { date: 'Transaction Date', description: 'Narration', amount: 'Amount' },
        duplicatesDetected: 3,
      },
    };
  },

  /**
   * Execute the import with column mapping
   * TODO: Replace with POST /api/imports/:uploadId/execute
   */
  async executeImport(
    organizationId: string,
    uploadId: string,
    bankAccountId: string,
    columnMapping: Record<string, string>,
    options: {
      skipDuplicates?: boolean;
      autoClassify?: boolean;
      currency?: string;
    } = {}
  ): Promise<ServiceResponse<ImportResult>> {
    await simulateDelay(2000); // Imports take time

    const { skipDuplicates = true, autoClassify = true, currency = 'USD' } = options;

    // Simulate importing transactions
    const mockImportedTxns: Omit<Transaction, 'id' | 'organizationId' | 'createdAt'>[] = [
      {
        bankAccountId,
        date: '2026-01-14',
        description: 'DEPOSIT - NEW CLIENT ONBOARDING',
        narration: 'Onboarding fee from new client StartupXYZ',
        amount: 8500,
        currency,
        type: 'credit',
        status: 'pending',
        tags: ['imported'],
        attachments: [],
      },
      {
        bankAccountId,
        date: '2026-01-14',
        description: 'SLACK TECHNOLOGIES',
        narration: 'Monthly Slack Business+ subscription',
        amount: -12.50,
        currency,
        type: 'debit',
        status: 'pending',
        tags: ['imported'],
        attachments: [],
      },
      {
        bankAccountId,
        date: '2026-01-13',
        description: 'UBER FOR BUSINESS',
        narration: 'Team transportation for client meeting',
        amount: -45.80,
        currency,
        type: 'debit',
        status: 'pending',
        tags: ['imported'],
        attachments: [],
      },
    ];

    let autoClassified = 0;
    let needsReview = 0;

    // Auto-classify if enabled
    if (autoClassify) {
      for (const txn of mockImportedTxns) {
        const classResult = await classificationService.classify(
          organizationId,
          txn.narration,
          txn.amount,
          txn.type
        );
        if (classResult.success && classResult.data.confidence >= 60) {
          txn.categoryId = classResult.data.categoryId;
          txn.status = 'classified';
          txn.confidence = classResult.data.confidence;
          txn.classifiedBy = 'auto';
          txn.classifiedAt = new Date().toISOString();
          autoClassified++;
        } else {
          needsReview++;
        }
      }
    } else {
      needsReview = mockImportedTxns.length;
    }

    // Add to data store
    const imported: Transaction[] = [];
    for (const txn of mockImportedTxns) {
      const newTxn: Transaction = {
        ...txn,
        id: generateId('txn'),
        organizationId,
        createdAt: new Date().toISOString(),
      };
      dataStore.transactions.unshift(newTxn);
      imported.push(newTxn);
    }

    dataStore.notify('transactions');

    const totalIncome = imported.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0);
    const totalExpenses = imported.filter(t => t.type === 'debit').reduce((s, t) => s + Math.abs(t.amount), 0);

    return {
      success: true,
      data: {
        imported: imported.length,
        skipped: skipDuplicates ? 3 : 0,
        duplicates: 3,
        errors: [],
        summary: {
          totalIncome,
          totalExpenses,
          netAmount: totalIncome - totalExpenses,
          autoClassified,
          needsReview,
        },
      },
      message: `${imported.length} transactions imported successfully`,
    };
  },

  /**
   * Get import history
   * TODO: Replace with GET /api/organizations/:orgId/imports
   */
  async getHistory(organizationId: string): Promise<ServiceResponse<ImportHistoryRecord[]>> {
    await simulateDelay();

    // Base records — in a real backend these come from an imports table
    const baseRecords: { id: string; fileName: string; importedAt: string; transactionCount: number; status: string; bankAccountId: string }[] = [
      { id: 'import-001', fileName: 'chase_jan_2026.csv', importedAt: '2026-01-13T08:00:00Z', transactionCount: 45, status: 'completed', bankAccountId: 'bank-001' },
      { id: 'import-002', fileName: 'amex_dec_2025.csv', importedAt: '2026-01-01T10:30:00Z', transactionCount: 32, status: 'completed', bankAccountId: 'bank-002' },
    ];

    // Enrich each record with bank account name + classification stats
    const enriched: ImportHistoryRecord[] = baseRecords.map(rec => {
      // Resolve account display name from dataStore
      const bankAccount = dataStore.bankAccounts.find(b => b.id === rec.bankAccountId);
      const accountName = bankAccount?.bankName
        ? `${bankAccount.bankName} (${bankAccount.currency || 'USD'})`
        : 'Unknown Account';

      // Derive classification stats from imported transactions
      const importedTxns = dataStore.transactions.filter(
        t => t.organizationId === organizationId && t.tags?.includes('imported')
      );
      // Approximate per-import: distribute proportionally or use deterministic demo values
      const autoPlaced = Math.round(rec.transactionCount * 0.9);
      const needsReview = Math.round(rec.transactionCount * 0.08);
      const duplicatesFound = Math.max(0, rec.transactionCount - autoPlaced - needsReview);

      return {
        id: rec.id,
        fileName: rec.fileName,
        importedAt: rec.importedAt,
        transactionCount: rec.transactionCount,
        status: rec.status,
        accountName,
        autoPlaced,
        needsReview,
        duplicatesFound,
      };
    });

    return { success: true, data: enriched };
  },
};