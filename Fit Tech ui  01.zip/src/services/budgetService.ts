/**
 * Budget Service
 * ===============
 * CRUD for budgets with tracking and variance analysis.
 *
 * MIGRATION: Replace method bodies with API calls.
 */

import { Budget } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse } from './types';

export const budgetService = {
  /** TODO: Replace with GET /api/organizations/:orgId/budgets */
  async getAll(organizationId: string): Promise<ServiceResponse<Budget[]>> {
    await simulateDelay();
    return { success: true, data: dataStore.budgets.filter(b => b.organizationId === organizationId) };
  },

  /** TODO: Replace with GET /api/budgets/:id */
  async getById(id: string): Promise<ServiceResponse<Budget | null>> {
    await simulateDelay(80);
    const budget = dataStore.budgets.find(b => b.id === id) || null;
    return { success: !!budget, data: budget };
  },

  /** TODO: Replace with POST /api/organizations/:orgId/budgets */
  async create(organizationId: string, data: Omit<Budget, 'id' | 'organizationId'>): Promise<ServiceResponse<Budget>> {
    await simulateDelay(200);
    const newBudget: Budget = { ...data, id: generateId('budget'), organizationId };
    dataStore.budgets.push(newBudget);
    dataStore.notify('budgets');
    return { success: true, data: newBudget, message: 'Budget created' };
  },

  /** TODO: Replace with PATCH /api/budgets/:id */
  async update(id: string, updates: Partial<Budget>): Promise<ServiceResponse<Budget>> {
    await simulateDelay(150);
    const idx = dataStore.budgets.findIndex(b => b.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Budget not found' };
    dataStore.budgets[idx] = { ...dataStore.budgets[idx], ...updates };
    dataStore.notify('budgets');
    return { success: true, data: dataStore.budgets[idx] };
  },

  /** TODO: Replace with DELETE /api/budgets/:id */
  async delete(id: string): Promise<ServiceResponse<null>> {
    await simulateDelay(150);
    const idx = dataStore.budgets.findIndex(b => b.id === id);
    if (idx === -1) return { success: false, data: null, error: 'Budget not found' };
    dataStore.budgets.splice(idx, 1);
    dataStore.notify('budgets');
    return { success: true, data: null, message: 'Budget deleted' };
  },

  /**
   * Get budget vs actual analysis
   * BUSINESS LOGIC - stays after migration
   */
  async getVarianceAnalysis(organizationId: string): Promise<ServiceResponse<{
    budgetId: string;
    name: string;
    budgeted: number;
    actual: number;
    variance: number;
    variancePercent: number;
    status: string;
    isOverBudget: boolean;
  }[]>> {
    await simulateDelay();

    const budgets = dataStore.budgets.filter(b => b.organizationId === organizationId);
    const analysis = budgets.map(budget => {
      const variance = budget.budgetedAmount - budget.spentAmount;
      const variancePercent = budget.budgetedAmount > 0
        ? (variance / budget.budgetedAmount) * 100
        : 0;

      return {
        budgetId: budget.id,
        name: budget.name,
        budgeted: budget.budgetedAmount,
        actual: budget.spentAmount,
        variance,
        variancePercent: Math.round(variancePercent * 10) / 10,
        status: budget.status,
        isOverBudget: budget.spentAmount > budget.budgetedAmount,
      };
    });

    return { success: true, data: analysis };
  },

  /**
   * Get budget alerts (over or near budget)
   * BUSINESS LOGIC
   */
  async getAlerts(organizationId: string): Promise<ServiceResponse<Budget[]>> {
    await simulateDelay();
    const alerts = dataStore.budgets.filter(b => {
      if (b.organizationId !== organizationId) return false;
      const utilization = b.budgetedAmount > 0 ? (b.spentAmount / b.budgetedAmount) * 100 : 0;
      return utilization >= 80; // Alert when 80%+ utilized
    });
    return { success: true, data: alerts };
  },
};