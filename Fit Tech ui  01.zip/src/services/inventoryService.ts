/**
 * Inventory Service
 * ==================
 * CRUD for inventory items and inventory transactions.
 *
 * MIGRATION: Replace method bodies with API calls.
 */

import { InventoryItem, InventoryTransaction } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse } from './types';

export const inventoryService = {
  /** TODO: Replace with GET /api/organizations/:orgId/inventory */
  async getAll(organizationId: string): Promise<ServiceResponse<InventoryItem[]>> {
    await simulateDelay();
    return { success: true, data: dataStore.inventoryItems.filter(i => i.organizationId === organizationId) };
  },

  /** TODO: Replace with GET /api/inventory/:id */
  async getById(id: string): Promise<ServiceResponse<InventoryItem | null>> {
    await simulateDelay(80);
    const item = dataStore.inventoryItems.find(i => i.id === id) || null;
    return { success: !!item, data: item };
  },

  /** TODO: Replace with POST /api/organizations/:orgId/inventory */
  async create(organizationId: string, data: Omit<InventoryItem, 'id' | 'organizationId'>): Promise<ServiceResponse<InventoryItem>> {
    await simulateDelay(200);
    const newItem: InventoryItem = { ...data, id: generateId('inv'), organizationId };
    dataStore.inventoryItems.push(newItem);
    dataStore.notify('inventoryItems');
    return { success: true, data: newItem, message: 'Inventory item created' };
  },

  /** TODO: Replace with PATCH /api/inventory/:id */
  async update(id: string, updates: Partial<InventoryItem>): Promise<ServiceResponse<InventoryItem>> {
    await simulateDelay(150);
    const idx = dataStore.inventoryItems.findIndex(i => i.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Item not found' };
    dataStore.inventoryItems[idx] = { ...dataStore.inventoryItems[idx], ...updates };
    dataStore.notify('inventoryItems');
    return { success: true, data: dataStore.inventoryItems[idx] };
  },

  /**
   * Record inventory transaction (purchase, sale, adjustment)
   * TODO: Replace with POST /api/inventory/:id/transactions
   */
  async recordTransaction(
    organizationId: string,
    data: Omit<InventoryTransaction, 'id' | 'organizationId'>
  ): Promise<ServiceResponse<InventoryTransaction>> {
    await simulateDelay(200);

    // Create the inventory transaction
    const newTxn: InventoryTransaction = { ...data, id: generateId('invtxn'), organizationId };
    dataStore.inventoryTransactions.push(newTxn);

    // Update stock level
    const itemIdx = dataStore.inventoryItems.findIndex(i => i.id === data.inventoryItemId);
    if (itemIdx !== -1) {
      dataStore.inventoryItems[itemIdx].currentStock += data.quantity;

      // Update average cost on purchase
      if (data.type === 'purchase' && data.quantity > 0) {
        const item = dataStore.inventoryItems[itemIdx];
        const totalValue = (item.averageCost * (item.currentStock - data.quantity)) + data.totalAmount;
        item.averageCost = totalValue / item.currentStock;
        item.lastCost = data.unitCost;
      }
    }

    dataStore.notify('inventoryItems');
    dataStore.notify('inventoryTransactions');
    return { success: true, data: newTxn, message: 'Transaction recorded' };
  },

  /** TODO: Replace with GET /api/inventory/:id/transactions */
  async getTransactions(inventoryItemId: string): Promise<ServiceResponse<InventoryTransaction[]>> {
    await simulateDelay();
    const txns = dataStore.inventoryTransactions.filter(t => t.inventoryItemId === inventoryItemId);
    return { success: true, data: txns };
  },

  /**
   * Get low stock alerts
   * BUSINESS LOGIC - stays after migration
   */
  async getLowStockAlerts(organizationId: string): Promise<ServiceResponse<InventoryItem[]>> {
    await simulateDelay();
    const lowStock = dataStore.inventoryItems.filter(
      i => i.organizationId === organizationId && i.isActive && i.currentStock <= i.reorderLevel
    );
    return { success: true, data: lowStock };
  },

  /**
   * Get inventory valuation
   * BUSINESS LOGIC - stays after migration
   */
  async getValuation(organizationId: string): Promise<ServiceResponse<{
    totalItems: number;
    totalValue: number;
    byCostingMethod: { method: string; count: number; value: number }[];
  }>> {
    await simulateDelay();
    const items = dataStore.inventoryItems.filter(i => i.organizationId === organizationId && i.isActive);

    const byMethod = new Map<string, { count: number; value: number }>();
    let totalValue = 0;

    for (const item of items) {
      const value = item.currentStock * item.averageCost;
      totalValue += value;
      const existing = byMethod.get(item.costingMethod) || { count: 0, value: 0 };
      byMethod.set(item.costingMethod, { count: existing.count + 1, value: existing.value + value });
    }

    return {
      success: true,
      data: {
        totalItems: items.length,
        totalValue: Math.round(totalValue * 100) / 100,
        byCostingMethod: Array.from(byMethod.entries()).map(([method, data]) => ({
          method,
          ...data,
          value: Math.round(data.value * 100) / 100,
        })),
      },
    };
  },
};