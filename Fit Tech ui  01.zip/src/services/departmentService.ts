/**
 * Department Service
 * ===================
 * CRUD for departments with profitability and overhead allocation.
 *
 * MIGRATION: Replace method bodies with API calls.
 */

import { Department } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse, DepartmentProfitability } from './types';

export const departmentService = {
  /** TODO: Replace with GET /api/organizations/:orgId/departments */
  async getAll(organizationId: string): Promise<ServiceResponse<Department[]>> {
    await simulateDelay();
    const departments = dataStore.departments.filter(d => d.organizationId === organizationId);
    return { success: true, data: departments };
  },

  /** TODO: Replace with GET /api/departments/:id */
  async getById(id: string): Promise<ServiceResponse<Department | null>> {
    await simulateDelay(80);
    const dept = dataStore.departments.find(d => d.id === id) || null;
    return { success: !!dept, data: dept };
  },

  /** TODO: Replace with POST /api/organizations/:orgId/departments */
  async create(organizationId: string, data: Omit<Department, 'id' | 'organizationId'>): Promise<ServiceResponse<Department>> {
    await simulateDelay(200);
    const newDept: Department = { ...data, id: generateId('dept'), organizationId };
    dataStore.departments.push(newDept);
    dataStore.notify('departments');
    return { success: true, data: newDept, message: 'Department created' };
  },

  /** TODO: Replace with PATCH /api/departments/:id */
  async update(id: string, updates: Partial<Department>): Promise<ServiceResponse<Department>> {
    await simulateDelay(150);
    const idx = dataStore.departments.findIndex(d => d.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Department not found' };
    dataStore.departments[idx] = { ...dataStore.departments[idx], ...updates };
    dataStore.notify('departments');
    return { success: true, data: dataStore.departments[idx] };
  },

  /** TODO: Replace with DELETE /api/departments/:id */
  async delete(id: string): Promise<ServiceResponse<null>> {
    await simulateDelay(150);
    const idx = dataStore.departments.findIndex(d => d.id === id);
    if (idx === -1) return { success: false, data: null, error: 'Department not found' };
    dataStore.departments.splice(idx, 1);
    dataStore.notify('departments');
    return { success: true, data: null, message: 'Department deleted' };
  },

  /**
   * Calculate department profitability with overhead allocation
   * BUSINESS LOGIC - stays the same after migration, only data source changes
   */
  async getProfitability(organizationId: string): Promise<ServiceResponse<DepartmentProfitability[]>> {
    await simulateDelay();

    const departments = dataStore.departments.filter(d => d.organizationId === organizationId && d.isActive);
    const orgTxns = dataStore.transactions.filter(t => t.organizationId === organizationId);
    const members = dataStore.organizationMembers.filter(m => m.organizationId === organizationId);
    const allocations = dataStore.overheadAllocations.filter(a => a.organizationId === organizationId);

    const profitability: DepartmentProfitability[] = departments.map(dept => {
      // Revenue: credit transactions for this department
      const deptTxns = orgTxns.filter(t => t.departmentId === dept.id);
      const revenue = deptTxns.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0);
      const directCosts = deptTxns.filter(t => t.type === 'debit').reduce((s, t) => s + Math.abs(t.amount), 0);

      // Overhead: sum allocations for this department
      let allocatedOverhead = 0;
      for (const alloc of allocations) {
        const deptAlloc = alloc.departments.find(d => d.departmentId === dept.id);
        if (deptAlloc) {
          const totalOverhead = alloc.accountIds.reduce((sum, accId) => {
            const acc = dataStore.accounts.find(a => a.id === accId);
            return sum + (acc?.balance || 0);
          }, 0);
          allocatedOverhead += (totalOverhead * deptAlloc.percentage) / 100;
        }
      }

      // Headcount
      const headcount = members.filter(m => {
        // Approximate: check if user's transactions are in this department
        return orgTxns.some(t => t.departmentId === dept.id && t.classifiedBy === m.userId);
      }).length || Math.max(1, Math.round(Math.random() * 5 + 2)); // Fallback for demo

      const netProfit = revenue - directCosts - allocatedOverhead;
      const profitMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0;

      // ── Enriched fields (Phase 9A) ──────────────────────────────────────
      // Total capacity: headcount × standard 160-hour work month
      const totalHours = headcount * 160;

      // Billable hours: derive from revenue/cost ratio with sensible floor
      // When real time-tracking exists, replace this with actual tracked hours
      const billableRatio = revenue > 0
        ? Math.min(0.85, Math.max(0.45, revenue / (revenue + directCosts + 1)))
        : 0.6;
      const billableHours = Math.round(totalHours * billableRatio);

      // Utilization: billable as percentage of total capacity
      const utilization = totalHours > 0
        ? Math.round((billableHours / totalHours) * 1000) / 10
        : 0;

      // Cost per hour: effective rate based on direct costs and total capacity
      const costPerHour = totalHours > 0
        ? Math.round(directCosts / totalHours)
        : dept.budget ? Math.round(dept.budget / 160) : 0;

      return {
        departmentId: dept.id,
        departmentName: dept.name,
        revenue,
        directCosts,
        allocatedOverhead: Math.round(allocatedOverhead),
        netProfit: Math.round(netProfit),
        profitMargin: Math.round(profitMargin * 10) / 10,
        headcount,
        revenuePerHead: headcount > 0 ? Math.round(revenue / headcount) : 0,
        totalHours,
        billableHours,
        utilization,
        costPerHour,
      };
    });

    return { success: true, data: profitability };
  },
};