/**
 * Notification Service
 * =====================
 * CRUD for user notifications.
 *
 * MIGRATION: Replace method bodies with API calls (or WebSocket events).
 */

import { Notification } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse } from './types';

export const notificationService = {
  /** TODO: Replace with GET /api/users/:userId/notifications */
  async getAll(userId: string, organizationId: string): Promise<ServiceResponse<Notification[]>> {
    await simulateDelay();
    const notifications = dataStore.notifications.filter(
      n => n.userId === userId && n.organizationId === organizationId
    );
    return { success: true, data: notifications };
  },

  /** TODO: Replace with GET /api/notifications/unread-count */
  async getUnreadCount(userId: string, organizationId: string): Promise<ServiceResponse<number>> {
    await simulateDelay(50);
    const count = dataStore.notifications.filter(
      n => n.userId === userId && n.organizationId === organizationId && !n.isRead
    ).length;
    return { success: true, data: count };
  },

  /** TODO: Replace with PATCH /api/notifications/:id/read */
  async markAsRead(notificationId: string): Promise<ServiceResponse<null>> {
    await simulateDelay(80);
    const idx = dataStore.notifications.findIndex(n => n.id === notificationId);
    if (idx !== -1) {
      dataStore.notifications[idx].isRead = true;
      dataStore.notify('notifications');
    }
    return { success: true, data: null };
  },

  /** TODO: Replace with POST /api/notifications/mark-all-read */
  async markAllAsRead(userId: string, organizationId: string): Promise<ServiceResponse<null>> {
    await simulateDelay(100);
    dataStore.notifications.forEach(n => {
      if (n.userId === userId && n.organizationId === organizationId) {
        n.isRead = true;
      }
    });
    dataStore.notify('notifications');
    return { success: true, data: null, message: 'All marked as read' };
  },

  /** TODO: Replace with POST /api/notifications */
  async create(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<ServiceResponse<Notification>> {
    await simulateDelay(100);
    const newNotif: Notification = {
      ...notification,
      id: generateId('notif'),
      createdAt: new Date().toISOString(),
    };
    dataStore.notifications.unshift(newNotif);
    dataStore.notify('notifications');
    return { success: true, data: newNotif };
  },

  /** TODO: Replace with DELETE /api/notifications/:id */
  async delete(notificationId: string): Promise<ServiceResponse<null>> {
    await simulateDelay(80);
    const idx = dataStore.notifications.findIndex(n => n.id === notificationId);
    if (idx !== -1) {
      dataStore.notifications.splice(idx, 1);
      dataStore.notify('notifications');
    }
    return { success: true, data: null };
  },
};