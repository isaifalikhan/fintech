/**
 * Account (Chart of Accounts) Service
 * =====================================
 * CRUD for chart of accounts and bank accounts.
 *
 * MIGRATION: Replace method bodies with API calls.
 */

import { Account, BankAccount } from '@/services/types';
import { dataStore, generateId, simulateDelay } from './dataStore';
import type { ServiceResponse, BalanceSheetReport } from './types';

export const accountService = {
  // ---- CHART OF ACCOUNTS ----

  /** TODO: Replace with GET /api/organizations/:orgId/accounts */
  async getAll(organizationId: string): Promise<ServiceResponse<Account[]>> {
    await simulateDelay();
    const accounts = dataStore.accounts.filter(a => a.organizationId === organizationId);
    return { success: true, data: accounts };
  },

  /** TODO: Replace with GET /api/accounts/:id */
  async getById(id: string): Promise<ServiceResponse<Account | null>> {
    await simulateDelay(80);
    const account = dataStore.accounts.find(a => a.id === id) || null;
    return { success: !!account, data: account };
  },

  /** TODO: Replace with POST /api/organizations/:orgId/accounts */
  async create(organizationId: string, data: Omit<Account, 'id' | 'organizationId' | 'createdAt'>): Promise<ServiceResponse<Account>> {
    await simulateDelay(200);
    const newAcc: Account = {
      ...data,
      id: generateId('acc'),
      organizationId,
      createdAt: new Date().toISOString(),
    };
    dataStore.accounts.push(newAcc);
    dataStore.notify('accounts');
    return { success: true, data: newAcc, message: 'Account created' };
  },

  /** TODO: Replace with PATCH /api/accounts/:id */
  async update(id: string, updates: Partial<Account>): Promise<ServiceResponse<Account>> {
    await simulateDelay(150);
    const idx = dataStore.accounts.findIndex(a => a.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Account not found' };
    dataStore.accounts[idx] = { ...dataStore.accounts[idx], ...updates };
    dataStore.notify('accounts');
    return { success: true, data: dataStore.accounts[idx] };
  },

  /** TODO: Replace with DELETE /api/accounts/:id */
  async delete(id: string): Promise<ServiceResponse<null>> {
    await simulateDelay(150);
    const idx = dataStore.accounts.findIndex(a => a.id === id);
    if (idx === -1) return { success: false, data: null, error: 'Account not found' };
    dataStore.accounts.splice(idx, 1);
    dataStore.notify('accounts');
    return { success: true, data: null, message: 'Account deleted' };
  },

  /**
   * Get accounts organized by type (tree structure)
   * BUSINESS LOGIC - stays after migration
   */
  async getAccountTree(organizationId: string): Promise<ServiceResponse<{
    assets: Account[];
    liabilities: Account[];
    equity: Account[];
    income: Account[];
    expenses: Account[];
  }>> {
    await simulateDelay();
    const accounts = dataStore.accounts.filter(a => a.organizationId === organizationId);

    return {
      success: true,
      data: {
        assets: accounts.filter(a => a.type === 'asset'),
        liabilities: accounts.filter(a => a.type === 'liability'),
        equity: accounts.filter(a => a.type === 'equity'),
        income: accounts.filter(a => a.type === 'income'),
        expenses: accounts.filter(a => a.type === 'expense'),
      },
    };
  },

  // ---- BANK ACCOUNTS ----

  /** TODO: Replace with GET /api/organizations/:orgId/bank-accounts */
  async getBankAccounts(organizationId: string): Promise<ServiceResponse<BankAccount[]>> {
    await simulateDelay();
    const accounts = dataStore.bankAccounts.filter(b => b.organizationId === organizationId);
    return { success: true, data: accounts };
  },

  /** TODO: Replace with POST /api/organizations/:orgId/bank-accounts */
  async createBankAccount(
    organizationId: string,
    data: Omit<BankAccount, 'id' | 'organizationId'>
  ): Promise<ServiceResponse<BankAccount>> {
    await simulateDelay(200);
    const newBank: BankAccount = { ...data, id: generateId('bank'), organizationId };
    dataStore.bankAccounts.push(newBank);
    dataStore.notify('bankAccounts');
    return { success: true, data: newBank, message: 'Bank account added' };
  },

  /** TODO: Replace with PATCH /api/bank-accounts/:id */
  async updateBankAccount(id: string, updates: Partial<BankAccount>): Promise<ServiceResponse<BankAccount>> {
    await simulateDelay(150);
    const idx = dataStore.bankAccounts.findIndex(b => b.id === id);
    if (idx === -1) return { success: false, data: null as any, error: 'Bank account not found' };
    dataStore.bankAccounts[idx] = { ...dataStore.bankAccounts[idx], ...updates };
    dataStore.notify('bankAccounts');
    return { success: true, data: dataStore.bankAccounts[idx] };
  },

  // ---- BALANCE SHEET (BUSINESS LOGIC) ----

  /**
   * Generate balance sheet report from chart of accounts
   * BUSINESS LOGIC - calculation stays, data source changes
   */
  async getBalanceSheet(organizationId: string, asOfDate?: string): Promise<ServiceResponse<BalanceSheetReport>> {
    await simulateDelay(200);

    const accounts = dataStore.accounts.filter(a => a.organizationId === organizationId && a.isActive);
    const assets = accounts.filter(a => a.type === 'asset');
    const liabilities = accounts.filter(a => a.type === 'liability');
    const equity = accounts.filter(a => a.type === 'equity');

    const totalAssets = assets.reduce((s, a) => s + a.balance, 0);
    const totalLiabilities = liabilities.reduce((s, a) => s + a.balance, 0);
    const totalEquity = equity.reduce((s, a) => s + a.balance, 0);

    return {
      success: true,
      data: {
        asOfDate: asOfDate || new Date().toISOString().split('T')[0],
        assets: assets.map(a => ({ accountId: a.id, name: a.name, balance: a.balance, type: a.subtype })),
        liabilities: liabilities.map(a => ({ accountId: a.id, name: a.name, balance: a.balance, type: a.subtype })),
        equity: equity.map(a => ({ accountId: a.id, name: a.name, balance: a.balance, type: a.subtype })),
        totalAssets,
        totalLiabilities,
        totalEquity,
      },
    };
  },
};