/**
 * useService Hook
 * ================
 * Generic React hook for consuming service layer methods.
 * Handles loading, error, and data states automatically.
 *
 * MIGRATION: This hook stays as-is. It works with any async function.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import type { ServiceResponse } from '@/services/types';

interface UseServiceState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

interface UseServiceReturn<T> extends UseServiceState<T> {
  refetch: () => Promise<void>;
  mutate: (newData: T) => void;
}

/**
 * Hook for auto-fetching service data on mount
 *
 * Usage:
 *   const { data, loading, error, refetch } = useService(
 *     () => transactionService.getAll('org-001', { page: 1 }),
 *     [page] // re-fetch when deps change
 *   );
 */
export function useService<T>(
  serviceFn: () => Promise<ServiceResponse<T>>,
  deps: any[] = []
): UseServiceReturn<T> {
  const [state, setState] = useState<UseServiceState<T>>({
    data: null,
    loading: true,
    error: null,
  });
  const mountedRef = useRef(true);

  const fetchData = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    try {
      const response = await serviceFn();
      if (mountedRef.current) {
        if (response.success) {
          setState({ data: response.data, loading: false, error: null });
        } else {
          setState({ data: null, loading: false, error: response.error || 'Unknown error' });
        }
      }
    } catch (err: any) {
      if (mountedRef.current) {
        setState({ data: null, loading: false, error: err.message || 'Service error' });
      }
    }
  }, deps);

  useEffect(() => {
    mountedRef.current = true;
    fetchData();
    return () => { mountedRef.current = false; };
  }, [fetchData]);

  const mutate = useCallback((newData: T) => {
    setState(prev => ({ ...prev, data: newData }));
  }, []);

  return { ...state, refetch: fetchData, mutate };
}

/**
 * Hook for service mutations (create, update, delete)
 *
 * Usage:
 *   const { execute, loading, error } = useMutation(
 *     (data) => transactionService.create('org-001', data)
 *   );
 *   await execute(newTransactionData);
 */
export function useMutation<TInput, TOutput>(
  mutationFn: (input: TInput) => Promise<ServiceResponse<TOutput>>
): {
  execute: (input: TInput) => Promise<ServiceResponse<TOutput>>;
  loading: boolean;
  error: string | null;
  data: TOutput | null;
  reset: () => void;
} {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<TOutput | null>(null);

  const execute = useCallback(async (input: TInput) => {
    setLoading(true);
    setError(null);
    try {
      const response = await mutationFn(input);
      if (response.success) {
        setData(response.data);
      } else {
        setError(response.error || 'Mutation failed');
      }
      setLoading(false);
      return response;
    } catch (err: any) {
      const errorMsg = err.message || 'Mutation error';
      setError(errorMsg);
      setLoading(false);
      return { success: false, data: null as any, error: errorMsg };
    }
  }, [mutationFn]);

  const reset = useCallback(() => {
    setLoading(false);
    setError(null);
    setData(null);
  }, []);

  return { execute, loading, error, data, reset };
}
