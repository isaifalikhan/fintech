import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageCircle, 
  X, 
  Send, 
  Sparkles,
  TrendingUp,
  DollarSign,
  AlertCircle,
  Minimize2,
  Maximize2
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

const SAMPLE_RESPONSES = [
  {
    trigger: ['profit', 'margin'],
    response: 'Your profit margin for this month is 28%, which is 3.2% higher than last month. This improvement is primarily due to reduced cloud infrastructure costs and increased client revenue from the ABC Corp project.',
    suggestions: [
      'Show me department profitability',
      'Which clients are most profitable?',
      'How can I improve margins further?'
    ]
  },
  {
    trigger: ['cash', 'flow', 'balance'],
    response: 'Your current cash balance is PKR 2.5M. Based on your recurring expenses and scheduled payments, your balance may drop below PKR 500K in approximately 15 days. I recommend reviewing your accounts receivable and following up on overdue invoices.',
    suggestions: [
      'Show cash flow forecast',
      'List overdue invoices',
      'What are my upcoming expenses?'
    ]
  },
  {
    trigger: ['expense', 'spending'],
    response: 'Your top expense category this month is "Salaries & Wages" at PKR 850K (42% of total expenses), followed by "Cloud Infrastructure" at PKR 180K (9%). Compared to last month, overall expenses decreased by 5%.',
    suggestions: [
      'Show expense breakdown chart',
      'Compare expenses vs last quarter',
      'Which expenses can I reduce?'
    ]
  }
];

const QUICK_QUESTIONS = [
  'Why did profit drop last month?',
  'Show me cash flow forecast',
  'Which clients are most profitable?',
  'What are my biggest expenses?',
  'How is my budget tracking?'
];

export function AIAssistantChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Hi! I\'m your AI financial assistant. Ask me anything about your finances, and I\'ll provide insights based on your data.',
      timestamp: new Date(),
      suggestions: QUICK_QUESTIONS
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen, isMinimized]);

  const handleSend = (text?: string) => {
    const messageText = text || inputValue.trim();
    if (!messageText) return;

    // Add user message
    const userMessage: Message = {
      id: `user_${Date.now()}`,
      type: 'user',
      content: messageText,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate AI response
    setIsTyping(true);
    setTimeout(() => {
      // Find matching response
      const matchedResponse = SAMPLE_RESPONSES.find(sr => 
        sr.trigger.some(keyword => 
          messageText.toLowerCase().includes(keyword)
        )
      );

      const response = matchedResponse || {
        response: 'I can help you with that! Based on your data, I\'ll analyze this and provide insights. This is a demo response - in production, this would be powered by real AI analyzing your actual financial data.',
        suggestions: [
          'Show me detailed breakdown',
          'Compare with last month',
          'Export this data'
        ]
      };

      const assistantMessage: Message = {
        id: `assistant_${Date.now()}`,
        type: 'assistant',
        content: response.response,
        timestamp: new Date(),
        suggestions: response.suggestions
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleQuickQuestion = (question: string) => {
    handleSend(question);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 left-6 w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all z-40 group"
        title="AI Assistant"
      >
        <MessageCircle className="w-6 h-6 text-white" />
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-slate-900 animate-pulse" />
        
        {/* Pulse animation */}
        <div className="absolute inset-0 rounded-full bg-purple-500/50 animate-ping opacity-75 group-hover:opacity-0" />
      </button>
    );
  }

  return (
    <>
      {/* Chat Widget Button */}
      {!isOpen && !isMinimized && (
        <motion.button
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0, opacity: 0 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 rounded-full p-4 shadow-2xl"
          style={{
            background: 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)',
            boxShadow: '0 20px 50px -10px rgba(59, 130, 246, 0.5)',
          }}
        >
          <Sparkles className="w-6 h-6 text-white" />
        </motion.button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          className={`fixed z-50 shadow-2xl border border-white/10 overflow-hidden ${
            isMinimized ? 'bottom-6 right-6 w-80' : 'bottom-6 right-6 w-[500px] h-[700px]'
          }`}
          style={{
            background: '#0f0f13',
            borderRadius: '16px',
          }}
        >
          {/* Header */}
          <div className="p-4 border-b border-white/10 flex items-center justify-between" style={{
            background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%)',
          }}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{
                background: 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)',
                boxShadow: '0 10px 20px -5px rgba(59, 130, 246, 0.5)',
              }}>
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">AI Assistant</h3>
                <p className="text-xs text-slate-400">Always here to help</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="p-1.5 hover:bg-white/10 rounded transition-colors text-slate-400 hover:text-white"
              >
                {isMinimized ? (
                  <Maximize2 className="w-4 h-4" />
                ) : (
                  <Minimize2 className="w-4 h-4" />
                )}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 hover:bg-white/10 rounded transition-colors text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <MessageBubble key={message.id} message={message} onQuickQuestion={handleQuickQuestion} />
                ))}
                
                {/* Typing Indicator */}
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-start gap-3"
                  >
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1 bg-white/5 rounded-2xl rounded-tl-none p-4">
                      <div className="flex gap-1">
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </div>
                  </motion.div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-4 border-t border-white/10 bg-slate-950">
                <div className="flex gap-2">
                  <input
                    ref={inputRef}
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Ask me anything..."
                    className="flex-1 px-4 py-2 bg-slate-800 border border-white/10 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                  />
                  <Button
                    onClick={() => handleSend()}
                    disabled={!inputValue.trim()}
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:opacity-90 text-white"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </motion.div>
      )}
    </>
  );
}

function MessageBubble({ 
  message, 
  onQuickQuestion 
}: { 
  message: Message;
  onQuickQuestion: (question: string) => void;
}) {
  if (message.type === 'user') {
    return (
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex justify-end"
      >
        <div className="max-w-[80%] bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl rounded-tr-none px-4 py-3">
          <p className="text-white text-sm">{message.content}</p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex items-start gap-3"
    >
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
        <Sparkles className="w-4 h-4 text-white" />
      </div>
      <div className="flex-1 space-y-3">
        <div className="bg-white/5 rounded-2xl rounded-tl-none px-4 py-3">
          <p className="text-white text-sm leading-relaxed">{message.content}</p>
        </div>
        
        {/* Quick action suggestions */}
        {message.suggestions && message.suggestions.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs text-slate-400">Suggested actions:</p>
            {message.suggestions.map((suggestion, idx) => (
              <button
                key={idx}
                onClick={() => onQuickQuestion(suggestion)}
                className="block w-full text-left px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-xs text-slate-300 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}