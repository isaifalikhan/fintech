import { useState } from 'react';
import { motion } from 'motion/react';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';
import {
  Brain,
  Sparkles,
  TrendingUp,
  Check,
  X,
  AlertCircle,
  Plus,
  Trash2,
  Edit,
  Search,
  Filter,
  BookOpen,
  Target,
  Zap,
  BarChart3,
  Eye,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';
import { Button } from '../ui/button';
import { cn } from '../ui/utils';
import {
  classifyTransaction,
  learnFromFeedback,
  type ClassificationResult
} from '@/lib/classificationEngine';

type LearningView = 'patterns' | 'review' | 'performance' | 'rules';

export function EnhancedLogicLearning() {
  const [activeView, setActiveView] = useState<LearningView>('patterns');
  const [searchQuery, setSearchQuery] = useState('');
  const [testNarration, setTestNarration] = useState('');
  const [testResult, setTestResult] = useState<ClassificationResult | null>(null);
  
  const svc = useOrgServices();

  // Fetch categories via service layer
  const { data: categories = [] } = useService(
    () => svc.categories.getAll(),
    [svc.orgId]
  );

  // Fetch transactions (paginated — get a large page for learning analysis)
  const { data: txnResult } = useService(
    () => svc.transactions.getAll({ pageSize: 500 }),
    [svc.orgId]
  );
  const transactions = txnResult?.items ?? [];

  // Mock AI performance metrics
  const aiMetrics = {
    totalClassifications: 1247,
    accurateClassifications: 1189,
    accuracyRate: 95.3,
    avgConfidence: 89,
    learningRate: '+12% this month',
    patternsLearned: 156,
    userCorrections: 58,
  };

  const handleTestClassification = () => {
    if (!testNarration) return;

    const result = classifyTransaction(
      testNarration,
      1000, // Mock amount
      'debit',
      categories,
      transactions
    );

    setTestResult(result);
  };

  const recentClassifications = transactions
    .filter(t => t.classifiedBy === 'auto')
    .slice(0, 10);

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Logic & Learning Center
          </h1>
          <p className="text-gray-400 mt-1">AI-powered auto-classification engine</p>
        </div>
        <div className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-xl">
          <Brain className="w-5 h-5 text-purple-400" />
          <div>
            <div className="text-sm font-medium text-white">Neural Network Status</div>
            <div className="text-xs text-purple-400">Active & Learning</div>
          </div>
        </div>
      </motion.div>

      {/* AI Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-[#0a0a0f] to-[#1a1a2e] rounded-2xl p-6 border border-cyan-500/20 relative overflow-hidden group hover:border-cyan-500/40 transition-all"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Accuracy Rate</span>
              <Target className="w-5 h-5 text-cyan-400" />
            </div>
            <div className="text-3xl font-bold text-white">{aiMetrics.accuracyRate}%</div>
            <div className="text-xs text-green-400 mt-1">{aiMetrics.learningRate}</div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-[#0a0a0f] to-[#1a1a2e] rounded-2xl p-6 border border-purple-500/20 relative overflow-hidden group hover:border-purple-500/40 transition-all"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Avg Confidence</span>
              <Sparkles className="w-5 h-5 text-purple-400" />
            </div>
            <div className="text-3xl font-bold text-white">{aiMetrics.avgConfidence}%</div>
            <div className="text-xs text-purple-400 mt-1">High confidence</div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-br from-[#0a0a0f] to-[#1a1a2e] rounded-2xl p-6 border border-blue-500/20 relative overflow-hidden group hover:border-blue-500/40 transition-all"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Patterns Learned</span>
              <BookOpen className="w-5 h-5 text-blue-400" />
            </div>
            <div className="text-3xl font-bold text-white">{aiMetrics.patternsLearned}</div>
            <div className="text-xs text-blue-400 mt-1">Active patterns</div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="bg-gradient-to-br from-[#0a0a0f] to-[#1a1a2e] rounded-2xl p-6 border border-green-500/20 relative overflow-hidden group hover:border-green-500/40 transition-all"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">User Corrections</span>
              <TrendingUp className="w-5 h-5 text-green-400" />
            </div>
            <div className="text-3xl font-bold text-white">{aiMetrics.userCorrections}</div>
            <div className="text-xs text-green-400 mt-1">Learning from feedback</div>
          </div>
        </motion.div>
      </div>

      {/* View Tabs */}
      <div className="flex gap-2 border-b border-[#1a1a2e]">
        {[
          { id: 'patterns' as LearningView, label: 'Learned Patterns', icon: Sparkles },
          { id: 'review' as LearningView, label: 'Classification Review', icon: Eye },
          { id: 'performance' as LearningView, label: 'AI Performance', icon: BarChart3 },
          { id: 'rules' as LearningView, label: 'Custom Rules', icon: Zap },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeView === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveView(tab.id)}
              className={cn(
                'px-6 py-3 flex items-center gap-2 text-sm font-medium transition-all relative',
                isActive
                  ? 'text-cyan-400'
                  : 'text-gray-400 hover:text-white'
              )}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
              {isActive && (
                <motion.div
                  layoutId="logicActiveTab"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-500 to-blue-500"
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Content Area */}
      {activeView === 'patterns' && (
        <div className="space-y-6">
          {/* Test Classification */}
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Test AI Classification
            </h3>
            <div className="flex gap-4">
              <input
                type="text"
                placeholder="Enter a transaction description to test..."
                value={testNarration}
                onChange={(e) => setTestNarration(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleTestClassification()}
                className="flex-1 px-4 py-3 bg-[#0a0a0f] border border-[#2a2a3e] rounded-xl text-white placeholder-gray-500 focus:border-purple-500/50 focus:outline-none transition-all"
              />
              <Button
                onClick={handleTestClassification}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
              >
                <Zap className="w-4 h-4 mr-2" />
                Classify
              </Button>
            </div>

            {testResult && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 p-4 bg-[#0a0a0f] rounded-xl border border-[#2a2a3e]"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="text-sm text-gray-400 mb-1">AI Classification Result</div>
                    <div className="text-xl font-semibold text-white">{testResult.categoryName}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-400 mb-1">Confidence</div>
                    <div className={cn(
                      'text-xl font-bold',
                      testResult.confidence >= 80 ? 'text-green-400' :
                      testResult.confidence >= 60 ? 'text-orange-400' :
                      'text-red-400'
                    )}>
                      {testResult.confidence}%
                    </div>
                  </div>
                </div>
                <div className="text-sm text-gray-400 mb-3">{testResult.reasoning}</div>
                
                {testResult.alternativeSuggestions.length > 0 && (
                  <div>
                    <div className="text-xs text-gray-500 mb-2">Alternative Suggestions:</div>
                    <div className="flex flex-wrap gap-2">
                      {testResult.alternativeSuggestions.map((alt, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-[#1a1a2e] border border-[#2a2a3e] rounded-lg text-sm text-gray-400"
                        >
                          {alt.categoryName} ({alt.confidence}%)
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </div>

          {/* Learned Patterns by Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {categories.slice(0, 6).map((category) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#0a0a0f] border border-[#1a1a2e] rounded-2xl p-6 hover:border-cyan-500/30 transition-all"
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">{category.name}</h3>
                    <p className="text-xs text-gray-500 capitalize">{category.type}</p>
                  </div>
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center text-xl">
                    {category.icon}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="text-xs text-gray-400 mb-2">Learned Patterns:</div>
                  <div className="flex flex-wrap gap-2">
                    {category.patterns.slice(0, 5).map((pattern, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-cyan-500/10 border border-cyan-500/20 rounded text-xs text-cyan-400"
                      >
                        {pattern}
                      </span>
                    ))}
                    {category.patterns.length > 5 && (
                      <span className="px-2 py-1 bg-[#1a1a2e] border border-[#2a2a3e] rounded text-xs text-gray-500">
                        +{category.patterns.length - 5} more
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {activeView === 'review' && (
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search classifications..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-[#0a0a0f] border border-[#1a1a2e] rounded-xl text-white placeholder-gray-500 focus:border-cyan-500/50 focus:outline-none transition-all"
              />
            </div>
            <Button className="bg-[#0a0a0f] border border-[#1a1a2e] hover:border-cyan-500/30 text-gray-400 hover:text-white">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>

          {/* Recent Auto-Classifications */}
          <div className="bg-[#0a0a0f] border border-[#1a1a2e] rounded-2xl overflow-hidden">
            <div className="p-6 border-b border-[#1a1a2e]">
              <h3 className="text-lg font-semibold text-white">Recent Auto-Classifications</h3>
              <p className="text-sm text-gray-400 mt-1">Review and provide feedback to improve AI accuracy</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#0a0a0f] border-b border-[#1a1a2e]">
                  <tr>
                    <th className="text-left px-6 py-4 text-xs font-medium text-gray-400 uppercase">Date</th>
                    <th className="text-left px-6 py-4 text-xs font-medium text-gray-400 uppercase">Description</th>
                    <th className="text-left px-6 py-4 text-xs font-medium text-gray-400 uppercase">Category</th>
                    <th className="text-center px-6 py-4 text-xs font-medium text-gray-400 uppercase">Confidence</th>
                    <th className="text-right px-6 py-4 text-xs font-medium text-gray-400 uppercase">Amount</th>
                    <th className="text-center px-6 py-4 text-xs font-medium text-gray-400 uppercase">Feedback</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1a1a2e]">
                  {recentClassifications.map((txn, index) => (
                    <motion.tr
                      key={txn.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="hover:bg-[#1a1a2e]/30 transition-colors"
                    >
                      <td className="px-6 py-4">
                        <span className="text-gray-300">{new Date(txn.date).toLocaleDateString()}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-white font-medium max-w-md truncate">{txn.narration}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-flex px-3 py-1 rounded-full text-xs font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                          {categories.find(c => c.id === txn.categoryId)?.name || 'Unknown'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <div className="w-16 h-2 bg-[#1a1a2e] rounded-full overflow-hidden">
                            <div
                              className={cn(
                                'h-full',
                                (txn.confidence || 0) >= 80 ? 'bg-green-500' :
                                (txn.confidence || 0) >= 60 ? 'bg-orange-500' :
                                'bg-red-500'
                              )}
                              style={{ width: `${txn.confidence || 0}%` }}
                            />
                          </div>
                          <span className="text-sm text-gray-400">{txn.confidence || 0}%</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className={cn(
                          'font-medium',
                          txn.type === 'credit' ? 'text-green-400' : 'text-red-400'
                        )}>
                          {txn.type === 'credit' ? '+' : '-'}
                          ${txn.amount.toLocaleString()}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-center gap-2">
                          <button className="p-2 hover:bg-green-500/10 rounded-lg transition-colors group">
                            <ThumbsUp className="w-4 h-4 text-gray-400 group-hover:text-green-400" />
                          </button>
                          <button className="p-2 hover:bg-red-500/10 rounded-lg transition-colors group">
                            <ThumbsDown className="w-4 h-4 text-gray-400 group-hover:text-red-400" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeView === 'performance' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-[#0a0a0f] to-[#1a1a2e] rounded-2xl p-6 border border-cyan-500/20"
          >
            <h3 className="text-lg font-semibold text-white mb-6">Classification Accuracy Trend</h3>
            <div className="space-y-4">
              {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'].map((month, idx) => {
                const accuracy = 88 + idx * 1.2;
                return (
                  <div key={month}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-400">{month} 2024</span>
                      <span className="text-sm text-cyan-400 font-medium">{accuracy.toFixed(1)}%</span>
                    </div>
                    <div className="h-2 bg-[#0a0a0f] rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${accuracy}%` }}
                        transition={{ duration: 1, delay: idx * 0.1 }}
                        className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-[#0a0a0f] to-[#1a1a2e] rounded-2xl p-6 border border-purple-500/20"
          >
            <h3 className="text-lg font-semibold text-white mb-6">Category Performance</h3>
            <div className="space-y-4">
              {categories.slice(0, 6).map((category, idx) => {
                const accuracy = 85 + Math.random() * 15;
                return (
                  <div key={category.id}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{category.icon}</span>
                        <span className="text-sm text-white">{category.name}</span>
                      </div>
                      <span className="text-sm text-purple-400 font-medium">{accuracy.toFixed(0)}%</span>
                    </div>
                    <div className="h-2 bg-[#0a0a0f] rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${accuracy}%` }}
                        transition={{ duration: 1, delay: idx * 0.1 }}
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </div>
      )}

      {activeView === 'rules' && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Create Custom Rule
            </Button>
          </div>

          <div className="bg-[#0a0a0f] border border-[#1a1a2e] rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Custom Classification Rules</h3>
            <p className="text-sm text-gray-400 mb-6">
              Create explicit rules that override AI classification for specific patterns.
            </p>

            <div className="space-y-3">
              {[
                { pattern: 'AWS*', category: 'Software & Tools', confidence: 100 },
                { pattern: 'SALARY*', category: 'Salaries & Wages', confidence: 100 },
                { pattern: 'GOOGLE ADS*', category: 'Marketing', confidence: 100 },
              ].map((rule, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center justify-between p-4 bg-[#1a1a2e] border border-[#2a2a3e] rounded-xl hover:border-cyan-500/30 transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                      <Zap className="w-5 h-5 text-cyan-400" />
                    </div>
                    <div>
                      <div className="text-white font-medium">If contains: <span className="text-cyan-400 font-mono">{rule.pattern}</span></div>
                      <div className="text-sm text-gray-400">Then classify as: {rule.category}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full text-xs text-green-400">
                      {rule.confidence}% confidence
                    </span>
                    <button className="p-2 hover:bg-blue-500/10 rounded-lg transition-colors">
                      <Edit className="w-4 h-4 text-blue-400" />
                    </button>
                    <button className="p-2 hover:bg-red-500/10 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}