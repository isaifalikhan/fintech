import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';
import { formatCurrency, formatDate } from '@/lib/formatters';
import { useTheme } from '@/contexts/ThemeContext';
import { AXIOM } from '@/styles/axiom-tokens';
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Eye,
  Trash2,
  ArrowRight,
  Sparkles,
  Loader2,
  FileSpreadsheet,
  Building2
} from 'lucide-react';
import { toast } from 'sonner';
import {
  parseCSVFile,
  autoDetectColumnMapping,
  processCSVData,
  findDuplicates,
  calculateImportStats,
  type ImportedTransaction,
  type ColumnMapping,
} from '@/lib/importUtils';

type ImportStep = 'upload' | 'mapping' | 'review' | 'complete';

export function EnhancedStatementImport() {
  const { theme } = useTheme();
  const [currentStep, setCurrentStep] = useState<ImportStep>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedAccount, setSelectedAccount] = useState<string>('');
  const [dragActive, setDragActive] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvData, setCsvData] = useState<string[][]>([]);
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({
    date: '',
    amount: '',
    narration: '',
  });
  const [parsedTransactions, setParsedTransactions] = useState<ImportedTransaction[]>([]);
  const [filterDuplicates, setFilterDuplicates] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const svc = useOrgServices();

  // Bank accounts for account selector
  const { data: bankAccounts = [] } = useService(
    () => svc.accounts.getBankAccounts(),
    [svc.orgId]
  );

  // Existing transactions for duplicate detection
  const { data: txnResult } = useService(
    () => svc.transactions.getAll({ pageSize: 1000 }),
    [svc.orgId]
  );
  const existingTransactions = txnResult?.items ?? [];

  // Drag and drop handlers
  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    const file = files[0];

    if (file && (file.name.endsWith('.csv') || file.name.endsWith('.xlsx'))) {
      await handleFileSelected(file);
    } else {
      toast.error('Please upload a valid CSV or Excel file');
    }
  }, []);

  const handleFileSelected = async (file: File) => {
    setSelectedFile(file);
    setProcessing(true);

    try {
      // Parse CSV
      const data = await parseCSVFile(file);
      const headers = data[0];
      
      setCsvHeaders(headers);
      setCsvData(data);

      // Auto-detect column mapping
      const detectedMapping = autoDetectColumnMapping(headers);
      setColumnMapping(detectedMapping);

      setProcessing(false);
      setCurrentStep('mapping');
      toast.success('File parsed successfully!');
    } catch (error) {
      console.error('Error parsing file:', error);
      setProcessing(false);
      toast.error('Failed to parse file');
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelected(file);
    }
  };

  const handleProceedToReview = () => {
    if (!columnMapping.date || !columnMapping.amount || !columnMapping.narration) {
      toast.error('Please map all required columns');
      return;
    }

    setProcessing(true);

    // Process CSV data
    const transactions = processCSVData(csvData, columnMapping, csvHeaders);

    // Detect duplicates
    findDuplicates(transactions, existingTransactions);

    setParsedTransactions(transactions);
    setProcessing(false);
    setCurrentStep('review');
    toast.success(`Parsed ${transactions.length} transactions`);
  };

  const handleImport = () => {
    setProcessing(true);

    // Simulate import
    setTimeout(() => {
      setProcessing(false);
      setCurrentStep('complete');
      toast.success('Import completed successfully!');
    }, 2000);
  };

  const stats = calculateImportStats(parsedTransactions);

  const filteredTransactions = parsedTransactions.filter(txn => {
    if (filterDuplicates && txn.isDuplicate) return false;
    if (searchQuery && !txn.narration.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  const stepIndex = ['upload', 'mapping', 'review', 'complete'].indexOf(currentStep);

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <FileSpreadsheet className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>
                Enhanced Statement Import
              </h1>
              <p className="text-slate-400 text-sm">Import and auto-classify bank statements with smart detection</p>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
            style={{
              background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
              border: '1px solid rgba(6, 182, 212, 0.5)',
              boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
              color: '#ffffff',
            }}
            onClick={() => {
              setCurrentStep('upload');
              setSelectedFile(null);
              setParsedTransactions([]);
              setSelectedAccount('');
            }}
          >
            <Upload className="size-4" />
            New Import
          </motion.button>
        </div>
      </motion.div>

      {/* Progress Steps */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex items-center gap-3"
      >
        {[
          { id: 'upload', label: 'Upload File', icon: Upload },
          { id: 'mapping', label: 'Column Mapping', icon: FileText },
          { id: 'review', label: 'Review & Classify', icon: Eye },
          { id: 'complete', label: 'Complete', icon: CheckCircle2 },
        ].map((step, index) => {
          const Icon = step.icon;
          const isActive = currentStep === step.id;
          const isCompleted = stepIndex > index;
          
          return (
            <div key={step.id} className="flex items-center flex-1">
              <motion.div
                whileHover={{ scale: 1.02 }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl flex-1 transition-all"
                style={{
                  background: isActive 
                    ? 'linear-gradient(135deg, rgba(6, 182, 212, 0.2), rgba(59, 130, 246, 0.2))'
                    : isCompleted
                    ? 'rgba(16, 185, 129, 0.1)'
                    : AXIOM.containers.item.background,
                  border: isActive
                    ? '1px solid rgba(6, 182, 212, 0.5)'
                    : isCompleted
                    ? '1px solid rgba(16, 185, 129, 0.3)'
                    : AXIOM.containers.item.border,
                }}
              >
                <div 
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{
                    background: isActive
                      ? AXIOM.iconBoxes.cyan
                      : isCompleted
                      ? AXIOM.iconBoxes.green
                      : 'rgba(0, 0, 0, 0.3)',
                    boxShadow: isActive
                      ? AXIOM.shadows.iconCyan
                      : isCompleted
                      ? AXIOM.shadows.iconGreen
                      : 'none',
                  }}
                >
                  <Icon className="size-5 text-white" />
                </div>
                <div>
                  <div 
                    className="text-sm font-semibold"
                    style={{
                      color: isActive ? '#22d3ee' : isCompleted ? '#34d399' : AXIOM.text.slate400,
                    }}
                  >
                    {step.label}
                  </div>
                </div>
              </motion.div>
              {index < 3 && (
                <ArrowRight className="size-5 mx-2" style={{ color: AXIOM.text.slate400 }} />
              )}
            </div>
          );
        })}
      </motion.div>

      {/* Step Content */}
      <AnimatePresence mode="wait">
        {currentStep === 'upload' && (
          <motion.div
            key="upload"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            {/* Account Selection */}
            <div className="p-6 rounded-2xl" style={AXIOM.containers.list}>
              <h3 className="text-xl font-bold text-white mb-4">Select Bank Account</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {bankAccounts.map((account) => (
                  <motion.button
                    key={account.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedAccount(account.id)}
                    className="p-4 rounded-xl transition-all text-left"
                    style={{
                      background: selectedAccount === account.id
                        ? 'linear-gradient(135deg, rgba(6, 182, 212, 0.2), rgba(59, 130, 246, 0.2))'
                        : AXIOM.containers.item.background,
                      border: selectedAccount === account.id
                        ? '1px solid rgba(6, 182, 212, 0.5)'
                        : AXIOM.containers.item.border,
                    }}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div 
                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{
                          background: AXIOM.iconBoxes.blue,
                          boxShadow: AXIOM.shadows.iconBlue,
                        }}
                      >
                        <Building2 className="size-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="text-white font-semibold">{account.bankName}</div>
                        <div className="text-xs" style={{ color: AXIOM.text.slate400 }}>
                          {account.accountNumber}
                        </div>
                      </div>
                    </div>
                    <div className="text-lg font-bold text-cyan-400">
                      {formatCurrency(account.balance)}
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* File Upload */}
            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              className="p-12 rounded-2xl border-2 border-dashed text-center transition-all cursor-pointer"
              style={{
                background: dragActive 
                  ? 'rgba(6, 182, 212, 0.1)' 
                  : AXIOM.containers.list.background,
                borderColor: dragActive ? 'rgba(6, 182, 212, 0.5)' : 'rgba(148, 163, 184, 0.2)',
              }}
            >
              <input
                type="file"
                id="file-upload"
                className="hidden"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileInputChange}
              />
              <label htmlFor="file-upload" className="cursor-pointer">
                <div 
                  className="w-24 h-24 mx-auto mb-6 rounded-2xl flex items-center justify-center"
                  style={{
                    background: AXIOM.iconBoxes.cyan,
                    boxShadow: AXIOM.shadows.iconCyan,
                  }}
                >
                  <Upload className="size-12 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  {selectedFile ? selectedFile.name : 'Drop your statement file here'}
                </h3>
                <p className="text-slate-400 mb-6">or click to browse</p>
                <div className="flex items-center justify-center gap-4">
                  <span 
                    className="px-4 py-2 rounded-lg text-sm"
                    style={AXIOM.badges.info}
                  >
                    Supports CSV, XLSX
                  </span>
                </div>
              </label>
            </div>

            {selectedFile && !processing && (
              <div className="flex justify-end">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleFileSelected(selectedFile)}
                  disabled={!selectedAccount}
                  className="px-6 py-3 rounded-xl text-sm font-medium flex items-center gap-2"
                  style={{
                    background: selectedAccount
                      ? 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))'
                      : 'rgba(148, 163, 184, 0.1)',
                    border: selectedAccount
                      ? '1px solid rgba(6, 182, 212, 0.5)'
                      : '1px solid rgba(148, 163, 184, 0.2)',
                    boxShadow: selectedAccount ? '0 10px 30px -10px rgba(6, 182, 212, 0.6)' : 'none',
                    color: selectedAccount ? '#ffffff' : AXIOM.text.slate400,
                    opacity: selectedAccount ? 1 : 0.5,
                    cursor: selectedAccount ? 'pointer' : 'not-allowed',
                  }}
                >
                  Proceed to Mapping
                  <ArrowRight className="size-4" />
                </motion.button>
              </div>
            )}

            {processing && (
              <div className="flex items-center justify-center gap-3 py-8">
                <Loader2 className="size-6 text-cyan-400 animate-spin" />
                <span className="text-slate-400">Processing file...</span>
              </div>
            )}
          </motion.div>
        )}

        {currentStep === 'mapping' && (
          <motion.div
            key="mapping"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="p-6 rounded-2xl" style={AXIOM.containers.list}>
              <h3 className="text-xl font-bold text-white mb-2">Map CSV Columns</h3>
              <p className="text-sm text-slate-400 mb-6">
                We've auto-detected your columns. Please verify or adjust the mapping.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  { key: 'date', label: 'Date Column', required: true },
                  { key: 'amount', label: 'Amount Column', required: true },
                  { key: 'narration', label: 'Description/Narration Column', required: true },
                  { key: 'balance', label: 'Balance Column (Optional)', required: false },
                  { key: 'reference', label: 'Reference Column (Optional)', required: false },
                  { key: 'type', label: 'Type Column (Optional)', required: false },
                ].map((field) => (
                  <div key={field.key}>
                    <label className="block text-sm font-medium text-slate-400 mb-2">
                      {field.label}
                      {field.required && <span className="text-red-400 ml-1">*</span>}
                    </label>
                    <select
                      value={columnMapping[field.key as keyof ColumnMapping] || ''}
                      onChange={(e) => setColumnMapping({ ...columnMapping, [field.key]: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl text-white focus:outline-none transition-all"
                      style={{
                        background: AXIOM.inputs.background,
                        border: AXIOM.inputs.border,
                      }}
                    >
                      <option value="">Select column...</option>
                      {csvHeaders.map((header) => (
                        <option key={header} value={header}>
                          {header}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              <div 
                className="mt-6 p-4 rounded-xl"
                style={{
                  background: 'rgba(59, 130, 246, 0.1)',
                  border: '1px solid rgba(59, 130, 246, 0.3)',
                }}
              >
                <div className="flex items-start gap-3">
                  <Sparkles className="size-5 text-blue-400 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-blue-400 mb-1">Smart Detection</h4>
                    <p className="text-xs text-slate-400">
                      Our AI has automatically mapped your columns based on common patterns.
                      You can adjust them if needed.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setCurrentStep('upload')}
                className="px-6 py-3 rounded-xl text-sm font-medium"
                style={AXIOM.buttons.secondary}
              >
                Back
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleProceedToReview}
                disabled={!columnMapping.date || !columnMapping.amount || !columnMapping.narration}
                className="px-6 py-3 rounded-xl text-sm font-medium flex items-center gap-2"
                style={{
                  ...(columnMapping.date && columnMapping.amount && columnMapping.narration
                    ? {
                        background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                        border: '1px solid rgba(6, 182, 212, 0.5)',
                        boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
                        color: '#ffffff',
                      }
                    : {
                        background: 'rgba(148, 163, 184, 0.1)',
                        border: '1px solid rgba(148, 163, 184, 0.2)',
                        color: AXIOM.text.slate400,
                        opacity: 0.5,
                        cursor: 'not-allowed',
                      }),
                }}
              >
                Proceed to Review
                <ArrowRight className="size-4" />
              </motion.button>
            </div>
          </motion.div>
        )}

        {currentStep === 'review' && (
          <motion.div
            key="review"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-6 rounded-2xl" style={AXIOM.containers.list}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Total</p>
                    <p className="text-2xl font-bold text-white">{stats.total}</p>
                  </div>
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{
                      background: AXIOM.iconBoxes.purple,
                      boxShadow: AXIOM.shadows.iconPurple,
                    }}
                  >
                    <FileText className="size-6 text-white" />
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl" style={AXIOM.containers.list}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Auto-Classified</p>
                    <p className="text-2xl font-bold text-emerald-400">{stats.classified}</p>
                  </div>
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{
                      background: AXIOM.iconBoxes.green,
                      boxShadow: AXIOM.shadows.iconGreen,
                    }}
                  >
                    <CheckCircle2 className="size-6 text-white" />
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl" style={AXIOM.containers.list}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Duplicates</p>
                    <p className="text-2xl font-bold text-amber-400">{stats.duplicates}</p>
                  </div>
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{
                      background: AXIOM.iconBoxes.orange,
                      boxShadow: AXIOM.shadows.iconOrange,
                    }}
                  >
                    <AlertTriangle className="size-6 text-white" />
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-2xl" style={AXIOM.containers.list}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm mb-1">To Import</p>
                    <p className="text-2xl font-bold text-cyan-400">{filteredTransactions.length}</p>
                  </div>
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{
                      background: AXIOM.iconBoxes.cyan,
                      boxShadow: AXIOM.shadows.iconCyan,
                    }}
                  >
                    <Sparkles className="size-6 text-white" />
                  </div>
                </div>
              </div>
            </div>

            {/* Transaction List */}
            <div className="p-6 rounded-2xl" style={AXIOM.containers.list}>
              <h3 className="text-xl font-bold text-white mb-4">Transactions to Import</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredTransactions.slice(0, 10).map((txn, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="p-4 rounded-xl flex items-center justify-between"
                    style={AXIOM.containers.item}
                  >
                    <div className="flex-1">
                      <p className="text-white font-semibold">{txn.narration}</p>
                      <p className="text-sm text-slate-400">{formatDate(txn.date)}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${txn.amount > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {formatCurrency(txn.amount)}
                      </p>
                      {txn.confidence && (
                        <p className="text-xs text-slate-400">
                          {txn.confidence}% confidence
                        </p>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="flex justify-between">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setCurrentStep('mapping')}
                className="px-6 py-3 rounded-xl text-sm font-medium"
                style={AXIOM.buttons.secondary}
              >
                Back
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleImport}
                disabled={processing}
                className="px-6 py-3 rounded-xl text-sm font-medium flex items-center gap-2"
                style={{
                  background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                  border: '1px solid rgba(6, 182, 212, 0.5)',
                  boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
                  color: '#ffffff',
                }}
              >
                {processing ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    Import Transactions
                    <CheckCircle2 className="size-4" />
                  </>
                )}
              </motion.button>
            </div>
          </motion.div>
        )}

        {currentStep === 'complete' && (
          <motion.div
            key="complete"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="p-12 rounded-2xl text-center"
            style={AXIOM.containers.list}
          >
            <div 
              className="w-24 h-24 mx-auto mb-6 rounded-2xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.green,
                boxShadow: AXIOM.shadows.iconGreen,
              }}
            >
              <CheckCircle2 className="size-12 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Import Complete!</h2>
            <p className="text-slate-400 mb-8">
              Successfully imported {filteredTransactions.length} transactions
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setCurrentStep('upload');
                setSelectedFile(null);
                setParsedTransactions([]);
                setSelectedAccount('');
              }}
              className="px-6 py-3 rounded-xl text-sm font-medium"
              style={{
                background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                border: '1px solid rgba(6, 182, 212, 0.5)',
                boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
                color: '#ffffff',
              }}
            >
              Import Another File
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}