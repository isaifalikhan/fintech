import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';
import { Tabs, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';
import { Plus, DollarSign, TrendingUp, TrendingDown, Sparkles, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'motion/react';
import { useTheme } from '../../../contexts/ThemeContext';
import { AXIOM } from '../../../styles/axiom-tokens';

export function QuickAdd() {
  const { theme } = useTheme();
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [amount, setAmount] = useState('');
  const [narration, setNarration] = useState('');
  const [scope, setScope] = useState<'business' | 'personal'>('business');
  const [method, setMethod] = useState<'cash' | 'bank' | 'card'>('bank');
  const [currency, setCurrency] = useState('PKR');
  const [account, setAccount] = useState('');
  const [suggestedCategory, setSuggestedCategory] = useState<string | null>(null);

  const svc = useOrgServices();
  const { data: bankAccounts = [] } = useService(
    () => svc.accounts.getBankAccounts(),
    [svc.orgId]
  );

  const handleNarrationChange = (value: string) => {
    setNarration(value);
    
    // Mock AI category suggestion
    if (value.toLowerCase().includes('aws') || value.toLowerCase().includes('hosting')) {
      setSuggestedCategory('Software & Tools');
    } else if (value.toLowerCase().includes('salary') || value.toLowerCase().includes('payroll')) {
      setSuggestedCategory('Salaries & Wages');
    } else if (value.toLowerCase().includes('lunch') || value.toLowerCase().includes('dinner')) {
      setSuggestedCategory('Office Expenses');
    } else if (value.toLowerCase().includes('domain') || value.toLowerCase().includes('godaddy')) {
      setSuggestedCategory('Software & Tools');
    } else if (value.toLowerCase().includes('client') && type === 'income') {
      setSuggestedCategory('Revenue - Services');
    } else {
      setSuggestedCategory(null);
    }
  };

  const handleSubmit = () => {
    if (!amount || !narration) {
      toast.error('Please fill in amount and narration');
      return;
    }

    toast.success(`${type === 'income' ? 'Income' : 'Expense'} added successfully`, {
      description: `${currency} ${amount} - ${narration}`,
    });

    // Reset form
    setAmount('');
    setNarration('');
    setSuggestedCategory(null);
  };

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header with AXIOM Gradient */}
      <motion.div
        {...AXIOM.animations.fadeInTop}
      >
        <div className="flex items-center gap-3 mb-2">
          <div 
            className="p-3 rounded-xl flex items-center justify-center"
            style={{
              background: AXIOM.iconBoxes.cyan,
              boxShadow: AXIOM.shadows.iconCyan,
            }}
          >
            <Zap className="size-6 text-white" />
          </div>
          <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>Quick Add</h1>
        </div>
        <p className="text-slate-400 text-xs">Fast entry for income and expenses</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form - AXIOM Style */}
        <motion.div 
          className="lg:col-span-2"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div 
            className="p-8 rounded-3xl"
            style={AXIOM.containers.list}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{
                    background: AXIOM.iconBoxes.purple,
                    boxShadow: AXIOM.shadows.iconPurple,
                  }}
                >
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">Transaction Details</h2>
                  <p className="text-slate-400 text-sm">Enter income or expense</p>
                </div>
              </div>
              <div className="flex gap-2">
                <motion.button
                  {...AXIOM.animations.hoverScale}
                  onClick={() => setType('expense')}
                  className="px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2"
                  style={type === 'expense' ? AXIOM.buttons.danger : AXIOM.buttons.outline}
                >
                  <TrendingDown className="size-4" />
                  Expense
                </motion.button>
                <motion.button
                  {...AXIOM.animations.hoverScale}
                  onClick={() => setType('income')}
                  className="px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2"
                  style={type === 'income' ? AXIOM.buttons.success : AXIOM.buttons.outline}
                >
                  <TrendingUp className="size-4" />
                  Income
                </motion.button>
              </div>
            </div>

            <div className="space-y-5">
              {/* Amount */}
              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: AXIOM.text.slate300 }}>Amount</label>
                <div className="flex gap-2">
                  <select 
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="h-12 px-4 rounded-xl font-medium"
                    style={{
                      background: AXIOM.inputs.background,
                      border: AXIOM.inputs.border,
                      color: AXIOM.inputs.color,
                    }}
                  >
                    <option value="PKR">PKR</option>
                    <option value="USD">USD</option>
                    <option value="AED">AED</option>
                  </select>
                  <input
                    type="number"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="h-12 px-4 rounded-xl text-2xl font-bold flex-1"
                    style={{
                      background: AXIOM.inputs.background,
                      border: AXIOM.inputs.border,
                      color: AXIOM.inputs.color,
                    }}
                  />
                </div>
              </div>

              {/* Narration */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium" style={{ color: AXIOM.text.slate300 }}>Narration / Description</label>
                  {suggestedCategory && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="flex items-center gap-1"
                    >
                      <Sparkles className="size-3 text-cyan-400" />
                      <span className="text-xs text-cyan-400 font-medium">AI Suggestion</span>
                    </motion.div>
                  )}
                </div>
                <textarea
                  placeholder="e.g., AWS hosting services, Client payment for website, Team lunch..."
                  value={narration}
                  onChange={(e) => handleNarrationChange(e.target.value)}
                  className="w-full min-h-24 px-4 py-3 rounded-xl"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
                {suggestedCategory && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="inline-block px-3 py-1 rounded-lg text-xs font-medium"
                    style={AXIOM.badges.cyan}
                  >
                    Suggested: {suggestedCategory}
                  </motion.div>
                )}
              </div>

              {/* Scope */}
              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: AXIOM.text.slate300 }}>Scope</label>
                <div className="flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    type="button"
                    onClick={() => setScope('business')}
                    className="px-4 py-3 rounded-xl text-sm font-medium flex-1"
                    style={scope === 'business' ? {
                      background: 'rgba(168, 85, 247, 0.3)',
                      border: '1px solid rgba(168, 85, 247, 0.5)',
                      color: '#ffffff',
                    } : {
                      background: 'rgba(0, 0, 0, 0.2)',
                      border: 'none',
                      color: 'rgba(148, 163, 184, 0.7)',
                    }}
                  >
                    Business
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    type="button"
                    onClick={() => setScope('personal')}
                    className="px-4 py-3 rounded-xl text-sm font-medium flex-1"
                    style={scope === 'personal' ? {
                      background: 'rgba(168, 85, 247, 0.3)',
                      border: '1px solid rgba(168, 85, 247, 0.5)',
                      color: '#ffffff',
                    } : {
                      background: 'rgba(0, 0, 0, 0.2)',
                      border: 'none',
                      color: 'rgba(148, 163, 184, 0.7)',
                    }}
                  >
                    Personal
                  </motion.button>
                </div>
              </div>

              {/* Payment Method */}
              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: AXIOM.text.slate300 }}>Payment Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['cash', 'bank', 'card'] as const).map((m) => (
                    <motion.button
                      key={m}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      type="button"
                      onClick={() => setMethod(m)}
                      className="px-4 py-3 rounded-xl text-sm font-medium"
                      style={method === m ? {
                        background: 'rgba(168, 85, 247, 0.3)',
                        border: '1px solid rgba(168, 85, 247, 0.5)',
                        color: '#ffffff',
                      } : {
                        background: 'rgba(0, 0, 0, 0.2)',
                        border: 'none',
                        color: 'rgba(148, 163, 184, 0.7)',
                      }}
                    >
                      {m.charAt(0).toUpperCase() + m.slice(1)}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Account Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: AXIOM.text.slate300 }}>Account</label>
                <select 
                  value={account}
                  onChange={(e) => setAccount(e.target.value)}
                  className="w-full h-12 px-4 rounded-xl"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                >
                  {bankAccounts
                    .filter(acc => {
                      // Filter by payment method — BankAccount doesn't have scope
                      if (method === 'cash') return false; // no cash accounts in BankAccount
                      if (method === 'card') return acc.accountType === 'credit';
                      // 'bank' → everything except credit
                      return acc.accountType !== 'credit';
                    })
                    .map(acc => (
                      <option key={acc.id} value={acc.id}>
                        {acc.accountName} - {acc.currency}
                      </option>
                    ))}
                </select>
              </div>

              {/* Submit */}
              <motion.button
                {...AXIOM.animations.hoverScaleSmall}
                className="w-full h-14 rounded-xl text-base font-bold flex items-center justify-center gap-2 mt-6"
                onClick={handleSubmit}
                style={AXIOM.buttons.action}
              >
                <Plus className="size-5" />
                Add {type === 'income' ? 'Income' : 'Expense'}
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Recent Transactions - AXIOM Style */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="p-6 rounded-3xl"
            style={AXIOM.containers.list}
          >
            <h3 className="text-lg font-bold text-white mb-4">Recent Entries</h3>
            <div className="space-y-2">
              {[
                { narration: 'AWS hosting', amount: 45000, type: 'expense', time: '2 mins ago' },
                { narration: 'Client payment', amount: 150000, type: 'income', time: '1 hour ago' },
                { narration: 'Team lunch', amount: 8000, type: 'expense', time: '3 hours ago' },
              ].map((txn, idx) => (
                <motion.div 
                  key={idx} 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + idx * 0.1 }}
                  className="p-3 rounded-xl"
                  style={AXIOM.containers.item}
                >
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm text-white font-medium">{txn.narration}</p>
                    <div 
                      className="px-2 py-1 rounded text-xs font-bold"
                      style={txn.type === 'income' ? AXIOM.badges.success : AXIOM.badges.danger}
                    >
                      {txn.type === 'income' ? '+' : '-'}Rs {txn.amount.toLocaleString()}
                    </div>
                  </div>
                  <p className="text-xs" style={{ color: AXIOM.text.slate400 }}>{txn.time}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Pro Tips - AXIOM Style */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="p-6 rounded-3xl relative overflow-hidden"
            style={AXIOM.containers.chartCyan}
          >
            <div 
              className="absolute inset-0"
              style={{ background: AXIOM.radialOverlays.cyan }}
            />
            
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="size-5 text-cyan-400" />
                <h3 className="text-lg font-bold text-white">Pro Tips</h3>
              </div>
              <div className="space-y-2 text-sm" style={{ color: AXIOM.text.slate300 }}>
                <p className="flex items-start gap-2">
                  <span className="text-cyan-400 mt-0.5">•</span>
                  <span>Be descriptive in narration for better AI categorization</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="text-cyan-400 mt-0.5">•</span>
                  <span>The system learns from your corrections</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="text-cyan-400 mt-0.5">•</span>
                  <span>Date/time is auto-filled if not specified</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="text-cyan-400 mt-0.5">•</span>
                  <span>Cash withdrawals auto-update Cash in Hand</span>
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}