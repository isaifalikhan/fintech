import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { useTheme } from '@/contexts/ThemeContext';
import { motion } from 'motion/react';
import {
  Brain,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  Target,
  Users,
  DollarSign,
  Briefcase,
  PieChart,
  Activity
} from 'lucide-react';

import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';

interface AIInsight {
  id: string;
  type: 'warning' | 'opportunity' | 'success' | 'info';
  category: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  actionable: boolean;
  recommendation?: string;
}

interface FinancialPattern {
  id: string;
  pattern: string;
  frequency: string;
  trend: 'increasing' | 'decreasing' | 'stable';
  suggestion: string;
}

export function AIFinancialAssistant() {
  const { theme } = useTheme();
  const aiInsights: AIInsight[] = [
    {
      id: '1',
      type: 'warning',
      category: 'Personal vs Business',
      title: 'High Personal Expense Ratio Detected',
      description: 'You\'re drawing 42% of business revenue as personal expenses. Industry standard for agencies is 15-25%.',
      impact: 'high',
      actionable: true,
      recommendation: 'Consider reducing personal drawings to PKR 180,000/month to maintain healthy cash flow.'
    }
  ];

  const financialPatterns: FinancialPattern[] = [
    {
      id: '1',
      pattern: 'Peak Revenue Months',
      frequency: 'Q4 (Oct-Dec)',
      trend: 'increasing',
      suggestion: 'Your revenue increases 35% in Q4. Plan for increased hiring/expenses in Q3 to capture demand.'
    },
    {
      id: '2',
      pattern: 'Cash Withdrawal Pattern',
      frequency: 'Every 15th of month',
      trend: 'stable',
      suggestion: 'You consistently withdraw PKR 150,000 on the 15th. Set up automated transfer for better planning.'
    },
    {
      id: '3',
      pattern: 'Client Payment Delays',
      frequency: 'Average 18 days',
      trend: 'increasing',
      suggestion: 'Payment delays increasing by 3 days/quarter. Implement stricter payment terms or advance billing.'
    },
    {
      id: '4',
      pattern: 'Office Expense Spike',
      frequency: 'January & July',
      trend: 'stable',
      suggestion: 'Office expenses spike in Jan (utilities) and July (maintenance). Budget extra PKR 40,000 for these months.'
    }
  ];

  const currentSituation = {
    cashPosition: 'healthy',
    burnRate: 'PKR 420,000/month',
    runway: '8.5 months',
    profitMargin: '32%',
    personalDrawings: '42% of revenue (too high)',
    teamUtilization: '78%'
  };

  const futureProjections = {
    nextQuarter: {
      revenue: 'PKR 1.85M',
      profit: 'PKR 580K',
      confidence: 85
    },
    nextYear: {
      revenue: 'PKR 7.2M',
      profit: 'PKR 2.3M',
      confidence: 72
    }
  };

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: '#0a0a0a' }}>
      {/* Header with Dashboard Gradient */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center gap-3 mb-2">
          <div 
            className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center"
            style={{ boxShadow: '0 10px 30px -10px rgba(168, 85, 247, 0.6)' }}
          >
            <Brain className="size-6 text-white" />
          </div>
          <h1 className="text-4xl font-bold" style={{
            background: 'linear-gradient(135deg, #ffffff 0%, #a855f7 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}>AI Financial Assistant</h1>
        </div>
        <p className="text-slate-400 text-xs">Pattern recognition, insights, and intelligent recommendations</p>
      </motion.div>

      {/* Current Situation - Dashboard Style */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="p-8 rounded-3xl relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, rgba(30, 15, 50, 0.6) 0%, rgba(10, 5, 20, 0.8) 100%)',
          border: '1px solid rgba(6, 182, 212, 0.2)',
          boxShadow: '0 20px 60px -20px rgba(6, 182, 212, 0.5)',
        }}
      >
        <div 
          className="absolute inset-0 opacity-40"
          style={{
            background: 'radial-gradient(circle at 50% 50%, rgba(6, 182, 212, 0.3), transparent 70%)',
          }}
        />
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <div 
              className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center"
              style={{ boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)' }}
            >
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Current Financial Situation</h2>
              <p className="text-slate-400 text-sm">AI-powered analysis of your business health</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="p-4 rounded-2xl"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-400">Cash Position</span>
                <CheckCircle2 className="size-4 text-green-400" />
              </div>
              <p className="font-bold text-white text-xl capitalize">{currentSituation.cashPosition}</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.25 }}
              className="p-4 rounded-2xl"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-400">Monthly Burn Rate</span>
                <TrendingDown className="size-4 text-orange-400" />
              </div>
              <p className="font-bold text-white text-xl">{currentSituation.burnRate}</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="p-4 rounded-2xl"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-400">Runway</span>
                <Target className="size-4 text-cyan-400" />
              </div>
              <p className="font-bold text-white text-xl">{currentSituation.runway}</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.35 }}
              className="p-4 rounded-2xl"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-400">Profit Margin</span>
                <TrendingUp className="size-4 text-green-400" />
              </div>
              <p className="font-bold text-white text-xl">{currentSituation.profitMargin}</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="p-4 rounded-2xl"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-400">Personal Drawings</span>
                <AlertTriangle className="size-4 text-red-400" />
              </div>
              <p className="font-bold text-white text-xl">{currentSituation.personalDrawings}</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.45 }}
              className="p-4 rounded-2xl"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-400">Team Utilization</span>
                <Users className="size-4 text-blue-400" />
              </div>
              <p className="font-bold text-white text-xl">{currentSituation.teamUtilization}</p>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Future Projections - Dashboard Style */}
      <div className="grid md:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="p-8 rounded-3xl relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(30, 15, 50, 0.6) 0%, rgba(10, 5, 20, 0.8) 100%)',
            border: '1px solid rgba(16, 185, 129, 0.2)',
            boxShadow: '0 20px 60px -20px rgba(16, 185, 129, 0.5)',
          }}
        >
          <div 
            className="absolute inset-0 opacity-40"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(16, 185, 129, 0.3), transparent 70%)',
            }}
          />
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
              <div 
                className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-green-500 flex items-center justify-center"
                style={{ boxShadow: '0 10px 30px -10px rgba(16, 185, 129, 0.6)' }}
              >
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">Next Quarter Projection</h2>
                <p className="text-slate-400 text-sm">AI-powered forecast based on patterns</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-2xl" style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}>
                <div className="text-xs text-slate-400 mb-2">Expected Revenue</div>
                <p className="text-3xl font-bold text-white mb-3">{futureProjections.nextQuarter.revenue}</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-slate-800 rounded-full h-2">
                    <motion.div 
                      className="bg-gradient-to-r from-emerald-500 to-green-500 h-2 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${futureProjections.nextQuarter.confidence}%` }}
                      transition={{ duration: 1.5, delay: 0.7 }}
                      style={{ boxShadow: '0 0 10px rgba(16, 185, 129, 0.6)' }}
                    />
                  </div>
                  <span className="text-xs text-slate-400">{futureProjections.nextQuarter.confidence}% confidence</span>
                </div>
              </div>
              <div className="p-4 bg-green-600/20 border border-green-500/30 rounded-2xl">
                <div className="text-xs text-green-400 mb-2">Expected Profit</div>
                <p className="text-3xl font-bold text-white">{futureProjections.nextQuarter.profit}</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="p-8 rounded-3xl relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(30, 15, 50, 0.6) 0%, rgba(10, 5, 20, 0.8) 100%)',
            border: '1px solid rgba(59, 130, 246, 0.2)',
            boxShadow: '0 20px 60px -20px rgba(59, 130, 246, 0.5)',
          }}
        >
          <div 
            className="absolute inset-0 opacity-40"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(59, 130, 246, 0.3), transparent 70%)',
            }}
          />
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
              <div 
                className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center"
                style={{ boxShadow: '0 10px 30px -10px rgba(59, 130, 246, 0.6)' }}
              >
                <Target className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">Next Year Projection</h2>
                <p className="text-slate-400 text-sm">Long-term forecast</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-2xl" style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}>
                <div className="text-xs text-slate-400 mb-2">Expected Revenue</div>
                <p className="text-3xl font-bold text-white mb-3">{futureProjections.nextYear.revenue}</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-slate-800 rounded-full h-2">
                    <motion.div 
                      className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${futureProjections.nextYear.confidence}%` }}
                      transition={{ duration: 1.5, delay: 0.8 }}
                      style={{ boxShadow: '0 0 10px rgba(59, 130, 246, 0.6)' }}
                    />
                  </div>
                  <span className="text-xs text-slate-400">{futureProjections.nextYear.confidence}% confidence</span>
                </div>
              </div>
              <div className="p-4 bg-blue-600/20 border border-blue-500/30 rounded-2xl">
                <div className="text-xs text-blue-400 mb-2">Expected Profit</div>
                <p className="text-3xl font-bold text-white">{futureProjections.nextYear.profit}</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* AI Insights - Dashboard Style */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="p-8 rounded-3xl"
        style={{
          background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.5) 0%, rgba(0, 0, 0, 0.3) 100%)',
          border: '1px solid rgba(148, 163, 184, 0.1)',
          boxShadow: '0 20px 60px -20px rgba(0, 0, 0, 0.8)',
        }}
      >
        <div className="flex items-center gap-3 mb-6">
          <div 
            className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-500 to-amber-500 flex items-center justify-center"
            style={{ boxShadow: '0 10px 30px -10px rgba(245, 158, 11, 0.6)' }}
          >
            <Lightbulb className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">AI-Generated Insights & Recommendations</h2>
            <p className="text-slate-400 text-sm">Actionable intelligence from your financial data</p>
          </div>
        </div>

        <div className="space-y-3">
          {aiInsights.map((insight, idx) => (
            <motion.div
              key={insight.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.8 + idx * 0.1 }}
              className={`p-5 rounded-2xl border ${
                insight.type === 'warning'
                  ? 'bg-red-900/10 border-red-600/30'
                  : insight.type === 'opportunity'
                  ? 'bg-cyan-900/10 border-cyan-600/30'
                  : insight.type === 'success'
                  ? 'bg-green-900/10 border-green-600/30'
                  : 'bg-blue-900/10 border-blue-600/30'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-start gap-3 flex-1">
                  <div className={`p-2 rounded-lg ${
                    insight.type === 'warning'
                      ? 'bg-red-600/20'
                      : insight.type === 'opportunity'
                      ? 'bg-cyan-600/20'
                      : insight.type === 'success'
                      ? 'bg-green-600/20'
                      : 'bg-blue-600/20'
                  }`}>
                    {insight.type === 'warning' && <AlertTriangle className="size-4 text-red-400" />}
                    {insight.type === 'opportunity' && <TrendingUp className="size-4 text-cyan-400" />}
                    {insight.type === 'success' && <CheckCircle2 className="size-4 text-green-400" />}
                    {insight.type === 'info' && <Brain className="size-4 text-blue-400" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-white">{insight.title}</h3>
                      <div className="px-2 py-1 rounded text-xs text-slate-300 border border-slate-600">
                        {insight.category}
                      </div>
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        insight.impact === 'high' 
                          ? 'bg-red-500/20 text-red-300 border border-red-400/30' 
                          : insight.impact === 'medium' 
                          ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-400/30' 
                          : 'bg-blue-500/20 text-blue-300 border border-blue-400/30'
                      }`}>
                        {insight.impact} impact
                      </div>
                    </div>
                    <p className="text-sm text-slate-300 mb-2">{insight.description}</p>
                    {insight.recommendation && (
                      <div className={`p-3 rounded-lg mt-2 ${
                        insight.type === 'warning'
                          ? 'bg-red-950/50'
                          : insight.type === 'opportunity'
                          ? 'bg-cyan-950/50'
                          : 'bg-green-950/50'
                      }`}>
                        <div className={`text-xs mb-1 ${
                          insight.type === 'warning'
                            ? 'text-red-400'
                            : insight.type === 'opportunity'
                            ? 'text-cyan-400'
                            : 'text-green-400'
                        }`}>
                          💡 AI Recommendation
                        </div>
                        <p className="text-sm text-white">{insight.recommendation}</p>
                      </div>
                    )}
                  </div>
                </div>
                {insight.actionable && (
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-4 py-2 rounded-lg text-sm font-medium text-white ml-4"
                    style={{
                      background: 'linear-gradient(135deg, rgba(168, 85, 247, 0.3), rgba(236, 72, 153, 0.3))',
                      border: '1px solid rgba(168, 85, 247, 0.5)',
                    }}
                  >
                    Take Action
                  </motion.button>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Financial Patterns - Dashboard Style */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9 }}
        className="p-8 rounded-3xl"
        style={{
          background: 'linear-gradient(135deg, rgba(15, 23, 42, 0.5) 0%, rgba(0, 0, 0, 0.3) 100%)',
          border: '1px solid rgba(148, 163, 184, 0.1)',
          boxShadow: '0 20px 60px -20px rgba(0, 0, 0, 0.8)',
        }}
      >
        <div className="flex items-center gap-3 mb-6">
          <div 
            className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center"
            style={{ boxShadow: '0 10px 30px -10px rgba(168, 85, 247, 0.6)' }}
          >
            <PieChart className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Detected Financial Patterns</h2>
            <p className="text-slate-400 text-sm">AI learns your business rhythm</p>
          </div>
        </div>

        <div className="space-y-3">
          {financialPatterns.map((pattern, idx) => (
            <motion.div 
              key={pattern.id} 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1.0 + idx * 0.1 }}
              className="p-5 rounded-2xl"
              style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(148, 163, 184, 0.1)',
              }}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-white">{pattern.pattern}</h3>
                    <div className={`px-2 py-1 rounded text-xs font-medium flex items-center gap-1 ${
                      pattern.trend === 'increasing' 
                        ? 'bg-green-500/20 text-green-300 border border-green-400/30' 
                        : pattern.trend === 'decreasing' 
                        ? 'bg-red-500/20 text-red-300 border border-red-400/30' 
                        : 'bg-blue-500/20 text-blue-300 border border-blue-400/30'
                    }`}>
                      {pattern.trend === 'increasing' && <TrendingUp className="size-3" />}
                      {pattern.trend === 'decreasing' && <TrendingDown className="size-3" />}
                      {pattern.trend}
                    </div>
                  </div>
                  <p className="text-sm text-slate-400 mb-2">Occurs: {pattern.frequency}</p>
                  <div className="p-3 bg-purple-900/20 rounded-lg border border-purple-600/30">
                    <p className="text-sm text-purple-300">{pattern.suggestion}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* How AI Works - Dashboard Style */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.1 }}
        className="p-8 rounded-3xl relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, rgba(30, 15, 50, 0.6) 0%, rgba(10, 5, 20, 0.8) 100%)',
          border: '1px solid rgba(168, 85, 247, 0.2)',
          boxShadow: '0 20px 60px -20px rgba(168, 85, 247, 0.5)',
        }}
      >
        <div 
          className="absolute inset-0 opacity-40"
          style={{
            background: 'radial-gradient(circle at 50% 50%, rgba(139, 92, 246, 0.3), transparent 70%)',
          }}
        />
        
        <div className="relative z-10">
          <div className="flex items-start gap-4">
            <div 
              className="p-3 rounded-xl bg-purple-600/20"
              style={{ border: '1px solid rgba(168, 85, 247, 0.3)' }}
            >
              <Brain className="size-6 text-purple-400" />
            </div>
            <div>
              <h3 className="font-semibold text-white mb-3 text-xl">How AI Financial Assistant Works</h3>
              <ul className="space-y-3 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-0.5 font-bold">•</span>
                  <span><strong className="text-white">Pattern Recognition:</strong> Analyzes your spending, revenue, and timing patterns</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-0.5 font-bold">•</span>
                  <span><strong className="text-white">Benchmarking:</strong> Compares your metrics against industry standards</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-0.5 font-bold">•</span>
                  <span><strong className="text-white">Predictive Analytics:</strong> Forecasts future scenarios based on historical data</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-0.5 font-bold">•</span>
                  <span><strong className="text-white">Proactive Alerts:</strong> Warns you before problems become critical</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-400 mt-0.5 font-bold">•</span>
                  <span><strong className="text-white">Continuous Learning:</strong> Gets smarter as you use the system more</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}