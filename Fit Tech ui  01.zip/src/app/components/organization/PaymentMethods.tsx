import { useState } from 'react';
import { motion } from 'motion/react';
import { CreditCard, Building2, Plus, Trash2, Pencil, CheckCircle2, Wallet, DollarSign } from 'lucide-react';
import { useTheme } from '../../../contexts/ThemeContext';
import { AXIOM } from '../../../styles/axiom-tokens';
import { toast } from 'sonner';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';

interface Card {
  id: string;
  name: string;
  type: 'Visa' | 'Mastercard' | 'Amex' | 'Other';
  lastFour: string;
  isDefault: boolean;
  currency: string;
}

interface BankAccount {
  id: string;
  name: string;
  accountNumber: string;
  bankName: string;
  currency: string;
  isDefault: boolean;
  isIntegrated: boolean;
}

export function PaymentMethods() {
  const { theme } = useTheme();
  const svc = useOrgServices();

  // Service-backed: load bank accounts from accountService
  const { data: serviceAccounts } = useService(
    () => svc.accounts.getBankAccounts(),
    []
  );

  const [cards, setCards] = useState<Card[]>([
    { id: '1', name: 'Business Visa', type: 'Visa', lastFour: '4532', isDefault: true, currency: 'PKR' },
    { id: '2', name: 'Personal Mastercard', type: 'Mastercard', lastFour: '8976', isDefault: false, currency: 'USD' },
  ]);

  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([
    { id: '1', name: 'Meezan Bank Business', accountNumber: 'PK45MEZN****1234', bankName: 'Meezan Bank', currency: 'PKR', isDefault: true, isIntegrated: false },
    { id: '2', name: 'HBL USD Account', accountNumber: 'PK88HABB****5678', bankName: 'HBL', currency: 'USD', isDefault: false, isIntegrated: false },
  ]);

  const [isAddingCard, setIsAddingCard] = useState(false);
  const [isAddingBank, setIsAddingBank] = useState(false);

  const handleDeleteCard = (id: string) => {
    setCards(cards.filter(c => c.id !== id));
    toast.success('Card removed successfully');
  };

  const handleDeleteBank = (id: string) => {
    setBankAccounts(bankAccounts.filter(b => b.id !== id));
    toast.success('Bank account removed successfully');
  };

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <CreditCard className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>Payment Methods</h1>
              <p className="text-slate-400 text-sm">Manage your cards and bank accounts for expense tracking</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Cards</p>
              <p className="text-2xl font-bold text-white">{cards.length}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <CreditCard className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Bank Accounts</p>
              <p className="text-2xl font-bold text-white">{bankAccounts.length}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.blue,
                boxShadow: AXIOM.shadows.iconBlue,
              }}
            >
              <Building2 className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Methods</p>
              <p className="text-2xl font-bold text-white">{cards.length + bankAccounts.length}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Wallet className="size-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Cards Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="p-6 rounded-2xl"
        style={AXIOM.containers.list}
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white mb-1">Cards</h2>
            <p className="text-sm" style={{ color: AXIOM.text.slate400 }}>Credit and debit cards for expenses</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
            style={{
              background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
              border: '1px solid rgba(6, 182, 212, 0.5)',
              boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
              color: '#ffffff',
            }}
            onClick={() => toast.info('Add Card feature coming soon')}
          >
            <Plus className="size-4" />
            Add Card
          </motion.button>
        </div>

        <div className="space-y-3">
          {cards.map((card, idx) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + idx * 0.05 }}
              className="p-4 rounded-xl flex items-center justify-between group"
              style={AXIOM.containers.item}
            >
              <div className="flex items-center gap-4">
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{
                    background: AXIOM.iconBoxes.cyan,
                    boxShadow: AXIOM.shadows.iconCyan,
                  }}
                >
                  <CreditCard className="size-6 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-white">{card.name}</h3>
                    {card.isDefault && (
                      <span 
                        className="px-2 py-0.5 rounded-lg text-xs font-medium flex items-center gap-1"
                        style={AXIOM.badges.success}
                      >
                        <CheckCircle2 className="size-3" />
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-mono" style={{ color: AXIOM.text.slate400 }}>
                    {card.type} •••• {card.lastFour} • {card.currency}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{
                    background: 'rgba(0, 0, 0, 0.2)',
                    color: AXIOM.text.slate400,
                  }}
                  onClick={() => toast.info('Edit feature coming soon')}
                >
                  <Pencil className="size-4" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{
                    background: 'rgba(0, 0, 0, 0.2)',
                    color: '#ef4444',
                  }}
                  onClick={() => handleDeleteCard(card.id)}
                >
                  <Trash2 className="size-4" />
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Bank Accounts Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        className="p-6 rounded-2xl"
        style={AXIOM.containers.list}
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white mb-1">Bank Accounts</h2>
            <p className="text-sm" style={{ color: AXIOM.text.slate400 }}>Link or add bank accounts for transactions</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
            style={{
              background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
              border: '1px solid rgba(6, 182, 212, 0.5)',
              boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
              color: '#ffffff',
            }}
            onClick={() => toast.info('Add Bank Account feature coming soon')}
          >
            <Plus className="size-4" />
            Add Bank Account
          </motion.button>
        </div>

        <div className="space-y-3">
          {bankAccounts.map((account, idx) => (
            <motion.div
              key={account.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + idx * 0.05 }}
              className="p-4 rounded-xl flex items-center justify-between group"
              style={AXIOM.containers.item}
            >
              <div className="flex items-center gap-4">
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{
                    background: AXIOM.iconBoxes.blue,
                    boxShadow: AXIOM.shadows.iconBlue,
                  }}
                >
                  <Building2 className="size-6 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-white">{account.name}</h3>
                    {account.isDefault && (
                      <span 
                        className="px-2 py-0.5 rounded-lg text-xs font-medium flex items-center gap-1"
                        style={AXIOM.badges.success}
                      >
                        <CheckCircle2 className="size-3" />
                        Default
                      </span>
                    )}
                    {account.isIntegrated && (
                      <span 
                        className="px-2 py-0.5 rounded-lg text-xs font-medium"
                        style={AXIOM.badges.info}
                      >
                        Integrated
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-mono" style={{ color: AXIOM.text.slate400 }}>
                    {account.bankName} • {account.accountNumber} • {account.currency}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{
                    background: 'rgba(0, 0, 0, 0.2)',
                    color: AXIOM.text.slate400,
                  }}
                  onClick={() => toast.info('Edit feature coming soon')}
                >
                  <Pencil className="size-4" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{
                    background: 'rgba(0, 0, 0, 0.2)',
                    color: '#ef4444',
                  }}
                  onClick={() => handleDeleteBank(account.id)}
                >
                  <Trash2 className="size-4" />
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Integration Tip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-4 p-4 rounded-xl"
          style={{
            background: 'rgba(59, 130, 246, 0.1)',
            border: '1px solid rgba(59, 130, 246, 0.2)',
          }}
        >
          <p className="text-sm text-blue-400 flex items-start gap-2">
            <span>💡</span>
            <span>
              Tip: You can integrate bank accounts from Integrations settings for automatic statement imports and real-time balance updates.
            </span>
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}