import { useState } from 'react';
import { OrganizationLayout } from './OrganizationLayout';
import { FinanceOSView } from './FinanceOSView';
import { OrgDashboard } from './OrgDashboard';
import { QuickAdd } from './QuickAdd';
import { TransactionsLedger } from './TransactionsLedger';
import { AccountsWallets } from './AccountsWallets';
import { PaymentMethods } from './PaymentMethods';
import { EnhancedStatementImport } from './EnhancedStatementImport';
import { EnhancedLogicLearning } from './EnhancedLogicLearning';
import { AIFinancialAssistant } from './AIFinancialAssistant';
import { CostingPricing } from './CostingPricing';
import { ReportsView } from './ReportsView';
import { LoansView } from './LoansView';
import { TeamPermissions } from './TeamPermissions';
import { OrgSettings } from './OrgSettings';
import { IntegrationsSettings } from './IntegrationsSettings';
import { RecurringTransactions } from './RecurringTransactions';
import { BudgetPlanning } from './BudgetPlanning';
import { CashFlowForecast } from './CashFlowForecast';
import { ProjectProfitability } from './ProjectProfitability';
import { WhatIfSimulator } from './WhatIfSimulator';
import { ProfitIntelligenceView } from './ProfitIntelligenceView';
import { AssetsDepreciationView } from './AssetsDepreciationView';
import { InventoryManagementView } from './InventoryManagementView';
import { ActiveSessionsView } from './ActiveSessionsView';
import { AuditLogView } from './AuditLogView';

export type OrgView = 
  | 'finance-os'
  | 'dashboard' 
  | 'quick-add'
  | 'transactions' 
  | 'recurring'
  | 'accounts'
  | 'payment-methods'
  | 'import' 
  | 'logic'
  | 'ai-assistant'
  | 'profit-intelligence'
  | 'budgets'
  | 'forecast'
  | 'projects'
  | 'simulator'
  | 'costing' 
  | 'reports' 
  | 'loans' 
  | 'assets'
  | 'inventory'
  | 'team' 
  | 'settings'
  | 'integrations'
  | 'active-sessions'
  | 'audit-log';

export function OrganizationWorkspace() {
  const [currentView, setCurrentView] = useState<OrgView>('finance-os');

  const renderView = () => {
    switch (currentView) {
      case 'finance-os':
        return <OrgDashboard />;
      case 'dashboard':
        return <FinanceOSView />;
      case 'quick-add':
        return <QuickAdd />;
      case 'transactions':
        return <TransactionsLedger />;
      case 'recurring':
        return <RecurringTransactions />;
      case 'accounts':
        return <AccountsWallets />;
      case 'payment-methods':
        return <PaymentMethods />;
      case 'import':
        return <EnhancedStatementImport />;
      case 'logic':
        return <EnhancedLogicLearning />;
      case 'ai-assistant':
        return <AIFinancialAssistant />;
      case 'profit-intelligence':
        return <ProfitIntelligenceView />;
      case 'budgets':
        return <BudgetPlanning />;
      case 'forecast':
        return <CashFlowForecast />;
      case 'projects':
        return <ProjectProfitability />;
      case 'simulator':
        return <WhatIfSimulator />;
      case 'costing':
        return <CostingPricing />;
      case 'reports':
        return <ReportsView />;
      case 'loans':
        return <LoansView />;
      case 'assets':
        return <AssetsDepreciationView />;
      case 'inventory':
        return <InventoryManagementView />;
      case 'team':
        return <TeamPermissions />;
      case 'settings':
        return <OrgSettings />;
      case 'integrations':
        return <IntegrationsSettings />;
      case 'active-sessions':
        return <ActiveSessionsView />;
      case 'audit-log':
        return <AuditLogView />;
      default:
        return <OrgDashboard />;
    }
  };

  return (
    <OrganizationLayout currentView={currentView} onViewChange={setCurrentView}>
      {renderView()}
    </OrganizationLayout>
  );
}