import { useState } from 'react';
import { motion } from 'motion/react';
import { Landmark, TrendingUp, TrendingDown, DollarSign, Wallet, Clock, AlertCircle, CheckCircle, FileText, ArrowUpRight, ArrowDownRight, Search, Edit, Trash2, Plus, Download, PieChart as PieChartIcon } from 'lucide-react';
import { BarChart, Bar, PieChart as RePieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { toast } from 'sonner';
import { AXIOM } from '../../../styles/axiom-tokens';
import { formatCurrency, formatDate } from '@/lib/formatters';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';

type LoanStatus = 'active' | 'pending' | 'overdue' | 'partially_paid' | 'paid' | 'defaulted';
type LoanView = 'overview' | 'to-receive' | 'to-pay' | 'analytics';

interface Loan {
  id: string;
  type: 'to_receive' | 'to_pay';
  party: string;
  amount: number;
  currency: string;
  principal: number;
  interestRate?: number;
  totalInterest?: number;
  amountPaid?: number;
  remainingBalance?: number;
  dueDate: string;
  startDate?: string;
  status: string;
  description: string;
  installmentAmount?: number;
  frequency?: 'monthly' | 'quarterly' | 'annual';
  nextPaymentDate?: string;
  paymentsCount?: number;
  paymentsCompleted?: number;
}

// Enhanced mock data
const enhancedLoans: Loan[] = [
  {
    id: 'loan-1',
    type: 'to_receive',
    party: 'ABC Corp',
    amount: 150000,
    principal: 150000,
    amountPaid: 0,
    remainingBalance: 150000,
    currency: 'USD',
    dueDate: '2026-02-15',
    startDate: '2025-12-01',
    status: 'pending',
    description: 'Short-term business loan',
    interestRate: 8.5,
    totalInterest: 12750,
    frequency: 'monthly',
    installmentAmount: 25000,
    paymentsCount: 6,
    paymentsCompleted: 0,
    nextPaymentDate: '2026-02-15',
  },
  {
    id: 'loan-2',
    type: 'to_pay',
    party: 'XYZ Bank',
    amount: 500000,
    principal: 450000,
    amountPaid: 180000,
    remainingBalance: 320000,
    currency: 'USD',
    dueDate: '2028-06-30',
    startDate: '2024-06-01',
    status: 'partially_paid',
    description: 'Equipment financing',
    interestRate: 6.5,
    totalInterest: 50000,
    frequency: 'monthly',
    installmentAmount: 10416,
    paymentsCount: 48,
    paymentsCompleted: 18,
    nextPaymentDate: '2026-03-01',
  },
  {
    id: 'loan-3',
    type: 'to_receive',
    party: 'Client - Tech Solutions',
    amount: 75000,
    principal: 75000,
    amountPaid: 0,
    remainingBalance: 75000,
    currency: 'USD',
    dueDate: '2026-01-20',
    startDate: '2025-11-20',
    status: 'overdue',
    description: 'Outstanding invoice payment',
    interestRate: 0,
    totalInterest: 0,
  },
  {
    id: 'loan-4',
    type: 'to_pay',
    party: 'Metro Credit Union',
    amount: 250000,
    principal: 250000,
    amountPaid: 62500,
    remainingBalance: 187500,
    currency: 'USD',
    dueDate: '2027-12-31',
    startDate: '2025-01-01',
    status: 'active',
    description: 'Working capital loan',
    interestRate: 7.25,
    totalInterest: 18125,
    frequency: 'quarterly',
    installmentAmount: 21875,
    paymentsCount: 12,
    paymentsCompleted: 3,
    nextPaymentDate: '2026-04-01',
  },
  {
    id: 'loan-5',
    type: 'to_receive',
    party: 'Partner Company Ltd',
    amount: 200000,
    principal: 200000,
    amountPaid: 100000,
    remainingBalance: 100000,
    currency: 'USD',
    dueDate: '2026-08-15',
    startDate: '2025-08-15',
    status: 'active',
    description: 'Joint venture funding',
    interestRate: 5.0,
    totalInterest: 10000,
    frequency: 'monthly',
    installmentAmount: 17500,
    paymentsCount: 12,
    paymentsCompleted: 6,
    nextPaymentDate: '2026-03-15',
  },
  {
    id: 'loan-6',
    type: 'to_pay',
    party: 'Business Line of Credit',
    amount: 100000,
    principal: 100000,
    amountPaid: 100000,
    remainingBalance: 0,
    currency: 'USD',
    dueDate: '2025-12-31',
    startDate: '2025-01-01',
    status: 'paid',
    description: 'Short-term credit line',
    interestRate: 9.5,
    totalInterest: 9500,
    frequency: 'monthly',
    installmentAmount: 9125,
    paymentsCount: 12,
    paymentsCompleted: 12,
  },
];

const paymentScheduleData = [
  { month: 'Feb', scheduled: 35416, paid: 0 },
  { month: 'Mar', scheduled: 53416, paid: 0 },
  { month: 'Apr', scheduled: 71291, paid: 0 },
  { month: 'May', scheduled: 25000, paid: 0 },
  { month: 'Jun', scheduled: 35416, paid: 0 },
  { month: 'Jul', scheduled: 25000, paid: 0 },
];

const loanTypeData = [
  { name: 'Equipment Financing', value: 500000, count: 1 },
  { name: 'Working Capital', value: 250000, count: 1 },
  { name: 'Credit Line', value: 100000, count: 1 },
  { name: 'Business Loans', value: 150000, count: 1 },
];

const COLORS = {
  purple: '#a855f7',
  cyan: '#06b6d4',
  pink: '#ec4899',
  green: '#10b981',
  amber: '#f59e0b',
  blue: '#3b82f6',
  red: '#ef4444',
  orange: '#f97316'
};

export function LoansView() {
  const svc = useOrgServices();

  // Service-backed: fetch accounts with loan-type for future API integration
  const { data: accountsData } = useService(
    () => svc.accounts.getAll(),
    []
  );

  const [activeView, setActiveView] = useState<LoanView>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const loansToReceive = enhancedLoans.filter(l => l.type === 'to_receive');
  const loansToPay = enhancedLoans.filter(l => l.type === 'to_pay');

  // Calculations
  const totalToReceive = loansToReceive.reduce((sum, loan) => sum + (loan.remainingBalance || loan.amount), 0);
  const totalToPay = loansToPay.reduce((sum, loan) => sum + (loan.remainingBalance || loan.amount), 0);
  const netPosition = totalToReceive - totalToPay;
  const totalInterestReceivable = loansToReceive.reduce((sum, loan) => sum + (loan.totalInterest || 0), 0);
  const totalInterestPayable = loansToPay.reduce((sum, loan) => sum + (loan.totalInterest || 0), 0);
  
  const overdueLoans = enhancedLoans.filter(l => l.status === 'overdue');
  const activeLoans = enhancedLoans.filter(l => l.status === 'active' || l.status === 'partially_paid');

  const getStatusBadge = (status: string) => {
    const styles: Record<string, any> = {
      active: AXIOM.badges.success,
      pending: AXIOM.badges.warning,
      overdue: AXIOM.badges.danger,
      partially_paid: AXIOM.badges.info,
      paid: AXIOM.badges.success,
      defaulted: AXIOM.badges.danger,
    };
    return styles[status] || AXIOM.badges.info;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
      case 'paid':
        return <CheckCircle className="size-4" />;
      case 'overdue':
      case 'defaulted':
        return <AlertCircle className="size-4" />;
      case 'pending':
        return <Clock className="size-4" />;
      default:
        return <FileText className="size-4" />;
    }
  };

  const filteredLoans = enhancedLoans.filter(loan => {
    const matchesSearch = loan.party.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         loan.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || loan.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const viewButtons = [
    { id: 'overview' as const, label: 'Overview', icon: Landmark },
    { id: 'to-receive' as const, label: 'Receivables', icon: TrendingUp },
    { id: 'to-pay' as const, label: 'Payables', icon: TrendingDown },
    { id: 'analytics' as const, label: 'Analytics', icon: PieChartIcon },
  ];

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Landmark className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>
                Loans & Liabilities
              </h1>
              <p className="text-slate-400 text-sm">Track borrowings, lending, and payment schedules</p>
            </div>
          </div>
          <div className="flex gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => toast.success('Export downloaded')}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={AXIOM.buttons.secondary}
            >
              <Download className="size-4" />
              Export
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => toast.success('Add loan modal opened')}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={{
                background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                border: '1px solid rgba(6, 182, 212, 0.5)',
                boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
                color: '#ffffff',
              }}
            >
              <Plus className="size-4" />
              Add Loan
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.chartGreen}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Receivables</p>
              <p className="text-3xl font-bold text-white">{formatCurrency(totalToReceive)}</p>
              <div className="flex items-center gap-1 mt-2">
                <ArrowUpRight className="size-3 text-green-400" />
                <p className="text-xs text-green-400">{loansToReceive.length} loans</p>
              </div>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.green,
                boxShadow: AXIOM.shadows.iconGreen,
              }}
            >
              <TrendingUp className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.chartRed}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Payables</p>
              <p className="text-3xl font-bold text-white">{formatCurrency(totalToPay)}</p>
              <div className="flex items-center gap-1 mt-2">
                <ArrowDownRight className="size-3 text-red-400" />
                <p className="text-xs text-red-400">{loansToPay.length} loans</p>
              </div>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.red,
                boxShadow: AXIOM.shadows.iconRed,
              }}
            >
              <TrendingDown className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.chartCyan}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Net Position</p>
              <p className="text-3xl font-bold text-white">{formatCurrency(Math.abs(netPosition))}</p>
              <div className="flex items-center gap-1 mt-2">
                <DollarSign className="size-3 text-cyan-400" />
                <p className="text-xs text-cyan-400">{netPosition >= 0 ? 'Surplus' : 'Deficit'}</p>
              </div>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <Wallet className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.chartAmber}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Overdue Loans</p>
              <p className="text-3xl font-bold text-white">{overdueLoans.length}</p>
              <div className="flex items-center gap-1 mt-2">
                <AlertCircle className="size-3 text-amber-400" />
                <p className="text-xs text-amber-400">Requires attention</p>
              </div>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.amber,
                boxShadow: AXIOM.shadows.iconAmber,
              }}
            >
              <Clock className="size-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* View Selector */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex gap-2 p-2 rounded-2xl"
        style={AXIOM.containers.list}
      >
        {viewButtons.map((btn) => (
          <motion.button
            key={btn.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveView(btn.id)}
            className="flex-1 px-4 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
            style={activeView === btn.id ? AXIOM.buttons.primary : AXIOM.buttons.secondary}
          >
            <btn.icon className="size-4" />
            {btn.label}
          </motion.button>
        ))}
      </motion.div>

      {/* Search and Filter */}
      {activeView !== 'analytics' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="flex gap-4"
        >
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by party or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl text-sm"
              style={{
                background: AXIOM.inputs.background,
                border: AXIOM.inputs.border,
                color: AXIOM.inputs.color,
              }}
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-3 rounded-xl text-sm font-medium"
            style={AXIOM.buttons.secondary}
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="overdue">Overdue</option>
            <option value="partially_paid">Partially Paid</option>
            <option value="paid">Paid</option>
          </select>
        </motion.div>
      )}

      {/* Content Views */}
      {activeView === 'overview' && (
        <div className="space-y-4">
          {/* Upcoming Payments */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.chartPurple}
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-bold text-white">Upcoming Payment Schedule</h3>
                <p className="text-sm text-slate-400 mt-1">Next 6 months payment obligations</p>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={paymentScheduleData}>
                <defs>
                  <linearGradient id="colorScheduled" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={COLORS.cyan} stopOpacity={0.8}/>
                    <stop offset="95%" stopColor={COLORS.cyan} stopOpacity={0.3}/>
                  </linearGradient>
                </defs>
                <CartesianGrid {...AXIOM.charts.grid} />
                <XAxis 
                  dataKey="month" 
                  {...AXIOM.charts.axis}
                  tick={{ fill: '#94a3b8' }}
                />
                <YAxis 
                  {...AXIOM.charts.axis}
                  tick={{ fill: '#94a3b8' }}
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: AXIOM.charts.tooltip.backgroundColor,
                    border: AXIOM.charts.tooltip.border,
                    borderRadius: AXIOM.charts.tooltip.borderRadius,
                    color: '#fff',
                  }}
                  formatter={(value: any) => formatCurrency(value)}
                />
                <Bar dataKey="scheduled" fill="url(#colorScheduled)" name="Scheduled" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Recent Loans */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45 }}
              className="p-6 rounded-2xl"
              style={AXIOM.containers.list}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <TrendingUp className="size-5 text-green-400" />
                  Active Receivables
                </h3>
              </div>
              <div className="space-y-3">
                {loansToReceive.slice(0, 3).map((loan) => (
                  <div
                    key={loan.id}
                    className="p-4 rounded-xl"
                    style={AXIOM.containers.item}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-white font-medium">{loan.party}</p>
                      <span 
                        className="px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1"
                        style={getStatusBadge(loan.status)}
                      >
                        {getStatusIcon(loan.status)}
                        {loan.status.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-2xl font-bold text-green-400 mb-2">{formatCurrency(loan.remainingBalance || loan.amount)}</p>
                    <p className="text-sm text-slate-400 mb-2">{loan.description}</p>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500">Due: {formatDate(loan.dueDate)}</span>
                      {loan.interestRate && (
                        <span className="text-cyan-400">{loan.interestRate}% APR</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="p-6 rounded-2xl"
              style={AXIOM.containers.list}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <TrendingDown className="size-5 text-red-400" />
                  Active Payables
                </h3>
              </div>
              <div className="space-y-3">
                {loansToPay.slice(0, 3).map((loan) => (
                  <div
                    key={loan.id}
                    className="p-4 rounded-xl"
                    style={AXIOM.containers.item}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-white font-medium">{loan.party}</p>
                      <span 
                        className="px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1"
                        style={getStatusBadge(loan.status)}
                      >
                        {getStatusIcon(loan.status)}
                        {loan.status.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-2xl font-bold text-red-400 mb-2">{formatCurrency(loan.remainingBalance || loan.amount)}</p>
                    <p className="text-sm text-slate-400 mb-2">{loan.description}</p>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500">Due: {formatDate(loan.dueDate)}</span>
                      {loan.interestRate && (
                        <span className="text-amber-400">{loan.interestRate}% APR</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      )}

      {activeView === 'to-receive' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold text-white flex items-center gap-2">
                <TrendingUp className="size-6 text-green-400" />
                Loans to Receive
              </h3>
              <p className="text-sm text-slate-400 mt-1">Money owed to your organization</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-400">Total Outstanding</p>
              <p className="text-2xl font-bold text-green-400">{formatCurrency(totalToReceive)}</p>
            </div>
          </div>

          <div className="space-y-3">
            {loansToReceive.filter(loan => {
              const matchesSearch = loan.party.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                   loan.description.toLowerCase().includes(searchQuery.toLowerCase());
              const matchesFilter = filterStatus === 'all' || loan.status === filterStatus;
              return matchesSearch && matchesFilter;
            }).map((loan) => (
              <div
                key={loan.id}
                className="p-6 rounded-xl hover:bg-black/20 transition-colors"
                style={AXIOM.containers.item}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="text-lg font-bold text-white">{loan.party}</h4>
                      <span 
                        className="px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1"
                        style={getStatusBadge(loan.status)}
                      >
                        {getStatusIcon(loan.status)}
                        {loan.status.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-sm text-slate-400">{loan.description}</p>
                  </div>
                  <div className="flex gap-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-lg"
                      style={AXIOM.buttons.secondary}
                      onClick={() => toast.success('Edit loan')}
                    >
                      <Edit className="size-4" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-lg"
                      style={AXIOM.buttons.danger}
                      onClick={() => toast.success('Delete loan')}
                    >
                      <Trash2 className="size-4" />
                    </motion.button>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Principal Amount</p>
                    <p className="text-lg font-bold text-white">{formatCurrency(loan.principal)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Remaining Balance</p>
                    <p className="text-lg font-bold text-green-400">{formatCurrency(loan.remainingBalance || loan.amount)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Interest Rate</p>
                    <p className="text-lg font-bold text-cyan-400">{loan.interestRate || 0}%</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Total Interest</p>
                    <p className="text-lg font-bold text-amber-400">{formatCurrency(loan.totalInterest || 0)}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4" style={{ borderTop: '1px solid rgba(148, 163, 184, 0.1)' }}>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Start Date</p>
                    <p className="text-sm text-slate-300">{loan.startDate ? formatDate(loan.startDate) : 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Due Date</p>
                    <p className="text-sm text-slate-300">{formatDate(loan.dueDate)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Next Payment</p>
                    <p className="text-sm text-slate-300">{loan.nextPaymentDate ? formatDate(loan.nextPaymentDate) : 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Progress</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 rounded-full" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                        <div 
                          className="h-full rounded-full" 
                          style={{ 
                            width: `${loan.paymentsCompleted && loan.paymentsCount ? (loan.paymentsCompleted / loan.paymentsCount * 100) : 0}%`,
                            background: AXIOM.iconBoxes.green
                          }}
                        />
                      </div>
                      <span className="text-xs text-slate-400">
                        {loan.paymentsCompleted || 0}/{loan.paymentsCount || 0}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {activeView === 'to-pay' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold text-white flex items-center gap-2">
                <TrendingDown className="size-6 text-red-400" />
                Loans to Pay
              </h3>
              <p className="text-sm text-slate-400 mt-1">Your organization's outstanding debt</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-400">Total Outstanding</p>
              <p className="text-2xl font-bold text-red-400">{formatCurrency(totalToPay)}</p>
            </div>
          </div>

          <div className="space-y-3">
            {loansToPay.filter(loan => {
              const matchesSearch = loan.party.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                   loan.description.toLowerCase().includes(searchQuery.toLowerCase());
              const matchesFilter = filterStatus === 'all' || loan.status === filterStatus;
              return matchesSearch && matchesFilter;
            }).map((loan) => (
              <div
                key={loan.id}
                className="p-6 rounded-xl hover:bg-black/20 transition-colors"
                style={AXIOM.containers.item}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="text-lg font-bold text-white">{loan.party}</h4>
                      <span 
                        className="px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1"
                        style={getStatusBadge(loan.status)}
                      >
                        {getStatusIcon(loan.status)}
                        {loan.status.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-sm text-slate-400">{loan.description}</p>
                  </div>
                  <div className="flex gap-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-lg"
                      style={AXIOM.buttons.secondary}
                      onClick={() => toast.success('Edit loan')}
                    >
                      <Edit className="size-4" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-lg"
                      style={AXIOM.buttons.danger}
                      onClick={() => toast.success('Delete loan')}
                    >
                      <Trash2 className="size-4" />
                    </motion.button>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Principal Amount</p>
                    <p className="text-lg font-bold text-white">{formatCurrency(loan.principal)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Amount Paid</p>
                    <p className="text-lg font-bold text-green-400">{formatCurrency(loan.amountPaid || 0)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Remaining Balance</p>
                    <p className="text-lg font-bold text-red-400">{formatCurrency(loan.remainingBalance || loan.amount)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Interest Rate</p>
                    <p className="text-lg font-bold text-amber-400">{loan.interestRate || 0}%</p>
                  </div>
                </div>

                {loan.installmentAmount && (
                  <div className="p-4 rounded-xl mb-4" style={{ background: 'rgba(6, 182, 212, 0.1)', border: '1px solid rgba(6, 182, 212, 0.2)' }}>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Installment</p>
                        <p className="text-sm font-bold text-cyan-400">{formatCurrency(loan.installmentAmount)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Frequency</p>
                        <p className="text-sm font-bold text-white capitalize">{loan.frequency || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Next Payment</p>
                        <p className="text-sm font-bold text-white">{loan.nextPaymentDate ? formatDate(loan.nextPaymentDate) : 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4" style={{ borderTop: '1px solid rgba(148, 163, 184, 0.1)' }}>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Start Date</p>
                    <p className="text-sm text-slate-300">{loan.startDate ? formatDate(loan.startDate) : 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Due Date</p>
                    <p className="text-sm text-slate-300">{formatDate(loan.dueDate)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Total Interest</p>
                    <p className="text-sm text-amber-400 font-medium">{formatCurrency(loan.totalInterest || 0)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Progress</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 rounded-full" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                        <div 
                          className="h-full rounded-full" 
                          style={{ 
                            width: `${loan.paymentsCompleted && loan.paymentsCount ? (loan.paymentsCompleted / loan.paymentsCount * 100) : 0}%`,
                            background: AXIOM.iconBoxes.cyan
                          }}
                        />
                      </div>
                      <span className="text-xs text-slate-400">
                        {loan.paymentsCompleted || 0}/{loan.paymentsCount || 0}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {activeView === 'analytics' && (
        <div className="space-y-4">
          {/* Loan Distribution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="p-6 rounded-2xl"
              style={AXIOM.containers.chartPurple}
            >
              <h4 className="text-lg font-bold text-white mb-4">Loan Type Distribution</h4>
              <ResponsiveContainer width="100%" height={300}>
                <RePieChart>
                  <Pie
                    data={loanTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${formatCurrency(value)}`}
                    outerRadius={90}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {loanTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={Object.values(COLORS)[index % Object.values(COLORS).length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: AXIOM.charts.tooltip.backgroundColor,
                      border: AXIOM.charts.tooltip.border,
                      borderRadius: AXIOM.charts.tooltip.borderRadius,
                      color: '#fff',
                    }}
                    formatter={(value: any) => formatCurrency(value)}
                  />
                  <Legend />
                </RePieChart>
              </ResponsiveContainer>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45 }}
              className="p-6 rounded-2xl"
              style={AXIOM.containers.chartCyan}
            >
              <h4 className="text-lg font-bold text-white mb-4">Interest Analysis</h4>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-slate-400">Interest Receivable</p>
                    <p className="text-2xl font-bold text-green-400">{formatCurrency(totalInterestReceivable)}</p>
                  </div>
                  <div className="h-3 rounded-full" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                    <div 
                      className="h-full rounded-full" 
                      style={{ 
                        width: `${(totalInterestReceivable / (totalInterestReceivable + totalInterestPayable) * 100)}%`,
                        background: AXIOM.iconBoxes.green
                      }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-slate-400">Interest Payable</p>
                    <p className="text-2xl font-bold text-red-400">{formatCurrency(totalInterestPayable)}</p>
                  </div>
                  <div className="h-3 rounded-full" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                    <div 
                      className="h-full rounded-full" 
                      style={{ 
                        width: `${(totalInterestPayable / (totalInterestReceivable + totalInterestPayable) * 100)}%`,
                        background: AXIOM.iconBoxes.red
                      }}
                    />
                  </div>
                </div>
                <div className="pt-4" style={{ borderTop: '1px solid rgba(148, 163, 184, 0.1)' }}>
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-slate-400">Net Interest Position</p>
                    <p className="text-2xl font-bold text-cyan-400">
                      {formatCurrency(Math.abs(totalInterestReceivable - totalInterestPayable))}
                    </p>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 text-right">
                    {totalInterestReceivable > totalInterestPayable ? 'Net Gain' : 'Net Cost'}
                  </p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Loan Status Summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.list}
          >
            <h4 className="text-lg font-bold text-white mb-6">Loan Status Summary</h4>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="p-4 rounded-xl" style={AXIOM.containers.item}>
                <p className="text-sm text-slate-400 mb-1">Active</p>
                <p className="text-3xl font-bold text-green-400">
                  {enhancedLoans.filter(l => l.status === 'active').length}
                </p>
              </div>
              <div className="p-4 rounded-xl" style={AXIOM.containers.item}>
                <p className="text-sm text-slate-400 mb-1">Pending</p>
                <p className="text-3xl font-bold text-amber-400">
                  {enhancedLoans.filter(l => l.status === 'pending').length}
                </p>
              </div>
              <div className="p-4 rounded-xl" style={AXIOM.containers.item}>
                <p className="text-sm text-slate-400 mb-1">Overdue</p>
                <p className="text-3xl font-bold text-red-400">
                  {enhancedLoans.filter(l => l.status === 'overdue').length}
                </p>
              </div>
              <div className="p-4 rounded-xl" style={AXIOM.containers.item}>
                <p className="text-sm text-slate-400 mb-1">Partial</p>
                <p className="text-3xl font-bold text-blue-400">
                  {enhancedLoans.filter(l => l.status === 'partially_paid').length}
                </p>
              </div>
              <div className="p-4 rounded-xl" style={AXIOM.containers.item}>
                <p className="text-sm text-slate-400 mb-1">Paid</p>
                <p className="text-3xl font-bold text-cyan-400">
                  {enhancedLoans.filter(l => l.status === 'paid').length}
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}