import { OrganizationDashboard } from '../OrganizationDashboardModern';

export function FinanceOSView() {
  return <OrganizationDashboard />;
}