import { toast } from 'sonner';
import { AXIOM } from '../../../styles/axiom-tokens';
import { organizationService } from '@/services/organizationService';
import { useService } from '@/hooks/useService';
import { useAuth } from '@/contexts/AuthContext';
import { ActiveSessionsView } from './ActiveSessionsView';
import { AuditLogView } from './AuditLogView';
import { DataExportCenter } from './DataExportCenter';

type SettingsView = 'general' | 'financial' | 'team' | 'notifications' | 'security' | 'audit' | 'data' | 'billing';

interface Currency {
  code: string;
  name: string;
  symbol: string;
  enabled: boolean;
}

interface Department {
  id: string;
  name: string;
  color: string;
}

interface FeatureToggle {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  icon: any;
  category: 'financial' | 'automation' | 'team' | 'reporting';
}

// Mock data
const currencies: Currency[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$', enabled: true },
  { code: 'PKR', name: 'Pakistani Rupee', symbol: '₨', enabled: true },
  { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', enabled: true },
  { code: 'EUR', name: 'Euro', symbol: '€', enabled: false },
  { code: 'GBP', name: 'British Pound', symbol: '£', enabled: false },
  { code: 'SAR', name: 'Saudi Riyal', symbol: '﷼', enabled: false },
];

const departments: Department[] = [
  { id: '1', name: 'Design', color: 'purple' },
  { id: '2', name: 'Development', color: 'cyan' },
  { id: '3', name: 'Marketing', color: 'pink' },
  { id: '4', name: 'Sales', color: 'green' },
  { id: '5', name: 'Admin', color: 'amber' },
];

const featureToggles: FeatureToggle[] = [
  {
    id: 'personal_finance',
    name: 'Personal Finance',
    description: 'Track personal and business transactions separately',
    enabled: true,
    icon: DollarSign,
    category: 'financial',
  },
  {
    id: 'auto_categorization',
    name: 'Auto-Categorization',
    description: 'Automatically categorize transactions using AI',
    enabled: true,
    icon: Zap,
    category: 'automation',
  },
  {
    id: 'profit_intelligence',
    name: 'Profit Intelligence',
    description: 'Advanced profit analysis and insights',
    enabled: true,
    icon: BarChart3,
    category: 'financial',
  },
  {
    id: 'multi_currency',
    name: 'Multi-Currency Support',
    description: 'Handle transactions in multiple currencies',
    enabled: true,
    icon: Globe,
    category: 'financial',
  },
  {
    id: 'team_collaboration',
    name: 'Team Collaboration',
    description: 'Enable team members to collaborate on transactions',
    enabled: true,
    icon: Users,
    category: 'team',
  },
  {
    id: 'automated_reports',
    name: 'Automated Reports',
    description: 'Schedule and receive automated financial reports',
    enabled: false,
    icon: FileText,
    category: 'reporting',
  },
  {
    id: 'budget_alerts',
    name: 'Budget Alerts',
    description: 'Get notified when approaching budget limits',
    enabled: true,
    icon: Bell,
    category: 'automation',
  },
  {
    id: 'recurring_transactions',
    name: 'Recurring Transactions',
    description: 'Automatically create recurring transactions',
    enabled: true,
    icon: RefreshCw,
    category: 'automation',
  },
];

export function OrgSettings() {
  const [activeView, setActiveView] = useState<SettingsView>('general');
  const [orgName, setOrgName] = useState('Acme Digital Agency');
  const [fiscalYearStart, setFiscalYearStart] = useState('01-01');
  const [defaultCurrency, setDefaultCurrency] = useState('USD');
  const [enabledCurrencies, setEnabledCurrencies] = useState(currencies.filter(c => c.enabled));
  const [orgDepartments, setOrgDepartments] = useState(departments);
  const [features, setFeatures] = useState(featureToggles);

  const viewButtons = [
    { id: 'general' as const, label: 'General', icon: Building2 },
    { id: 'financial' as const, label: 'Financial', icon: DollarSign },
    { id: 'team' as const, label: 'Team', icon: Users },
    { id: 'notifications' as const, label: 'Notifications', icon: Bell },
    { id: 'security' as const, label: 'Security', icon: Shield },
    { id: 'audit' as const, label: 'Audit Log', icon: FileText },
    { id: 'data' as const, label: 'Data & Export', icon: Database },
    { id: 'billing' as const, label: 'Billing', icon: CreditCard },
  ];

  const toggleFeature = (featureId: string) => {
    setFeatures(features.map(f => 
      f.id === featureId ? { ...f, enabled: !f.enabled } : f
    ));
    toast.success('Feature updated');
  };

  const addCurrency = (currency: Currency) => {
    setEnabledCurrencies([...enabledCurrencies, currency]);
    toast.success(`${currency.code} enabled`);
  };

  const removeCurrency = (code: string) => {
    setEnabledCurrencies(enabledCurrencies.filter(c => c.code !== code));
    toast.success('Currency removed');
  };

  const addDepartment = () => {
    const newDept: Department = {
      id: String(orgDepartments.length + 1),
      name: 'New Department',
      color: 'blue',
    };
    setOrgDepartments([...orgDepartments, newDept]);
    toast.success('Department added');
  };

  const removeDepartment = (id: string) => {
    setOrgDepartments(orgDepartments.filter(d => d.id !== id));
    toast.success('Department removed');
  };

  const saveSettings = () => {
    toast.success('Settings saved successfully');
  };

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Settings className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>
                Organization Settings
              </h1>
              <p className="text-slate-400 text-sm">Configure your organization preferences and features</p>
            </div>
          </div>
          <div className="flex gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => toast.success('Settings reset')}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={AXIOM.buttons.secondary}
            >
              <RefreshCw className="size-4" />
              Reset
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={saveSettings}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={{
                background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                border: '1px solid rgba(6, 182, 212, 0.5)',
                boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
                color: '#ffffff',
              }}
            >
              <Save className="size-4" />
              Save Changes
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* View Selector */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-4 gap-2 p-2 rounded-2xl"
        style={AXIOM.containers.list}
      >
        {viewButtons.map((btn) => (
          <motion.button
            key={btn.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveView(btn.id)}
            className="px-4 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
            style={activeView === btn.id ? AXIOM.buttons.primary : AXIOM.buttons.secondary}
          >
            <btn.icon className="size-4" />
            {btn.label}
          </motion.button>
        ))}
      </motion.div>

      {/* General Settings */}
      {activeView === 'general' && (
        <div className="space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.list}
          >
            <div className="flex items-center gap-3 mb-6">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{
                  background: AXIOM.iconBoxes.cyan,
                  boxShadow: AXIOM.shadows.iconCyan,
                }}
              >
                <Building2 className="size-5 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Organization Information</h3>
                <p className="text-sm text-slate-400">Basic details about your organization</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-sm text-slate-400 block mb-2">Organization Name</label>
                <input
                  type="text"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl text-sm"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 block mb-2">Fiscal Year Start (MM-DD)</label>
                <input
                  type="text"
                  value={fiscalYearStart}
                  onChange={(e) => setFiscalYearStart(e.target.value)}
                  placeholder="01-01"
                  className="w-full px-4 py-3 rounded-xl text-sm"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 block mb-2">Time Zone</label>
                <select
                  className="w-full px-4 py-3 rounded-xl text-sm"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                >
                  <option>UTC+05:00 - Pakistan Standard Time</option>
                  <option>UTC+04:00 - Gulf Standard Time</option>
                  <option>UTC+00:00 - Coordinated Universal Time</option>
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-400 block mb-2">Date Format</label>
                <select
                  className="w-full px-4 py-3 rounded-xl text-sm"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                >
                  <option>MM/DD/YYYY</option>
                  <option>DD/MM/YYYY</option>
                  <option>YYYY-MM-DD</option>
                </select>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.list}
          >
            <div className="flex items-center gap-3 mb-6">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{
                  background: AXIOM.iconBoxes.purple,
                  boxShadow: AXIOM.shadows.iconPurple,
                }}
              >
                <Layers className="size-5 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Departments</h3>
                <p className="text-sm text-slate-400">Organize your team into departments</p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              {orgDepartments.map((dept) => (
                <div
                  key={dept.id}
                  className="p-3 rounded-xl flex items-center justify-between group"
                  style={AXIOM.containers.item}
                >
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{
                        background: dept.color === 'purple' ? COLORS.purple :
                                   dept.color === 'cyan' ? COLORS.cyan :
                                   dept.color === 'pink' ? COLORS.pink :
                                   dept.color === 'green' ? COLORS.green :
                                   dept.color === 'amber' ? COLORS.amber :
                                   COLORS.blue,
                      }}
                    />
                    <span className="text-sm text-white">{dept.name}</span>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => removeDepartment(dept.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="size-3 text-red-400" />
                  </motion.button>
                </div>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={addDepartment}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={AXIOM.buttons.secondary}
            >
              <Plus className="size-4" />
              Add Department
            </motion.button>
          </motion.div>
        </div>
      )}

      {/* Financial Settings */}
      {activeView === 'financial' && (
        <div className="space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.list}
          >
            <div className="flex items-center gap-3 mb-6">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{
                  background: AXIOM.iconBoxes.green,
                  boxShadow: AXIOM.shadows.iconGreen,
                }}
              >
                <Globe className="size-5 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Currency Settings</h3>
                <p className="text-sm text-slate-400">Manage enabled currencies and default currency</p>
              </div>
            </div>

            <div className="mb-6">
              <label className="text-sm text-slate-400 block mb-2">Default Currency</label>
              <select
                value={defaultCurrency}
                onChange={(e) => setDefaultCurrency(e.target.value)}
                className="w-full md:w-1/2 px-4 py-3 rounded-xl text-sm"
                style={{
                  background: AXIOM.inputs.background,
                  border: AXIOM.inputs.border,
                  color: AXIOM.inputs.color,
                }}
              >
                {enabledCurrencies.map((curr) => (
                  <option key={curr.code} value={curr.code}>
                    {curr.code} - {curr.name} ({curr.symbol})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm text-slate-400 block mb-3">Enabled Currencies</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {enabledCurrencies.map((curr) => (
                  <div
                    key={curr.code}
                    className="p-4 rounded-xl flex items-center justify-between"
                    style={AXIOM.containers.item}
                  >
                    <div>
                      <p className="text-white font-medium">{curr.code}</p>
                      <p className="text-xs text-slate-400">{curr.name}</p>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => removeCurrency(curr.code)}
                      className="text-red-400"
                    >
                      <X className="size-4" />
                    </motion.button>
                  </div>
                ))}
              </div>

              <div className="mt-4">
                <label className="text-sm text-slate-400 block mb-3">Available Currencies</label>
                <div className="flex flex-wrap gap-2">
                  {currencies.filter(c => !enabledCurrencies.find(ec => ec.code === c.code)).map((curr) => (
                    <motion.button
                      key={curr.code}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => addCurrency(curr)}
                      className="px-3 py-2 rounded-lg text-sm flex items-center gap-2"
                      style={AXIOM.buttons.secondary}
                    >
                      <Plus className="size-3" />
                      {curr.code}
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.list}
          >
            <div className="flex items-center gap-3 mb-6">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{
                  background: AXIOM.iconBoxes.amber,
                  boxShadow: AXIOM.shadows.iconAmber,
                }}
              >
                <Tag className="size-5 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Tax & Compliance</h3>
                <p className="text-sm text-slate-400">Configure tax rates and compliance settings</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-sm text-slate-400 block mb-2">Default Tax Rate (%)</label>
                <input
                  type="number"
                  defaultValue="18"
                  className="w-full px-4 py-3 rounded-xl text-sm"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 block mb-2">Tax Registration Number</label>
                <input
                  type="text"
                  placeholder="Enter tax ID"
                  className="w-full px-4 py-3 rounded-xl text-sm"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Team Settings */}
      {activeView === 'team' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center gap-3 mb-6">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Users className="size-5 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Team Preferences</h3>
              <p className="text-sm text-slate-400">Configure team collaboration settings</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="p-4 rounded-xl flex items-center justify-between" style={AXIOM.containers.item}>
              <div>
                <p className="text-white font-medium">Require Approval for Transactions</p>
                <p className="text-sm text-slate-400 mt-1">Team members need admin approval for new transactions</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 rounded-full peer bg-slate-700 peer-checked:after:translate-x-full peer-checked:bg-purple-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
              </label>
            </div>

            <div className="p-4 rounded-xl flex items-center justify-between" style={AXIOM.containers.item}>
              <div>
                <p className="text-white font-medium">Enable Team Comments</p>
                <p className="text-sm text-slate-400 mt-1">Allow team members to add comments on transactions</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 rounded-full peer bg-slate-700 peer-checked:after:translate-x-full peer-checked:bg-purple-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
              </label>
            </div>

            <div className="p-4 rounded-xl flex items-center justify-between" style={AXIOM.containers.item}>
              <div>
                <p className="text-white font-medium">Activity Notifications</p>
                <p className="text-sm text-slate-400 mt-1">Notify admins of team member activities</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 rounded-full peer bg-slate-700 peer-checked:after:translate-x-full peer-checked:bg-purple-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
              </label>
            </div>
          </div>
        </motion.div>
      )}

      {/* Notifications */}
      {activeView === 'notifications' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center gap-3 mb-6">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.amber,
                boxShadow: AXIOM.shadows.iconAmber,
              }}
            >
              <Bell className="size-5 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Notification Preferences</h3>
              <p className="text-sm text-slate-400">Control how and when you receive notifications</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="p-4 rounded-xl flex items-center justify-between" style={AXIOM.containers.item}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: AXIOM.iconBoxes.cyan }}>
                  <Mail className="size-5 text-white" />
                </div>
                <div>
                  <p className="text-white font-medium">Email Notifications</p>
                  <p className="text-sm text-slate-400">Receive updates via email</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 rounded-full peer bg-slate-700 peer-checked:after:translate-x-full peer-checked:bg-purple-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
              </label>
            </div>

            <div className="p-4 rounded-xl flex items-center justify-between" style={AXIOM.containers.item}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: AXIOM.iconBoxes.green }}>
                  <DollarSign className="size-5 text-white" />
                </div>
                <div>
                  <p className="text-white font-medium">Transaction Alerts</p>
                  <p className="text-sm text-slate-400">Notify on new transactions</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 rounded-full peer bg-slate-700 peer-checked:after:translate-x-full peer-checked:bg-purple-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
              </label>
            </div>

            <div className="p-4 rounded-xl flex items-center justify-between" style={AXIOM.containers.item}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: AXIOM.iconBoxes.amber }}>
                  <AlertCircle className="size-5 text-white" />
                </div>
                <div>
                  <p className="text-white font-medium">Budget Warnings</p>
                  <p className="text-sm text-slate-400">Alert when approaching budget limits</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 rounded-full peer bg-slate-700 peer-checked:after:translate-x-full peer-checked:bg-purple-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
              </label>
            </div>

            <div className="p-4 rounded-xl flex items-center justify-between" style={AXIOM.containers.item}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: AXIOM.iconBoxes.blue }}>
                  <FileText className="size-5 text-white" />
                </div>
                <div>
                  <p className="text-white font-medium">Report Reminders</p>
                  <p className="text-sm text-slate-400">Weekly/monthly report summaries</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 rounded-full peer bg-slate-700 peer-checked:after:translate-x-full peer-checked:bg-purple-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
              </label>
            </div>
          </div>
        </motion.div>
      )}

      {/* Security Settings */}
      {activeView === 'security' && <ActiveSessionsView />}

      {/* Audit Log */}
      {activeView === 'audit' && <AuditLogView />}

      {/* Data & Export */}
      {activeView === 'data' && <DataExportCenter />}

      {/* Billing */}
      {activeView === 'billing' && (
        <div className="space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.chartPurple}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{
                    background: AXIOM.iconBoxes.purple,
                    boxShadow: AXIOM.shadows.iconPurple,
                  }}
                >
                  <CreditCard className="size-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Current Plan: Professional</h3>
                  <p className="text-sm text-slate-400">$499/month - Billed annually</p>
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 py-2 rounded-xl text-sm font-medium"
                style={AXIOM.buttons.secondary}
              >
                Upgrade Plan
              </motion.button>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-slate-400 mb-1">Users</p>
                <p className="text-2xl font-bold text-white">5/10</p>
                <div className="mt-2 h-2 rounded-full" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                  <div className="h-full rounded-full" style={{ width: '50%', background: AXIOM.iconBoxes.cyan }} />
                </div>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-1">Storage</p>
                <p className="text-2xl font-bold text-white">3.4/10 GB</p>
                <div className="mt-2 h-2 rounded-full" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                  <div className="h-full rounded-full" style={{ width: '34%', background: AXIOM.iconBoxes.green }} />
                </div>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-1">Statements</p>
                <p className="text-2xl font-bold text-white">248/500</p>
                <div className="mt-2 h-2 rounded-full" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                  <div className="h-full rounded-full" style={{ width: '49.6%', background: AXIOM.iconBoxes.amber }} />
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.list}
          >
            <h3 className="text-lg font-bold text-white mb-4">Billing History</h3>
            <div className="space-y-2">
              {[
                { date: '2026-02-01', amount: '$499.00', status: 'Paid', invoice: 'INV-2026-02' },
                { date: '2026-01-01', amount: '$499.00', status: 'Paid', invoice: 'INV-2026-01' },
                { date: '2025-12-01', amount: '$499.00', status: 'Paid', invoice: 'INV-2025-12' },
              ].map((bill) => (
                <div
                  key={bill.invoice}
                  className="p-4 rounded-xl flex items-center justify-between"
                  style={AXIOM.containers.item}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: AXIOM.iconBoxes.green }}>
                      <Check className="size-5 text-white" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{bill.invoice}</p>
                      <p className="text-sm text-slate-400">{bill.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-white font-bold">{bill.amount}</p>
                      <span className="text-xs px-2 py-1 rounded" style={AXIOM.badges.success}>
                        {bill.status}
                      </span>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 rounded-lg"
                      style={AXIOM.buttons.secondary}
                    >
                      <FileDown className="size-4" />
                    </motion.button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

const COLORS = {
  purple: '#a855f7',
  cyan: '#06b6d4',
  pink: '#ec4899',
  green: '#10b981',
  amber: '#f59e0b',
  blue: '#3b82f6',
  red: '#ef4444',
  orange: '#f97316'
};