import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { formatCurrency, formatDate } from '@/lib/formatters';
import { Briefcase, Plus, Target, TrendingUp, TrendingDown, Clock, Users, DollarSign, AlertTriangle, CheckCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { toast } from 'sonner';
import { useTheme } from '../../../contexts/ThemeContext';
import { AXIOM } from '../../../styles/axiom-tokens';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';

interface Project {
  id: string;
  name: string;
  client: string;
  status: 'planning' | 'active' | 'completed' | 'on-hold';
  type: 'fixed' | 'hourly' | 'retainer';
  
  // Financial
  quotedAmount: number;
  actualRevenue: number;
  estimatedCost: number;
  actualCost: number;
  
  // Timeline
  startDate: string;
  endDate: string;
  estimatedHours: number;
  actualHours: number;
  
  // Team
  department: string;
  teamSize: number;
  
  // Tracking
  completionPercentage: number;
}

const mockProjects: Project[] = [
  {
    id: '1',
    name: 'E-commerce Platform Redesign',
    client: 'TechCorp Inc',
    status: 'active',
    type: 'fixed',
    quotedAmount: 1500000,
    actualRevenue: 900000,
    estimatedCost: 1000000,
    actualCost: 650000,
    startDate: '2025-01-01',
    endDate: '2025-03-31',
    estimatedHours: 400,
    actualHours: 260,
    department: 'Development',
    teamSize: 5,
    completionPercentage: 65
  },
  {
    id: '2',
    name: 'Brand Identity Package',
    client: 'StartupXYZ',
    status: 'active',
    type: 'fixed',
    quotedAmount: 500000,
    actualRevenue: 500000,
    estimatedCost: 300000,
    actualCost: 280000,
    startDate: '2024-12-15',
    endDate: '2025-02-15',
    estimatedHours: 120,
    actualHours: 112,
    department: 'Design',
    teamSize: 3,
    completionPercentage: 85
  },
  {
    id: '3',
    name: 'Digital Marketing Campaign',
    client: 'RetailCo',
    status: 'active',
    type: 'retainer',
    quotedAmount: 300000,
    actualRevenue: 300000,
    estimatedCost: 200000,
    actualCost: 210000,
    startDate: '2025-01-01',
    endDate: '2025-06-30',
    estimatedHours: 240,
    actualHours: 85,
    department: 'Marketing',
    teamSize: 2,
    completionPercentage: 35
  },
  {
    id: '4',
    name: 'Mobile App Development',
    client: 'FinanceHub',
    status: 'completed',
    type: 'hourly',
    quotedAmount: 2000000,
    actualRevenue: 2100000,
    estimatedCost: 1400000,
    actualCost: 1350000,
    startDate: '2024-10-01',
    endDate: '2024-12-31',
    estimatedHours: 560,
    actualHours: 540,
    department: 'Development',
    teamSize: 6,
    completionPercentage: 100
  },
  {
    id: '5',
    name: 'Website Performance Audit',
    client: 'MediaGroup',
    status: 'completed',
    type: 'fixed',
    quotedAmount: 150000,
    actualRevenue: 150000,
    estimatedCost: 80000,
    actualCost: 95000,
    startDate: '2024-12-01',
    endDate: '2024-12-20',
    estimatedHours: 40,
    actualHours: 48,
    department: 'Consulting',
    teamSize: 2,
    completionPercentage: 100
  }
];

export function ProjectProfitability() {
  const [projects, setProjects] = useState(mockProjects);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | Project['status']>('all');
  const [filterDepartment, setFilterDepartment] = useState('all');

  const filteredProjects = projects.filter(project => {
    const matchesStatus = filterStatus === 'all' || project.status === filterStatus;
    const matchesDepartment = filterDepartment === 'all' || project.department === filterDepartment;
    return matchesStatus && matchesDepartment;
  });

  const departments = Array.from(new Set(projects.map(p => p.department)));

  // Calculate metrics
  const getProjectProfit = (project: Project) => {
    return project.actualRevenue - project.actualCost;
  };

  const getProjectMargin = (project: Project) => {
    if (project.actualRevenue === 0) return 0;
    return ((project.actualRevenue - project.actualCost) / project.actualRevenue) * 100;
  };

  const getEstimatedProfit = (project: Project) => {
    return project.quotedAmount - project.estimatedCost;
  };

  const getEstimatedMargin = (project: Project) => {
    if (project.quotedAmount === 0) return 0;
    return ((project.quotedAmount - project.estimatedCost) / project.quotedAmount) * 100;
  };

  const getCostVariance = (project: Project) => {
    return project.actualCost - project.estimatedCost;
  };

  const getHourVariance = (project: Project) => {
    return project.actualHours - project.estimatedHours;
  };

  const isOverBudget = (project: Project) => {
    return project.actualCost > project.estimatedCost;
  };

  const isOverHours = (project: Project) => {
    return project.actualHours > project.estimatedHours;
  };

  // Aggregate stats
  const totalRevenue = filteredProjects.reduce((sum, p) => sum + p.actualRevenue, 0);
  const totalCost = filteredProjects.reduce((sum, p) => sum + p.actualCost, 0);
  const totalProfit = totalRevenue - totalCost;
  const avgMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
  const activeProjects = projects.filter(p => p.status === 'active').length;
  const completedProjects = projects.filter(p => p.status === 'completed').length;

  // Performance by department
  const deptPerformance = departments.map(dept => {
    const deptProjects = filteredProjects.filter(p => p.department === dept);
    const revenue = deptProjects.reduce((sum, p) => sum + p.actualRevenue, 0);
    const cost = deptProjects.reduce((sum, p) => sum + p.actualCost, 0);
    const profit = revenue - cost;
    const margin = revenue > 0 ? (profit / revenue) * 100 : 0;
    
    return {
      department: dept,
      revenue,
      cost,
      profit,
      margin,
      projectCount: deptProjects.length
    };
  });

  const handleViewDetails = (project: Project) => {
    setSelectedProject(project);
    setDetailsDialogOpen(true);
  };

  const getStatusBadge = (status: Project['status']) => {
    switch (status) {
      case 'active': return AXIOM.badges.info;
      case 'completed': return AXIOM.badges.success;
      case 'planning': return AXIOM.badges.warning;
      case 'on-hold': return { ...AXIOM.badges.neutral };
      default: return AXIOM.badges.neutral;
    }
  };

  const getTypeBadge = (type: Project['type']) => {
    switch (type) {
      case 'fixed': return { background: 'rgba(6, 182, 212, 0.1)', color: '#06b6d4', border: '1px solid rgba(6, 182, 212, 0.3)' };
      case 'hourly': return { background: 'rgba(168, 85, 247, 0.1)', color: '#a855f7', border: '1px solid rgba(168, 85, 247, 0.3)' };
      case 'retainer': return { background: 'rgba(236, 72, 153, 0.1)', color: '#ec4899', border: '1px solid rgba(236, 72, 153, 0.3)' };
      default: return AXIOM.badges.neutral;
    }
  };

  const { theme } = useTheme();

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Briefcase className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>
                Project Profitability
              </h1>
              <p className="text-slate-400 text-sm">Track costs, revenue, and margins per project</p>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
            style={{
              background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
              border: '1px solid rgba(6, 182, 212, 0.5)',
              boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
              color: '#ffffff',
            }}
            onClick={() => setCreateDialogOpen(true)}
          >
            <Plus className="size-4" />
            New Project
          </motion.button>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Revenue</p>
              <p className="text-2xl font-bold text-white">
                {formatCurrency(totalRevenue, 'PKR')}
              </p>
              <p className="text-xs text-slate-400 mt-1">{filteredProjects.length} projects</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.green,
                boxShadow: AXIOM.shadows.iconGreen,
              }}
            >
              <DollarSign className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Cost</p>
              <p className="text-2xl font-bold text-white">
                {formatCurrency(totalCost, 'PKR')}
              </p>
              <p className="text-xs text-slate-400 mt-1">Actual spend</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.red,
                boxShadow: AXIOM.shadows.iconRed,
              }}
            >
              <TrendingDown className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Profit</p>
              <p className="text-2xl font-bold text-cyan-400">
                {formatCurrency(totalProfit, 'PKR')}
              </p>
              <p className="text-xs text-cyan-400 mt-1">{avgMargin.toFixed(1)}% margin</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <TrendingUp className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Projects</p>
              <p className="text-2xl font-bold text-white">{activeProjects}</p>
              <p className="text-xs text-slate-400 mt-1">{completedProjects} completed</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Briefcase className="size-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="p-4 rounded-2xl"
        style={AXIOM.containers.list}
      >
        <div className="flex gap-3">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="px-4 py-2 rounded-xl text-white text-sm"
            style={{
              background: AXIOM.inputs.background,
              border: AXIOM.inputs.border,
            }}
          >
            <option value="all">All Status</option>
            <option value="planning">Planning</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="on-hold">On Hold</option>
          </select>
          <select
            value={filterDepartment}
            onChange={(e) => setFilterDepartment(e.target.value)}
            className="px-4 py-2 rounded-xl text-white text-sm"
            style={{
              background: AXIOM.inputs.background,
              border: AXIOM.inputs.border,
            }}
          >
            <option value="all">All Departments</option>
            {departments.map(dept => (
              <option key={dept} value={dept}>{dept}</option>
            ))}
          </select>
        </div>
      </motion.div>

      {/* Projects List */}
      <div className="space-y-3">
        {filteredProjects.map((project, idx) => {
          const profit = getProjectProfit(project);
          const margin = getProjectMargin(project);
          const costVariance = getCostVariance(project);
          const hourVariance = getHourVariance(project);

          return (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.35 + idx * 0.05 }}
              className="p-6 rounded-2xl"
              style={AXIOM.containers.list}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-white font-semibold">{project.name}</h3>
                    <span className="px-2 py-1 rounded-lg text-xs font-medium capitalize" style={getStatusBadge(project.status)}>
                      {project.status}
                    </span>
                    <span className="px-2 py-1 rounded-lg text-xs font-medium capitalize" style={getTypeBadge(project.type)}>
                      {project.type}
                    </span>
                  </div>
                  <p className="text-sm text-slate-400">
                    {project.client} • {project.department} • {project.teamSize} members
                  </p>
                </div>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white"
                  style={{ background: 'rgba(148, 163, 184, 0.1)' }}
                  onClick={() => handleViewDetails(project)}
                >
                  <Target className="size-4" />
                </motion.button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                <div>
                  <p className="text-xs text-slate-400 mb-1">Revenue</p>
                  <p className="text-lg font-bold text-emerald-400">
                    {formatCurrency(project.actualRevenue, 'PKR')}
                  </p>
                  <p className="text-xs text-slate-400">
                    of {formatCurrency(project.quotedAmount, 'PKR')}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Cost</p>
                  <p className="text-lg font-bold text-red-400">
                    {formatCurrency(project.actualCost, 'PKR')}
                  </p>
                  <p className={`text-xs ${isOverBudget(project) ? 'text-red-400' : 'text-slate-400'}`}>
                    {isOverBudget(project) ? '+' : ''}{formatCurrency(Math.abs(costVariance), 'PKR')} variance
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Profit</p>
                  <p className={`text-lg font-bold ${profit >= 0 ? 'text-cyan-400' : 'text-red-400'}`}>
                    {formatCurrency(profit, 'PKR')}
                  </p>
                  <p className="text-xs text-slate-400">{margin.toFixed(1)}% margin</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Hours</p>
                  <p className="text-lg font-bold text-white">
                    {project.actualHours}h
                  </p>
                  <p className={`text-xs ${isOverHours(project) ? 'text-amber-400' : 'text-slate-400'}`}>
                    of {project.estimatedHours}h ({isOverHours(project) ? '+' : ''}{Math.abs(hourVariance)}h)
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Timeline</p>
                  <p className="text-sm text-white">
                    {formatDate(project.startDate)}
                  </p>
                  <p className="text-xs text-slate-400">
                    to {formatDate(project.endDate)}
                  </p>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                  <span>Progress</span>
                  <span>{project.completionPercentage}%</span>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${project.completionPercentage}%` }}
                    transition={{ duration: 1, delay: 0.2 }}
                    className="h-full"
                    style={{
                      background: project.completionPercentage === 100
                        ? 'linear-gradient(90deg, #10b981, #059669)'
                        : 'linear-gradient(90deg, #06b6d4, #0891b2)',
                    }}
                  />
                </div>
              </div>

              {(isOverBudget(project) || isOverHours(project)) && project.status === 'active' && (
                <div 
                  className="mt-4 p-3 rounded-xl flex items-start gap-2"
                  style={{
                    background: 'rgba(245, 158, 11, 0.1)',
                    border: '1px solid rgba(245, 158, 11, 0.3)',
                  }}
                >
                  <AlertTriangle className="size-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-400">
                    {isOverBudget(project) && isOverHours(project) 
                      ? 'Project is over budget and estimated hours'
                      : isOverBudget(project)
                      ? `Over budget by ${formatCurrency(costVariance, 'PKR')}`
                      : `Over estimated hours by ${hourVariance}h`
                    }
                  </p>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Department Performance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="p-6 rounded-2xl"
        style={AXIOM.containers.chartBlue}
      >
        <h3 className="text-xl font-bold text-white mb-4">Department Performance</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={deptPerformance}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
            <XAxis dataKey="department" stroke="#94a3b8" />
            <YAxis stroke="#94a3b8" tickFormatter={(value) => `${value / 1000}K`} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#0a0a0f',
                border: '1px solid rgba(148, 163, 184, 0.2)',
                borderRadius: '12px',
                color: '#fff'
              }}
              formatter={(value: any) => formatCurrency(value, 'PKR')}
            />
            <Legend />
            <Bar dataKey="revenue" fill="#10b981" name="Revenue" />
            <Bar dataKey="cost" fill="#ef4444" name="Cost" />
            <Bar dataKey="profit" fill="#06b6d4" name="Profit" />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Project Details Dialog */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent 
          className="max-w-3xl text-white"
          style={{
            background: AXIOM.containers.list.background,
            border: AXIOM.containers.list.border,
          }}
        >
          <DialogHeader>
            <DialogTitle className="text-white">Project Details</DialogTitle>
          </DialogHeader>

          {selectedProject && (
            <div className="space-y-4">
              <div>
                <h2 className="text-2xl font-bold text-white mb-1">{selectedProject.name}</h2>
                <p className="text-slate-400">{selectedProject.client}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-400 text-xs block mb-1">Status</label>
                  <span className="inline-block px-2 py-1 rounded-lg text-xs font-medium capitalize" style={getStatusBadge(selectedProject.status)}>
                    {selectedProject.status}
                  </span>
                </div>
                <div>
                  <label className="text-slate-400 text-xs block mb-1">Type</label>
                  <span className="inline-block px-2 py-1 rounded-lg text-xs font-medium capitalize" style={getTypeBadge(selectedProject.type)}>
                    {selectedProject.type}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 p-4 rounded-xl" style={AXIOM.containers.item}>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Quoted</p>
                  <p className="text-xl font-bold text-white">
                    {formatCurrency(selectedProject.quotedAmount, 'PKR')}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Actual Revenue</p>
                  <p className="text-xl font-bold text-emerald-400">
                    {formatCurrency(selectedProject.actualRevenue, 'PKR')}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Profit</p>
                  <p className={`text-xl font-bold ${getProjectProfit(selectedProject) >= 0 ? 'text-cyan-400' : 'text-red-400'}`}>
                    {formatCurrency(getProjectProfit(selectedProject), 'PKR')}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded-xl" style={AXIOM.containers.item}>
                  <p className="text-sm text-slate-400 mb-2">Cost Analysis</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-300">Estimated</span>
                      <span className="text-white">{formatCurrency(selectedProject.estimatedCost, 'PKR')}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-300">Actual</span>
                      <span className="text-white">{formatCurrency(selectedProject.actualCost, 'PKR')}</span>
                    </div>
                    <div className="flex justify-between text-sm pt-2" style={{ borderTop: '1px solid rgba(148, 163, 184, 0.2)' }}>
                      <span className="text-slate-300">Variance</span>
                      <span className={isOverBudget(selectedProject) ? 'text-red-400' : 'text-emerald-400'}>
                        {isOverBudget(selectedProject) ? '+' : ''}{formatCurrency(getCostVariance(selectedProject), 'PKR')}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-xl" style={AXIOM.containers.item}>
                  <p className="text-sm text-slate-400 mb-2">Time Analysis</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-300">Estimated</span>
                      <span className="text-white">{selectedProject.estimatedHours}h</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-300">Actual</span>
                      <span className="text-white">{selectedProject.actualHours}h</span>
                    </div>
                    <div className="flex justify-between text-sm pt-2" style={{ borderTop: '1px solid rgba(148, 163, 184, 0.2)' }}>
                      <span className="text-slate-300">Variance</span>
                      <span className={isOverHours(selectedProject) ? 'text-amber-400' : 'text-emerald-400'}>
                        {isOverHours(selectedProject) ? '+' : ''}{getHourVariance(selectedProject)}h
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <p className="text-sm text-slate-400 mb-2">Progress</p>
                <div className="h-3 rounded-full overflow-hidden" style={{ background: 'rgba(148, 163, 184, 0.1)' }}>
                  <div
                    className="h-full"
                    style={{
                      width: `${selectedProject.completionPercentage}%`,
                      background: selectedProject.completionPercentage === 100
                        ? 'linear-gradient(90deg, #10b981, #059669)'
                        : 'linear-gradient(90deg, #06b6d4, #0891b2)',
                    }}
                  />
                </div>
                <p className="text-xs text-slate-400 mt-1">{selectedProject.completionPercentage}% complete</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-400 text-xs block mb-1">Department</label>
                  <p className="text-white">{selectedProject.department}</p>
                </div>
                <div>
                  <label className="text-slate-400 text-xs block mb-1">Team Size</label>
                  <p className="text-white">{selectedProject.teamSize} members</p>
                </div>
              </div>

              <div className="flex gap-2 pt-4" style={{ borderTop: '1px solid rgba(148, 163, 184, 0.2)' }}>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex-1 px-4 py-3 rounded-xl text-sm font-medium"
                  style={AXIOM.buttons.secondary}
                  onClick={() => setDetailsDialogOpen(false)}
                >
                  Close
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex-1 px-4 py-3 rounded-xl text-sm font-medium"
                  style={{
                    background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                    border: '1px solid rgba(6, 182, 212, 0.5)',
                    color: '#ffffff',
                  }}
                >
                  Edit Project
                </motion.button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Project Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent 
          className="max-w-2xl text-white"
          style={{
            background: AXIOM.containers.list.background,
            border: AXIOM.containers.list.border,
          }}
        >
          <DialogHeader>
            <DialogTitle className="text-white">Create New Project</DialogTitle>
            <DialogDescription className="text-slate-400">
              Set up a new project to track profitability
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Project Name *</label>
                <input
                  placeholder="E-commerce Platform"
                  className="w-full px-4 py-3 rounded-xl text-white"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                  }}
                />
              </div>
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Client *</label>
                <input
                  placeholder="Client name"
                  className="w-full px-4 py-3 rounded-xl text-white"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                  }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Type *</label>
                <Select>
                  <SelectTrigger 
                    className="w-full text-white"
                    style={{
                      background: AXIOM.inputs.background,
                      border: AXIOM.inputs.border,
                    }}
                  >
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent 
                    style={{
                      background: AXIOM.containers.list.background,
                      border: AXIOM.containers.list.border,
                    }}
                  >
                    <SelectItem value="fixed" className="text-white">Fixed Price</SelectItem>
                    <SelectItem value="hourly" className="text-white">Hourly</SelectItem>
                    <SelectItem value="retainer" className="text-white">Retainer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Department *</label>
                <Select>
                  <SelectTrigger 
                    className="w-full text-white"
                    style={{
                      background: AXIOM.inputs.background,
                      border: AXIOM.inputs.border,
                    }}
                  >
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent 
                    style={{
                      background: AXIOM.containers.list.background,
                      border: AXIOM.containers.list.border,
                    }}
                  >
                    <SelectItem value="development" className="text-white">Development</SelectItem>
                    <SelectItem value="design" className="text-white">Design</SelectItem>
                    <SelectItem value="marketing" className="text-white">Marketing</SelectItem>
                    <SelectItem value="consulting" className="text-white">Consulting</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Team Size</label>
                <input
                  type="number"
                  placeholder="5"
                  className="w-full px-4 py-3 rounded-xl text-white"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                  }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Quoted Amount *</label>
                <input
                  type="number"
                  placeholder="1000000"
                  className="w-full px-4 py-3 rounded-xl text-white"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                  }}
                />
              </div>
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Estimated Cost *</label>
                <input
                  type="number"
                  placeholder="700000"
                  className="w-full px-4 py-3 rounded-xl text-white"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                  }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Start Date *</label>
                <input
                  type="date"
                  className="w-full px-4 py-3 rounded-xl text-white"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                  }}
                />
              </div>
              <div>
                <label className="text-white text-sm font-medium mb-2 block">End Date *</label>
                <input
                  type="date"
                  className="w-full px-4 py-3 rounded-xl text-white"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                  }}
                />
              </div>
            </div>

            <div>
              <label className="text-white text-sm font-medium mb-2 block">Estimated Hours</label>
              <input
                type="number"
                placeholder="400"
                className="w-full px-4 py-3 rounded-xl text-white"
                style={{
                  background: AXIOM.inputs.background,
                  border: AXIOM.inputs.border,
                }}
              />
            </div>

            <div className="flex gap-2 pt-4" style={{ borderTop: '1px solid rgba(148, 163, 184, 0.2)' }}>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex-1 px-4 py-3 rounded-xl text-sm font-medium"
                style={AXIOM.buttons.secondary}
                onClick={() => setCreateDialogOpen(false)}
              >
                Cancel
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex-1 px-4 py-3 rounded-xl text-sm font-medium"
                style={{
                  background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                  border: '1px solid rgba(6, 182, 212, 0.5)',
                  color: '#ffffff',
                }}
                onClick={() => {
                  toast.success('Project created successfully');
                  setCreateDialogOpen(false);
                }}
              >
                Create Project
              </motion.button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}