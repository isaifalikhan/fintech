import { useState } from 'react';
import { motion } from 'motion/react';
import { formatCurrency, formatDate } from '@/lib/formatters';
import { Calendar, Repeat, Plus, Edit, Trash2, Pause, Play, AlertCircle, TrendingUp, Clock, DollarSign, TrendingDown } from 'lucide-react';
import { toast } from 'sonner';
import { useTheme } from '../../../contexts/ThemeContext';
import { AXIOM } from '../../../styles/axiom-tokens';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';
import { recurringTransactionService } from '@/services/recurringTransactionService';
import { useAuth } from '@/contexts/AuthContext';
import type { RecurringTransaction as ServiceRT } from '@/services/types';

interface RecurringTransaction extends ServiceRT {
  /** Display alias */
  name: string;
  accountName: string;
  generatedCount: number;
  totalExpected: number;
  autoGenerate: boolean;
  reminderDays: number;
  scope: string;
  status: string;
}

function toVM(r: ServiceRT): RecurringTransaction {
  return {
    ...r,
    name: r.description,
    accountName: r.bankAccountId,
    generatedCount: 0,
    totalExpected: 12,
    autoGenerate: true,
    reminderDays: 3,
    scope: 'business',
    status: r.isActive ? 'active' : 'paused',
  };
}

export function RecurringTransactions() {
  const { theme } = useTheme();
  const { currentOrganization } = useAuth();
  const orgId = currentOrganization?.id || 'org-001';
  const { data: rawRT, loading } = useService(
    () => recurringTransactionService.getAll(orgId),
    [orgId]
  );
  const serviceTransactions: RecurringTransaction[] = (rawRT ?? []).map(toVM);
  const [localOverrides, setLocalOverrides] = useState<RecurringTransaction[]>([]);
  // Use service data; local overrides for optimistic UI after create/delete
  const transactions = localOverrides.length > 0 ? localOverrides : serviceTransactions;
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'paused'>('all');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');

  const filteredTransactions = transactions.filter(txn => {
    const matchesStatus = filterStatus === 'all' || txn.status === filterStatus;
    const matchesType = filterType === 'all' || txn.type === filterType;
    return matchesStatus && matchesType;
  });

  const handleToggleStatus = (id: string) => {
    setLocalOverrides(transactions.map(txn => {
      if (txn.id === id) {
        const newStatus = txn.status === 'active' ? 'paused' : 'active';
        toast.success(`Transaction ${newStatus === 'active' ? 'resumed' : 'paused'}`);
        return { ...txn, status: newStatus };
      }
      return txn;
    }));
  };

  const handleDelete = (id: string) => {
    setLocalOverrides(transactions.filter(txn => txn.id !== id));
    toast.success('Recurring transaction deleted');
  };

  const activeTransactions = transactions.filter(t => t.status === 'active');
  const totalMonthlyIncome = activeTransactions
    .filter(t => t.type === 'income' && t.frequency === 'monthly')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const totalMonthlyExpense = activeTransactions
    .filter(t => t.type === 'expense' && t.frequency === 'monthly')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Repeat className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>Recurring Transactions</h1>
              <p className="text-slate-400 text-sm">Automate regular income and expenses</p>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
            style={{
              background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
              border: '1px solid rgba(6, 182, 212, 0.5)',
              boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
              color: '#ffffff',
            }}
            onClick={() => setCreateDialogOpen(true)}
          >
            <Plus className="size-4" />
            New Recurring Transaction
          </motion.button>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Active</p>
              <p className="text-2xl font-bold text-white">{activeTransactions.length}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.blue,
                boxShadow: AXIOM.shadows.iconBlue,
              }}
            >
              <Repeat className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Monthly Income</p>
              <p className="text-2xl font-bold text-emerald-400">{formatCurrency(totalMonthlyIncome, 'PKR')}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.green,
                boxShadow: AXIOM.shadows.iconGreen,
              }}
            >
              <TrendingUp className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Monthly Expense</p>
              <p className="text-2xl font-bold text-red-400">{formatCurrency(totalMonthlyExpense, 'PKR')}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.red,
                boxShadow: AXIOM.shadows.iconRed,
              }}
            >
              <TrendingDown className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Net Monthly</p>
              <p className={`text-2xl font-bold ${totalMonthlyIncome - totalMonthlyExpense >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {formatCurrency(totalMonthlyIncome - totalMonthlyExpense, 'PKR')}
              </p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <Clock className="size-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="p-6 rounded-2xl"
        style={AXIOM.containers.list}
      >
        <div className="flex gap-3">
          <select 
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="h-10 px-3 rounded-xl"
            style={{
              background: AXIOM.inputs.background,
              border: AXIOM.inputs.border,
              color: AXIOM.inputs.color,
            }}
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="paused">Paused</option>
          </select>
          <select 
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as any)}
            className="h-10 px-3 rounded-xl"
            style={{
              background: AXIOM.inputs.background,
              border: AXIOM.inputs.border,
              color: AXIOM.inputs.color,
            }}
          >
            <option value="all">All Types</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
          </select>
        </div>
      </motion.div>

      {/* Transactions List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        className="rounded-2xl overflow-hidden"
        style={AXIOM.containers.list}
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(148, 163, 184, 0.1)' }}>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Name</th>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Category</th>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Frequency</th>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Next Due</th>
                <th className="px-4 py-4 text-right text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Amount</th>
                <th className="px-4 py-4 text-center text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Auto</th>
                <th className="px-4 py-4 text-center text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Status</th>
                <th className="px-4 py-4 text-center text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Progress</th>
                <th className="px-4 py-4 text-right text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center" style={{ color: AXIOM.text.slate400 }}>
                    No recurring transactions found.
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((txn, idx) => (
                  <motion.tr
                    key={txn.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + idx * 0.05 }}
                    className="group"
                    style={{
                      borderBottom: '1px solid rgba(148, 163, 184, 0.05)',
                    }}
                  >
                    <td className="px-4 py-4">
                      <div>
                        <p className="text-sm font-medium text-white">{txn.name}</p>
                        {txn.department && (
                          <p className="text-xs" style={{ color: AXIOM.text.slate400 }}>{txn.department}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-sm" style={{ color: AXIOM.text.slate300 }}>{txn.category}</td>
                    <td className="px-4 py-4">
                      <span 
                        className="px-2 py-1 rounded-lg text-xs font-medium capitalize"
                        style={AXIOM.badges.purple}
                      >
                        {txn.frequency}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm" style={{ color: AXIOM.text.slate300 }}>
                      {formatDate(txn.nextDue)}
                    </td>
                    <td className="px-4 py-4 text-right">
                      <span 
                        className="text-sm font-bold font-mono"
                        style={{ color: txn.type === 'income' ? '#10b981' : '#ef4444' }}
                      >
                        {txn.type === 'income' ? '+' : '-'}{formatCurrency(txn.amount, txn.currency)}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-center">
                      {txn.autoGenerate ? (
                        <span 
                          className="px-2 py-1 rounded-lg text-xs font-medium"
                          style={AXIOM.badges.success}
                        >
                          Auto
                        </span>
                      ) : (
                        <span 
                          className="px-2 py-1 rounded-lg text-xs font-medium"
                          style={AXIOM.badges.warning}
                        >
                          Manual
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-4 text-center">
                      <span 
                        className="px-2 py-1 rounded-lg text-xs font-medium capitalize"
                        style={
                          txn.status === 'active' ? AXIOM.badges.success :
                          txn.status === 'paused' ? AXIOM.badges.warning :
                          AXIOM.badges.default
                        }
                      >
                        {txn.status}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-24 h-2 rounded-full" style={{ background: 'rgba(148, 163, 184, 0.2)' }}>
                          <div 
                            className="h-full rounded-full"
                            style={{
                              width: `${(txn.generatedCount / txn.totalExpected) * 100}%`,
                              background: 'linear-gradient(to right, rgb(168, 85, 247), rgb(236, 72, 153))',
                            }}
                          />
                        </div>
                        <span className="text-xs" style={{ color: AXIOM.text.slate400 }}>
                          {txn.generatedCount}/{txn.totalExpected}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{
                            background: 'rgba(0, 0, 0, 0.2)',
                            color: AXIOM.text.slate400,
                          }}
                          onClick={() => handleToggleStatus(txn.id)}
                        >
                          {txn.status === 'active' ? <Pause className="size-3" /> : <Play className="size-3" />}
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{
                            background: 'rgba(0, 0, 0, 0.2)',
                            color: AXIOM.text.slate400,
                          }}
                          onClick={() => toast.info('Edit feature coming soon')}
                        >
                          <Edit className="size-3" />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{
                            background: 'rgba(0, 0, 0, 0.2)',
                            color: '#ef4444',
                          }}
                          onClick={() => handleDelete(txn.id)}
                        >
                          <Trash2 className="size-3" />
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}