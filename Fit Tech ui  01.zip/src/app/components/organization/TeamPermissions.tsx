import { toast } from 'sonner';
import { AXIOM } from '../../../styles/axiom-tokens';
// Wired to organizationService for member management
import { organizationService } from '@/services/organizationService';
import { useService } from '@/hooks/useService';
import { useAuth } from '@/contexts/AuthContext';
import { formatDate } from '@/lib/formatters';

type TeamView = 'members' | 'roles' | 'activity' | 'invitations';
type MemberRole = 'org_admin' | 'team_member' | 'accountant' | 'viewer';
type MemberStatus = 'active' | 'inactive' | 'pending';

interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  status: MemberStatus;
  permissions: string[];
  organizationId?: string;
  lastActive?: string;
  joinedDate?: string;
  avatar?: string;
}

interface Permission {
  id: string;
  name: string;
  description: string;
  icon: any;
  category: 'financial' | 'team' | 'settings' | 'data';
}

// Enhanced mock data
const enhancedTeamMembers: TeamMember[] = [
  {
    id: '2',
    email: 'john@acme.com',
    name: 'John Doe',
    role: 'org_admin',
    status: 'active',
    organizationId: 'org-1',
    permissions: ['all'],
    lastActive: '2026-02-09T10:30:00',
    joinedDate: '2025-01-15',
  },
  {
    id: '3',
    email: 'jane@acme.com',
    name: 'Jane Smith',
    role: 'team_member',
    status: 'active',
    organizationId: 'org-1',
    permissions: ['add_transaction', 'view_reports', 'export_data'],
    lastActive: '2026-02-09T09:15:00',
    joinedDate: '2025-02-01',
  },
  {
    id: '5',
    email: 'mike@acme.com',
    name: 'Mike Johnson',
    role: 'accountant',
    status: 'active',
    organizationId: 'org-1',
    permissions: ['view_reports', 'add_transaction', 'edit_transaction', 'categorize', 'export_data', 'manage_accounts'],
    lastActive: '2026-02-08T16:45:00',
    joinedDate: '2025-03-10',
  },
  {
    id: '6',
    email: 'sarah@acme.com',
    name: 'Sarah Williams',
    role: 'viewer',
    status: 'active',
    organizationId: 'org-1',
    permissions: ['view_reports', 'view_dashboard'],
    lastActive: '2026-02-07T14:20:00',
    joinedDate: '2025-04-05',
  },
  {
    id: '7',
    email: 'david@acme.com',
    name: 'David Brown',
    role: 'team_member',
    status: 'pending',
    organizationId: 'org-1',
    permissions: ['add_transaction', 'view_reports'],
    joinedDate: '2026-02-08',
  },
];

const allPermissions: Permission[] = [
  { id: 'view_dashboard', name: 'View Dashboard', description: 'Access organization dashboard', icon: BarChart3, category: 'financial' },
  { id: 'view_reports', name: 'View Reports', description: 'Access financial reports', icon: FileText, category: 'financial' },
  { id: 'add_transaction', name: 'Add Transactions', description: 'Create new transactions', icon: Plus, category: 'financial' },
  { id: 'edit_transaction', name: 'Edit Transactions', description: 'Modify existing transactions', icon: Edit, category: 'financial' },
  { id: 'delete_transaction', name: 'Delete Transactions', description: 'Remove transactions', icon: Trash2, category: 'financial' },
  { id: 'categorize', name: 'Categorize', description: 'Assign categories to transactions', icon: GitBranch, category: 'financial' },
  { id: 'manage_accounts', name: 'Manage Accounts', description: 'Add/edit bank accounts and wallets', icon: DollarSign, category: 'financial' },
  { id: 'export_data', name: 'Export Data', description: 'Export financial data and reports', icon: Database, category: 'data' },
  { id: 'import_statements', name: 'Import Statements', description: 'Upload bank statements', icon: FileText, category: 'data' },
  { id: 'manage_team', name: 'Manage Team', description: 'Invite and manage team members', icon: Users, category: 'team' },
  { id: 'manage_permissions', name: 'Manage Permissions', description: 'Assign roles and permissions', icon: Shield, category: 'team' },
  { id: 'organization_settings', name: 'Organization Settings', description: 'Modify organization settings', icon: Settings, category: 'settings' },
];

const roleDefinitions = [
  {
    id: 'org_admin',
    name: 'Organization Admin',
    description: 'Full access to all features and settings',
    color: 'purple',
    permissions: ['all'],
    count: 1,
  },
  {
    id: 'accountant',
    name: 'Accountant',
    description: 'Full financial access, limited team management',
    color: 'cyan',
    permissions: ['view_dashboard', 'view_reports', 'add_transaction', 'edit_transaction', 'categorize', 'export_data', 'manage_accounts', 'import_statements'],
    count: 1,
  },
  {
    id: 'team_member',
    name: 'Team Member',
    description: 'Add transactions and view reports',
    color: 'blue',
    permissions: ['view_dashboard', 'add_transaction', 'view_reports'],
    count: 2,
  },
  {
    id: 'viewer',
    name: 'Viewer',
    description: 'View-only access to reports and dashboard',
    color: 'green',
    permissions: ['view_dashboard', 'view_reports'],
    count: 1,
  },
];

const activityLog = [
  { id: '1', user: 'John Doe', action: 'Invited new member', details: 'david@acme.com', timestamp: '2026-02-08T15:30:00', type: 'invite' },
  { id: '2', user: 'Jane Smith', action: 'Updated permissions', details: 'Added export_data permission', timestamp: '2026-02-07T14:20:00', type: 'permission' },
  { id: '3', user: 'John Doe', action: 'Changed role', details: 'Mike Johnson → Accountant', timestamp: '2026-02-06T10:15:00', type: 'role' },
  { id: '4', user: 'Mike Johnson', action: 'Logged in', details: 'From IP 192.168.1.101', timestamp: '2026-02-08T16:45:00', type: 'login' },
];

export function TeamPermissions() {
  const { currentOrganization } = useAuth();
  const orgId = currentOrganization?.id || 'org-001';

  // Service-backed: will replace enhancedTeamMembers with organizationService.getMembers()
  const { data: orgMembers } = useService(
    () => organizationService.getMembers(orgId),
    [orgId]
  );

  const [activeView, setActiveView] = useState<TeamView>('members');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRole, setFilterRole] = useState<string>('all');
  const [selectedMember, setSelectedMember] = useState<string | null>(null);

  const teamMembers = orgMembers || enhancedTeamMembers.filter(m => m.organizationId === 'org-1');
  
  const activeMembers = teamMembers.filter(m => m.status === 'active').length;
  const pendingMembers = teamMembers.filter(m => m.status === 'pending').length;
  const totalPermissions = allPermissions.length;

  const formatDateTime = (dateStr: string) => {
    return new Date(dateStr).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getRelativeTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return formatDate(dateStr);
  };

  const getRoleBadge = (role: string) => {
    const styles: Record<string, any> = {
      org_admin: AXIOM.badges.purple,
      accountant: AXIOM.badges.cyan,
      team_member: AXIOM.badges.info,
      viewer: AXIOM.badges.success,
    };
    return styles[role] || AXIOM.badges.info;
  };

  const getStatusBadge = (status: MemberStatus) => {
    const styles: Record<string, any> = {
      active: AXIOM.badges.success,
      inactive: AXIOM.badges.danger,
      pending: AXIOM.badges.warning,
    };
    return styles[status] || AXIOM.badges.info;
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'org_admin':
        return <Crown className="size-4" />;
      case 'accountant':
        return <DollarSign className="size-4" />;
      case 'team_member':
        return <Users className="size-4" />;
      case 'viewer':
        return <Eye className="size-4" />;
      default:
        return <UserCheck className="size-4" />;
    }
  };

  const filteredMembers = teamMembers.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         member.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = filterRole === 'all' || member.role === filterRole;
    return matchesSearch && matchesRole;
  });

  const viewButtons = [
    { id: 'members' as const, label: 'Team Members', icon: Users },
    { id: 'roles' as const, label: 'Roles & Permissions', icon: Shield },
    { id: 'activity' as const, label: 'Activity Log', icon: Activity },
    { id: 'invitations' as const, label: 'Pending Invites', icon: Mail },
  ];

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Users className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>
                Team & Permissions
              </h1>
              <p className="text-slate-400 text-sm">Manage team members and access control</p>
            </div>
          </div>
          <div className="flex gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => toast.success('Bulk actions opened')}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={AXIOM.buttons.secondary}
            >
              <Settings className="size-4" />
              Settings
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => toast.success('Invite member modal opened')}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={{
                background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                border: '1px solid rgba(6, 182, 212, 0.5)',
                boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
                color: '#ffffff',
              }}
            >
              <Plus className="size-4" />
              Invite Member
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.chartGreen}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Active Members</p>
              <p className="text-3xl font-bold text-white">{activeMembers}</p>
              <p className="text-xs text-green-400 mt-1">Currently online</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.green,
                boxShadow: AXIOM.shadows.iconGreen,
              }}
            >
              <UserCheck className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.chartAmber}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Pending Invites</p>
              <p className="text-3xl font-bold text-white">{pendingMembers}</p>
              <p className="text-xs text-amber-400 mt-1">Awaiting acceptance</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.amber,
                boxShadow: AXIOM.shadows.iconAmber,
              }}
            >
              <Mail className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.chartPurple}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Roles</p>
              <p className="text-3xl font-bold text-white">{roleDefinitions.length}</p>
              <p className="text-xs text-purple-400 mt-1">Permission groups</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Shield className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.chartCyan}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Permissions</p>
              <p className="text-3xl font-bold text-white">{totalPermissions}</p>
              <p className="text-xs text-cyan-400 mt-1">Available controls</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <Lock className="size-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* View Selector */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex gap-2 p-2 rounded-2xl"
        style={AXIOM.containers.list}
      >
        {viewButtons.map((btn) => (
          <motion.button
            key={btn.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveView(btn.id)}
            className="flex-1 px-4 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
            style={activeView === btn.id ? AXIOM.buttons.primary : AXIOM.buttons.secondary}
          >
            <btn.icon className="size-4" />
            {btn.label}
          </motion.button>
        ))}
      </motion.div>

      {/* Search and Filter */}
      {activeView === 'members' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="flex gap-4"
        >
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 size-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name or email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl text-sm"
              style={{
                background: AXIOM.inputs.background,
                border: AXIOM.inputs.border,
                color: AXIOM.inputs.color,
              }}
            />
          </div>
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="px-4 py-3 rounded-xl text-sm font-medium"
            style={AXIOM.buttons.secondary}
          >
            <option value="all">All Roles</option>
            <option value="org_admin">Organization Admin</option>
            <option value="accountant">Accountant</option>
            <option value="team_member">Team Member</option>
            <option value="viewer">Viewer</option>
          </select>
        </motion.div>
      )}

      {/* Content Views */}
      {activeView === 'members' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMembers.map((member, index) => (
            <motion.div
              key={member.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.05 }}
              className="p-6 rounded-2xl group"
              style={AXIOM.containers.list}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div 
                    className="size-12 rounded-xl flex items-center justify-center"
                    style={{
                      background: member.role === 'org_admin' ? AXIOM.iconBoxes.purple :
                                 member.role === 'accountant' ? AXIOM.iconBoxes.cyan :
                                 member.role === 'viewer' ? AXIOM.iconBoxes.green :
                                 AXIOM.iconBoxes.blue,
                      boxShadow: member.role === 'org_admin' ? AXIOM.shadows.iconPurple :
                                 member.role === 'accountant' ? AXIOM.shadows.iconCyan :
                                 member.role === 'viewer' ? AXIOM.shadows.iconGreen :
                                 AXIOM.shadows.iconBlue,
                    }}
                  >
                    <span className="text-white font-bold text-lg">{member.name[0]}</span>
                  </div>
                  <div>
                    <p className="text-white font-medium">{member.name}</p>
                    <p className="text-xs text-slate-400">{member.email}</p>
                  </div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  style={AXIOM.buttons.secondary}
                  onClick={() => toast.success('Member options')}
                >
                  <MoreVertical className="size-4" />
                </motion.button>
              </div>

              <div className="flex items-center gap-2 mb-4">
                <span 
                  className="px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1"
                  style={getRoleBadge(member.role)}
                >
                  {getRoleIcon(member.role)}
                  {member.role.replace('_', ' ')}
                </span>
                <span 
                  className="px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1"
                  style={getStatusBadge(member.status)}
                >
                  {member.status === 'active' ? <CheckCircle className="size-3" /> :
                   member.status === 'pending' ? <AlertCircle className="size-3" /> :
                   <XCircle className="size-3" />}
                  {member.status}
                </span>
              </div>

              <div className="space-y-2 mb-4 pb-4" style={{ borderBottom: '1px solid rgba(148, 163, 184, 0.1)' }}>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Joined</span>
                  <span className="text-slate-300">{member.joinedDate ? formatDate(member.joinedDate) : 'N/A'}</span>
                </div>
                {member.lastActive && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Last active</span>
                    <span className="text-green-400">{getRelativeTime(member.lastActive)}</span>
                  </div>
                )}
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Permissions</span>
                  <span className="text-cyan-400">{member.permissions.includes('all') ? 'All' : member.permissions.length}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1"
                  style={AXIOM.buttons.secondary}
                  onClick={() => toast.success('Manage permissions')}
                >
                  <Shield className="size-3" />
                  Permissions
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1"
                  style={AXIOM.buttons.secondary}
                  onClick={() => toast.success('Edit member')}
                >
                  <Edit className="size-3" />
                  Edit
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {activeView === 'roles' && (
        <div className="space-y-4">
          {/* Role Definitions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {roleDefinitions.map((role, index) => (
              <motion.div
                key={role.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
                className="p-6 rounded-2xl"
                style={AXIOM.containers.list}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{
                        background: role.color === 'purple' ? AXIOM.iconBoxes.purple :
                                   role.color === 'cyan' ? AXIOM.iconBoxes.cyan :
                                   role.color === 'blue' ? AXIOM.iconBoxes.blue :
                                   AXIOM.iconBoxes.green,
                        boxShadow: role.color === 'purple' ? AXIOM.shadows.iconPurple :
                                   role.color === 'cyan' ? AXIOM.shadows.iconCyan :
                                   role.color === 'blue' ? AXIOM.shadows.iconBlue :
                                   AXIOM.shadows.iconGreen,
                      }}
                    >
                      {role.id === 'org_admin' && <Crown className="size-6 text-white" />}
                      {role.id === 'accountant' && <DollarSign className="size-6 text-white" />}
                      {role.id === 'team_member' && <Users className="size-6 text-white" />}
                      {role.id === 'viewer' && <Eye className="size-6 text-white" />}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-white">{role.name}</h3>
                      <p className="text-sm text-slate-400">{role.description}</p>
                    </div>
                  </div>
                  <span 
                    className="px-3 py-1 rounded-lg text-xs font-medium"
                    style={AXIOM.badges.info}
                  >
                    {role.count} {role.count === 1 ? 'member' : 'members'}
                  </span>
                </div>

                <div className="space-y-2">
                  <p className="text-xs text-slate-500 font-medium uppercase">Permissions</p>
                  {role.permissions.includes('all') ? (
                    <div className="p-3 rounded-lg" style={{ background: 'rgba(168, 85, 247, 0.1)', border: '1px solid rgba(168, 85, 247, 0.2)' }}>
                      <div className="flex items-center gap-2">
                        <Unlock className="size-4 text-purple-400" />
                        <span className="text-sm text-purple-400 font-medium">Full Access - All Permissions</span>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      {role.permissions.slice(0, 6).map((perm) => {
                        const permission = allPermissions.find(p => p.id === perm);
                        if (!permission) return null;
                        return (
                          <div
                            key={perm}
                            className="p-2 rounded-lg text-xs flex items-center gap-2"
                            style={AXIOM.containers.item}
                          >
                            <CheckCircle className="size-3 text-green-400" />
                            <span className="text-slate-300">{permission.name}</span>
                          </div>
                        );
                      })}
                      {role.permissions.length > 6 && (
                        <div className="p-2 rounded-lg text-xs flex items-center gap-2" style={AXIOM.containers.item}>
                          <span className="text-cyan-400">+{role.permissions.length - 6} more</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full mt-4 px-4 py-2 rounded-xl text-sm font-medium flex items-center justify-center gap-2"
                  style={AXIOM.buttons.secondary}
                  onClick={() => toast.success('Edit role permissions')}
                >
                  <Edit className="size-4" />
                  Edit Role
                </motion.button>
              </motion.div>
            ))}
          </div>

          {/* All Permissions Matrix */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="p-6 rounded-2xl"
            style={AXIOM.containers.list}
          >
            <h3 className="text-xl font-bold text-white mb-4">All Permissions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {allPermissions.map((permission) => {
                const Icon = permission.icon;
                return (
                  <div
                    key={permission.id}
                    className="p-4 rounded-xl"
                    style={AXIOM.containers.item}
                  >
                    <div className="flex items-start gap-3">
                      <div 
                        className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{
                          background: permission.category === 'financial' ? AXIOM.iconBoxes.green :
                                     permission.category === 'team' ? AXIOM.iconBoxes.purple :
                                     permission.category === 'settings' ? AXIOM.iconBoxes.amber :
                                     AXIOM.iconBoxes.cyan,
                        }}
                      >
                        <Icon className="size-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-white">{permission.name}</p>
                        <p className="text-xs text-slate-400 mt-1">{permission.description}</p>
                        <span 
                          className="inline-block mt-2 px-2 py-1 rounded text-xs"
                          style={{
                            background: permission.category === 'financial' ? 'rgba(16, 185, 129, 0.1)' :
                                       permission.category === 'team' ? 'rgba(168, 85, 247, 0.1)' :
                                       permission.category === 'settings' ? 'rgba(245, 158, 11, 0.1)' :
                                       'rgba(6, 182, 212, 0.1)',
                            color: permission.category === 'financial' ? '#10b981' :
                                  permission.category === 'team' ? '#a855f7' :
                                  permission.category === 'settings' ? '#f59e0b' :
                                  '#06b6d4',
                          }}
                        >
                          {permission.category}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </div>
      )}

      {activeView === 'activity' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-white">Recent Activity</h3>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={AXIOM.buttons.secondary}
            >
              <Filter className="size-4" />
              Filter
            </motion.button>
          </div>

          <div className="space-y-3">
            {activityLog.map((activity) => (
              <div
                key={activity.id}
                className="p-4 rounded-xl flex items-start gap-4"
                style={AXIOM.containers.item}
              >
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{
                    background: activity.type === 'invite' ? AXIOM.iconBoxes.cyan :
                               activity.type === 'permission' ? AXIOM.iconBoxes.purple :
                               activity.type === 'role' ? AXIOM.iconBoxes.amber :
                               AXIOM.iconBoxes.green,
                    boxShadow: activity.type === 'invite' ? AXIOM.shadows.iconCyan :
                              activity.type === 'permission' ? AXIOM.shadows.iconPurple :
                              activity.type === 'role' ? AXIOM.shadows.iconAmber :
                              AXIOM.shadows.iconGreen,
                  }}
                >
                  {activity.type === 'invite' && <Mail className="size-5 text-white" />}
                  {activity.type === 'permission' && <Shield className="size-5 text-white" />}
                  {activity.type === 'role' && <Crown className="size-5 text-white" />}
                  {activity.type === 'login' && <Activity className="size-5 text-white" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-white font-medium">{activity.user}</p>
                      <p className="text-sm text-slate-400">{activity.action}</p>
                      <p className="text-xs text-slate-500 mt-1">{activity.details}</p>
                    </div>
                    <span className="text-xs text-slate-500">{formatDateTime(activity.timestamp)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {activeView === 'invitations' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-bold text-white">Pending Invitations</h3>
              <p className="text-sm text-slate-400 mt-1">Team members awaiting acceptance</p>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => toast.success('Invite sent')}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={{
                background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                border: '1px solid rgba(6, 182, 212, 0.5)',
                boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
                color: '#ffffff',
              }}
            >
              <Plus className="size-4" />
              New Invite
            </motion.button>
          </div>

          <div className="space-y-3">
            {teamMembers.filter(m => m.status === 'pending').map((member) => (
              <div
                key={member.id}
                className="p-6 rounded-xl"
                style={AXIOM.containers.item}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{
                        background: AXIOM.iconBoxes.amber,
                        boxShadow: AXIOM.shadows.iconAmber,
                      }}
                    >
                      <span className="text-white font-bold text-lg">{member.name[0]}</span>
                    </div>
                    <div>
                      <p className="text-white font-medium">{member.name}</p>
                      <p className="text-sm text-slate-400">{member.email}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span 
                          className="px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1"
                          style={getRoleBadge(member.role)}
                        >
                          {getRoleIcon(member.role)}
                          {member.role.replace('_', ' ')}
                        </span>
                        <span className="text-xs text-slate-500">
                          Invited {member.joinedDate ? formatDate(member.joinedDate) : 'recently'}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
                      style={AXIOM.buttons.secondary}
                      onClick={() => toast.success('Invitation resent')}
                    >
                      <Mail className="size-4" />
                      Resend
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
                      style={AXIOM.buttons.danger}
                      onClick={() => toast.success('Invitation cancelled')}
                    >
                      <Trash2 className="size-4" />
                      Cancel
                    </motion.button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}