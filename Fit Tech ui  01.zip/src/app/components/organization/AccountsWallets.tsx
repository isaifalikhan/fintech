import { useState } from 'react';
import { motion } from 'motion/react';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';
import { formatCurrency } from '@/lib/formatters';
import { Plus, Wallet, TrendingUp, Building2, Banknote, Edit, Eye, CreditCard, DollarSign } from 'lucide-react';
import { useTheme } from '../../../contexts/ThemeContext';
import { AXIOM } from '../../../styles/axiom-tokens';
import { toast } from 'sonner';

// Map BankAccount.accountType to a simplified display category
type AccountCategory = 'bank' | 'cash' | 'virtual';

function getAccountCategory(accountType: string): AccountCategory {
  if (['checking', 'savings', 'business', 'payroll'].includes(accountType)) return 'bank';
  if (['credit', 'investment'].includes(accountType)) return 'virtual';
  return 'cash';
}

export function AccountsWallets() {
  const { theme } = useTheme();
  const [selectedType, setSelectedType] = useState<'all' | AccountCategory>('all');

  const svc = useOrgServices();
  const { data: bankAccounts = [], loading } = useService(
    () => svc.accounts.getBankAccounts(),
    [svc.orgId]
  );

  const filteredAccounts = selectedType === 'all'
    ? bankAccounts
    : bankAccounts.filter(a => getAccountCategory(a.accountType) === selectedType);

  const totalBankBalance = bankAccounts
    .filter(a => getAccountCategory(a.accountType) === 'bank')
    .reduce((sum, a) => sum + (a.currency === 'PKR' ? a.balance : a.balance * 280), 0);

  const totalVirtual = bankAccounts
    .filter(a => getAccountCategory(a.accountType) === 'virtual')
    .reduce((sum, a) => sum + (a.currency === 'PKR' ? a.balance : a.balance * 280), 0);

  const totalCash = bankAccounts
    .filter(a => getAccountCategory(a.accountType) === 'cash')
    .reduce((sum, a) => sum + (a.currency === 'PKR' ? a.balance : a.balance * 280), 0);

  const totalBalance = totalBankBalance + totalCash + totalVirtual;

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <Wallet className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>Accounts & Wallets</h1>
              <p className="text-slate-400 text-sm">Manage all your bank accounts, cash, and virtual wallets</p>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
            style={{
              background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
              border: '1px solid rgba(6, 182, 212, 0.5)',
              boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
              color: '#ffffff',
            }}
            onClick={() => toast.info('Add Account feature coming soon')}
          >
            <Plus className="size-4" />
            Add Account
          </motion.button>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Balance</p>
              <p className="text-2xl font-bold text-white">{formatCurrency(totalBalance, 'PKR')}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <DollarSign className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Bank Accounts</p>
              <p className="text-2xl font-bold text-cyan-400">{formatCurrency(totalBankBalance, 'PKR')}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.blue,
                boxShadow: AXIOM.shadows.iconBlue,
              }}
            >
              <Building2 className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Cash in Hand</p>
              <p className="text-2xl font-bold text-emerald-400">{formatCurrency(totalCash, 'PKR')}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.green,
                boxShadow: AXIOM.shadows.iconGreen,
              }}
            >
              <Banknote className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Virtual Wallets</p>
              <p className="text-2xl font-bold text-purple-400">{formatCurrency(totalVirtual, 'PKR')}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Wallet className="size-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Filter Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex gap-2"
      >
        {(['all', 'bank', 'cash', 'virtual'] as const).map((type) => (
          <motion.button
            key={type}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2 rounded-xl text-sm font-medium capitalize"
            style={
              selectedType === type
                ? {
                    background: 'rgba(168, 85, 247, 0.3)',
                    border: '1px solid rgba(168, 85, 247, 0.5)',
                    color: '#ffffff',
                  }
                : {
                    background: 'rgba(0, 0, 0, 0.2)',
                    border: 'none',
                    color: 'rgba(148, 163, 184, 0.7)',
                  }
            }
            onClick={() => setSelectedType(type)}
          >
            {type === 'all' ? 'All Accounts' : `${type} ${type === 'cash' ? '' : 'Accounts'}`}
          </motion.button>
        ))}
      </motion.div>

      {/* Accounts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAccounts.map((account, idx) => {
          const iconData = 
            account.accountType === 'bank' ? { icon: Building2, box: AXIOM.iconBoxes.blue, shadow: AXIOM.shadows.iconBlue, color: '#06b6d4' } :
            account.accountType === 'cash' ? { icon: Banknote, box: AXIOM.iconBoxes.green, shadow: AXIOM.shadows.iconGreen, color: '#10b981' } :
            { icon: Wallet, box: AXIOM.iconBoxes.purple, shadow: AXIOM.shadows.iconPurple, color: '#a855f7' };
          
          const Icon = iconData.icon;

          return (
            <motion.div
              key={account.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35 + idx * 0.05 }}
              className="p-6 rounded-2xl group"
              style={AXIOM.containers.list}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{
                      background: iconData.box,
                      boxShadow: iconData.shadow,
                    }}
                  >
                    <Icon className="size-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg">{account.accountName}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span 
                        className="px-2 py-0.5 rounded-lg text-xs font-medium capitalize"
                        style={AXIOM.badges.cyan}
                      >
                        business
                      </span>
                      <span className="text-xs capitalize" style={{ color: AXIOM.text.slate400 }}>
                        {account.accountType}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Balance */}
              <div className="mb-6">
                <p className="text-slate-400 text-xs mb-1">Current Balance</p>
                <p className="text-3xl font-bold text-white font-mono">
                  {formatCurrency(account.balance, account.currency)}
                </p>
              </div>

              {/* Details */}
              <div className="space-y-3 mb-6">
                {account.bankName && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm" style={{ color: AXIOM.text.slate400 }}>Bank</span>
                    <span className="text-sm text-white font-medium">{account.bankName}</span>
                  </div>
                )}
                {account.accountNumber && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm" style={{ color: AXIOM.text.slate400 }}>Account Number</span>
                    <span className="text-sm text-white font-mono">{account.accountNumber}</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-sm" style={{ color: AXIOM.text.slate400 }}>Currency</span>
                  <span className="text-sm text-white font-medium">{account.currency}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 px-4 py-2 rounded-xl text-sm font-medium flex items-center justify-center gap-2"
                  style={{
                    background: 'rgba(168, 85, 247, 0.3)',
                    border: '1px solid rgba(168, 85, 247, 0.5)',
                    color: '#ffffff',
                  }}
                  onClick={() => toast.info('View Transactions feature coming soon')}
                >
                  <Eye className="size-4" />
                  View Transactions
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{
                    background: 'rgba(0, 0, 0, 0.2)',
                    border: 'none',
                    color: AXIOM.text.slate400,
                  }}
                  onClick={() => toast.info('Edit Account feature coming soon')}
                >
                  <Edit className="size-4" />
                </motion.button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredAccounts.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="p-12 rounded-2xl text-center"
          style={AXIOM.containers.list}
        >
          <div 
            className="w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4"
            style={{
              background: AXIOM.iconBoxes.purple,
              boxShadow: AXIOM.shadows.iconPurple,
            }}
          >
            <Wallet className="size-8 text-white" />
          </div>
          <p className="text-white font-bold text-lg mb-2">No accounts found</p>
          <p className="text-slate-400 text-sm">Try selecting a different filter or add a new account</p>
        </motion.div>
      )}
    </div>
  );
}