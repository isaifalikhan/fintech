import { useState } from 'react';
import { motion } from 'motion/react';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';
import { formatCurrency, formatDate } from '@/lib/formatters';
import { exportTransactions } from '../../../lib/exportUtils';
import { Search, Filter, Download, Edit, Split, CheckSquare, X, Calendar, DollarSign, Tag, FileText, Trash2, Copy, History, TrendingUp, TrendingDown, Receipt } from 'lucide-react';
import { toast } from 'sonner';
import { TransactionHistoryModal } from './TransactionHistoryModal';
import { useTheme } from '../../../contexts/ThemeContext';
import { AXIOM } from '../../../styles/axiom-tokens';

// ── Type adapter ───────────────────────────────────────────────────────────────
// Bridges the NEW Transaction type (debit/credit, categoryId) to the
// shape the existing UI expects (income/expense, category string, scope).
// When a real backend arrives, remove this adapter and update the JSX directly.
function adaptTransaction(
  txn: any,
  categoryMap: Map<string, string>
) {
  return {
    ...txn,
    type: txn.type === 'credit' ? 'income' : 'expense',
    category: categoryMap.get(txn.categoryId ?? '') ?? 'Uncategorised',
    scope: 'business' as const,           // NEW type has no scope field
    account: txn.bankAccountId ?? '',      // keep FK as account reference
    narration: txn.narration ?? txn.description ?? '',
  };
}

export function TransactionsLedger() {
  const { theme } = useTheme();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterScope, setFilterScope] = useState<'all' | 'business' | 'personal'>('all');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [amountFrom, setAmountFrom] = useState('');
  const [amountTo, setAmountTo] = useState('');
  const [selectedTransactions, setSelectedTransactions] = useState<string[]>([]);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [splitDialogOpen, setSplitDialogOpen] = useState(false);
  const [bulkEditDialogOpen, setBulkEditDialogOpen] = useState(false);
  const [advancedFiltersOpen, setAdvancedFiltersOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<any>(null);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);

  // ── Service wiring ───────────────────────────────────────────────────────
  const svc = useOrgServices();

  const { data: txnResult, loading: txnLoading } = useService(
    () => svc.transactions.getAll({ pageSize: 500 }),
    [svc.orgId]
  );

  const { data: categories = [] } = useService(
    () => svc.categories.getAll(),
    [svc.orgId]
  );

  // Build lookup maps for adapting new → old field shapes
  const categoryMap = new Map(categories.map(c => [c.id, c.name]));

  // Adapted transactions match the UI's expected shape
  const allTransactions = (txnResult?.items ?? []).map(t => adaptTransaction(t, categoryMap));

  // Derived category list for filter dropdown
  const categoryList = Array.from(new Set(allTransactions.map(t => t.category)));

  const filteredTransactions = allTransactions.filter(txn => {
    const matchesSearch = txn.narration.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         txn.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesScope = filterScope === 'all' || txn.scope === filterScope;
    const matchesType = filterType === 'all' || txn.type === filterType;
    const matchesCategory = filterCategory === 'all' || txn.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || txn.status === filterStatus;
    
    const matchesDateFrom = !dateFrom || new Date(txn.date) >= new Date(dateFrom);
    const matchesDateTo = !dateTo || new Date(txn.date) <= new Date(dateTo);
    
    const matchesAmountFrom = !amountFrom || txn.amount >= parseFloat(amountFrom);
    const matchesAmountTo = !amountTo || txn.amount <= parseFloat(amountTo);
    
    return matchesSearch && matchesScope && matchesType && matchesCategory && 
           matchesStatus && matchesDateFrom && matchesDateTo && matchesAmountFrom && matchesAmountTo;
  });

  const toggleSelectAll = () => {
    if (selectedTransactions.length === filteredTransactions.length) {
      setSelectedTransactions([]);
    } else {
      setSelectedTransactions(filteredTransactions.map(t => t.id));
    }
  };

  const toggleSelectTransaction = (id: string) => {
    setSelectedTransactions(prev => 
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  const handleBulkCategorize = (category: string) => {
    toast.success(`Updated ${selectedTransactions.length} transactions to ${category}`);
    setSelectedTransactions([]);
    setBulkEditDialogOpen(false);
  };

  const handleBulkDelete = () => {
    toast.success(`Deleted ${selectedTransactions.length} transactions`);
    setSelectedTransactions([]);
  };

  const handleEditTransaction = (txn: any) => {
    setSelectedTransaction(txn);
    setEditDialogOpen(true);
  };

  const handleSplitTransaction = (txn: any) => {
    setSelectedTransaction(txn);
    setSplitDialogOpen(true);
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilterScope('all');
    setFilterType('all');
    setFilterCategory('all');
    setFilterStatus('all');
    setDateFrom('');
    setDateTo('');
    setAmountFrom('');
    setAmountTo('');
  };

  const totalIncome = filteredTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = filteredTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="min-h-screen p-8 space-y-6" style={{ background: AXIOM.backgrounds.main }}>
      {/* Header */}
      <motion.div {...AXIOM.animations.fadeInTop}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.purple,
                boxShadow: AXIOM.shadows.iconPurple,
              }}
            >
              <Receipt className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold" style={AXIOM.text.titleStyle}>Transactions Ledger</h1>
              <p className="text-slate-400 text-sm">All income and expenses in one unified view</p>
            </div>
          </div>
          <div className="flex gap-2">
            {selectedTransactions.length > 0 && (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
                style={{
                  background: 'rgba(168, 85, 247, 0.3)',
                  border: '1px solid rgba(168, 85, 247, 0.5)',
                  color: '#ffffff',
                }}
                onClick={() => setBulkEditDialogOpen(true)}
              >
                <CheckSquare className="size-4" />
                Bulk Edit ({selectedTransactions.length})
              </motion.button>
            )}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={{
                background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4))',
                border: '1px solid rgba(6, 182, 212, 0.5)',
                boxShadow: '0 10px 30px -10px rgba(6, 182, 212, 0.6)',
                color: '#ffffff',
              }}
              onClick={() => exportTransactions(filteredTransactions)}
            >
              <Download className="size-4" />
              Export
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Income</p>
              <p className="text-2xl font-bold text-emerald-400">+{formatCurrency(totalIncome, 'PKR')}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.green,
                boxShadow: AXIOM.shadows.iconGreen,
              }}
            >
              <TrendingUp className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Total Expense</p>
              <p className="text-2xl font-bold text-red-400">-{formatCurrency(totalExpense, 'PKR')}</p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.red,
                boxShadow: AXIOM.shadows.iconRed,
              }}
            >
              <TrendingDown className="size-6 text-white" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-6 rounded-2xl"
          style={AXIOM.containers.list}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-1">Net</p>
              <p className={`text-2xl font-bold ${totalIncome - totalExpense >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {totalIncome - totalExpense >= 0 ? '+' : ''}{formatCurrency(totalIncome - totalExpense, 'PKR')}
              </p>
            </div>
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <DollarSign className="size-6 text-white" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="p-6 rounded-2xl"
        style={AXIOM.containers.list}
      >
        <div className="space-y-4">
          <div className="flex flex-wrap gap-3">
            {/* Search */}
            <div className="flex-1 min-w-64 relative">
              <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search narration or category..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-10 pl-10 pr-4 rounded-xl"
                style={{
                  background: AXIOM.inputs.background,
                  border: AXIOM.inputs.border,
                  color: AXIOM.inputs.color,
                }}
              />
            </div>

            {/* Quick Filters */}
            <select 
              value={filterScope}
              onChange={(e) => setFilterScope(e.target.value as any)}
              className="h-10 px-3 rounded-xl"
              style={{
                background: AXIOM.inputs.background,
                border: AXIOM.inputs.border,
                color: AXIOM.inputs.color,
              }}
            >
              <option value="all">All Scopes</option>
              <option value="business">Business</option>
              <option value="personal">Personal</option>
            </select>

            <select 
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="h-10 px-3 rounded-xl"
              style={{
                background: AXIOM.inputs.background,
                border: AXIOM.inputs.border,
                color: AXIOM.inputs.color,
              }}
            >
              <option value="all">All Types</option>
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </select>

            <select 
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="h-10 px-3 rounded-xl"
              style={{
                background: AXIOM.inputs.background,
                border: AXIOM.inputs.border,
                color: AXIOM.inputs.color,
              }}
            >
              <option value="all">All Categories</option>
              {categoryList.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="h-10 px-4 rounded-xl text-sm font-medium flex items-center gap-2"
              style={{
                background: 'rgba(168, 85, 247, 0.3)',
                border: '1px solid rgba(168, 85, 247, 0.5)',
                color: '#ffffff',
              }}
              onClick={() => setAdvancedFiltersOpen(!advancedFiltersOpen)}
            >
              <Filter className="size-4" />
              Advanced
            </motion.button>
          </div>

          {/* Advanced Filters */}
          {advancedFiltersOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="pt-4 border-t grid grid-cols-2 md:grid-cols-5 gap-3"
              style={{ borderColor: 'rgba(148, 163, 184, 0.1)' }}
            >
              <div>
                <label className="text-xs font-medium mb-1.5 block" style={{ color: AXIOM.text.slate400 }}>Date From</label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
              </div>
              <div>
                <label className="text-xs font-medium mb-1.5 block" style={{ color: AXIOM.text.slate400 }}>Date To</label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
              </div>
              <div>
                <label className="text-xs font-medium mb-1.5 block" style={{ color: AXIOM.text.slate400 }}>Amount From</label>
                <input
                  type="number"
                  placeholder="0"
                  value={amountFrom}
                  onChange={(e) => setAmountFrom(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
              </div>
              <div>
                <label className="text-xs font-medium mb-1.5 block" style={{ color: AXIOM.text.slate400 }}>Amount To</label>
                <input
                  type="number"
                  placeholder="999999"
                  value={amountTo}
                  onChange={(e) => setAmountTo(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl"
                  style={{
                    background: AXIOM.inputs.background,
                    border: AXIOM.inputs.border,
                    color: AXIOM.inputs.color,
                  }}
                />
              </div>
              <div className="flex items-end">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full h-10 rounded-xl text-sm font-medium"
                  style={{
                    background: 'rgba(0, 0, 0, 0.2)',
                    border: 'none',
                    color: 'rgba(148, 163, 184, 0.7)',
                  }}
                  onClick={clearFilters}
                >
                  Clear Filters
                </motion.button>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>

      {/* Results Info */}
      {(searchTerm || filterScope !== 'all' || filterType !== 'all' || filterCategory !== 'all' || dateFrom || dateTo) && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center justify-between px-4 py-3 rounded-xl"
          style={AXIOM.containers.item}
        >
          <p className="text-sm" style={{ color: AXIOM.text.slate300 }}>
            Showing {filteredTransactions.length} of {allTransactions.length} transactions
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="text-sm flex items-center gap-1"
            style={{ color: AXIOM.text.slate400 }}
            onClick={clearFilters}
          >
            <X className="size-4" />
            Clear all
          </motion.button>
        </motion.div>
      )}

      {/* Transactions Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="rounded-2xl overflow-hidden"
        style={AXIOM.containers.list}
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(148, 163, 184, 0.1)' }}>
                <th className="px-4 py-4 text-left">
                  <input
                    type="checkbox"
                    checked={selectedTransactions.length === filteredTransactions.length && filteredTransactions.length > 0}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 rounded"
                    style={{
                      accentColor: '#a855f7',
                    }}
                  />
                </th>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Date</th>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Narration</th>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Category</th>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Account</th>
                <th className="px-4 py-4 text-left text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Scope</th>
                <th className="px-4 py-4 text-right text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Amount</th>
                <th className="px-4 py-4 text-center text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Status</th>
                <th className="px-4 py-4 text-right text-xs font-medium" style={{ color: AXIOM.text.slate400 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center" style={{ color: AXIOM.text.slate400 }}>
                    No transactions found. Try adjusting your filters.
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((txn, idx) => (
                  <motion.tr
                    key={txn.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.35 + idx * 0.02 }}
                    className="group"
                    style={{
                      borderBottom: '1px solid rgba(148, 163, 184, 0.05)',
                      background: selectedTransactions.includes(txn.id) ? 'rgba(168, 85, 247, 0.05)' : 'transparent',
                    }}
                  >
                    <td className="px-4 py-4">
                      <input
                        type="checkbox"
                        checked={selectedTransactions.includes(txn.id)}
                        onChange={() => toggleSelectTransaction(txn.id)}
                        className="w-4 h-4 rounded"
                        style={{
                          accentColor: '#a855f7',
                        }}
                      />
                    </td>
                    <td className="px-4 py-4 text-sm" style={{ color: AXIOM.text.slate300 }}>
                      {formatDate(txn.date)}
                    </td>
                    <td className="px-4 py-4">
                      <div>
                        <p className="text-sm font-medium text-white">{txn.narration}</p>
                        {txn.department && (
                          <p className="text-xs" style={{ color: AXIOM.text.slate400 }}>{txn.department}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-sm" style={{ color: AXIOM.text.slate300 }}>{txn.category}</td>
                    <td className="px-4 py-4 text-sm" style={{ color: AXIOM.text.slate300 }}>{txn.accountName}</td>
                    <td className="px-4 py-4">
                      <span 
                        className="px-2 py-1 rounded-lg text-xs font-medium"
                        style={txn.scope === 'business' ? AXIOM.badges.cyan : AXIOM.badges.purple}
                      >
                        {txn.scope}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-right">
                      <span 
                        className="text-sm font-bold font-mono"
                        style={{ color: txn.type === 'income' ? '#10b981' : '#ef4444' }}
                      >
                        {txn.type === 'income' ? '+' : '-'}{formatCurrency(txn.amount, txn.currency)}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-center">
                      <span 
                        className="px-2 py-1 rounded-lg text-xs font-medium"
                        style={
                          txn.status === 'auto' ? AXIOM.badges.info :
                          txn.status === 'reviewed' ? AXIOM.badges.success :
                          AXIOM.badges.warning
                        }
                      >
                        {txn.status}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{
                            background: 'rgba(0, 0, 0, 0.2)',
                            color: AXIOM.text.slate400,
                          }}
                          onClick={() => handleEditTransaction(txn)}
                        >
                          <Edit className="size-3" />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{
                            background: 'rgba(0, 0, 0, 0.2)',
                            color: AXIOM.text.slate400,
                          }}
                          onClick={() => handleSplitTransaction(txn)}
                        >
                          <Split className="size-3" />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{
                            background: 'rgba(0, 0, 0, 0.2)',
                            color: AXIOM.text.slate400,
                          }}
                          onClick={() => {
                            setSelectedTransaction(txn);
                            setHistoryDialogOpen(true);
                          }}
                        >
                          <History className="size-3" />
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* History Modal */}
      {historyDialogOpen && selectedTransaction && (
        <TransactionHistoryModal
          transaction={selectedTransaction}
          open={historyDialogOpen}
          onClose={() => setHistoryDialogOpen(false)}
        />
      )}
    </div>
  );
}