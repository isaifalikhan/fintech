import { formatCurrency } from '@/lib/formatters';
import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';
import { 
  TrendingUp, 
  Wallet, 
  DollarSign, 
  Plus, 
  Upload, 
  Settings, 
  BarChart3,
  Activity,
  Calendar,
  ArrowUpRight,
  Zap,
  Target,
  PieChart as PieChartIcon,
  TrendingDown,
  Users
} from 'lucide-react';
import { Button } from './ui/button';
import { useTheme } from '../../contexts/ThemeContext';
import { ModernKPICard } from './ModernKPICard';
import { ModernSidebarWidget } from './ModernSidebarWidget';
import { cn } from './ui/utils';
import { 
  ChartContainer, 
  SmoothAreaChart, 
  ModernBarChart,
  DonutChart,
  ComboChart,
  ProgressRing,
  Sparkline,
  MODERN_COLORS
} from './charts/ModernFinanceCharts';
import { AXIOM } from '../../styles/axiom-tokens';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Area, 
  AreaChart as RechartsAreaChart,
  ComposedChart as RechartsComposedChart,
  Bar,
  Legend
} from 'recharts';
import { motion } from 'framer-motion';

// ── Inline fallback analytics (replaces mockData import) ───────────────────
const FALLBACK_ANALYTICS = {
  netWorth: 2940000,
  cashInHand: 125000,
  monthlyProfit: 450000,
};

export function OrganizationDashboard() {
  const navigate = useNavigate();
  const { theme = 'dark' } = useTheme();
  const [selectedPeriod, setSelectedPeriod] = useState<'1W' | '1M' | '3M' | '6M' | '1Y'>('1M');

  // ── Service wiring ──────────────────────────────────────────────────────
  const svc = useOrgServices();
  const { data: bankAccounts = [] } = useService(
    () => svc.accounts.getBankAccounts(),
    [svc.orgId]
  );
  const { data: kpis } = useService(
    () => svc.reports.getDashboardSummary(),
    [svc.orgId]
  );
  const { data: txnResult } = useService(
    () => svc.transactions.getAll({ pageSize: 20 }),
    [svc.orgId]
  );

  // ── Derived KPI values (service data → fallback to mockAnalytics) ────────
  const totalBalance = bankAccounts.length > 0
    ? bankAccounts.reduce((sum, acc) => {
        if (acc.currency === 'PKR') return sum + acc.balance;
        if (acc.currency === 'USD') return sum + (acc.balance * 280);
        return sum;
      }, 0)
    : FALLBACK_ANALYTICS.netWorth;

  const cashInHand   = kpis?.cashOnHand   ?? FALLBACK_ANALYTICS.cashInHand;
  const monthlyProfit = kpis?.netProfit    ?? FALLBACK_ANALYTICS.monthlyProfit;
  const netWorth     = kpis?.totalRevenue  ?? FALLBACK_ANALYTICS.netWorth;

  // ── Transaction adapter: NEW (debit/credit) → UI shape (income/expense) ─
  const rawTxns = txnResult?.items ?? [];
  const recentTransactions = rawTxns.slice(0, 10).map(t => ({
    id: t.id,
    date: t.date,
    title: (t as any).narration ?? (t as any).description ?? '',
    amount: t.amount,
    type: t.type === 'credit' ? 'income' as const : 'expense' as const,
  }));
  const upcomingPayments = rawTxns
    .filter(t => t.type === 'debit')
    .slice(0, 5)
    .map(t => ({
      id: t.id,
      date: t.date,
      title: (t as any).narration ?? (t as any).description ?? '',
      amount: t.amount,
      type: 'expense' as const,
    }));
  // ─────────────────────────────────────────────────────────────────────────

  // Chart data
  const profitData = Array.from({ length: 12 }, (_, i) => ({
    name: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i],
    Revenue: 2000000 + Math.sin(i * 0.5) * 500000 + i * 150000,
    Expenses: 1200000 + Math.cos(i * 0.7) * 300000 + i * 80000,
    Profit: 800000 + Math.sin(i * 0.3) * 400000 + i * 100000,
  }));

  const departmentData = Array.from({ length: 12 }, (_, i) => ({
    name: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i],
    Development: 1500000 + Math.sin(i * 0.5) * 400000 + i * 120000,
    Design: 800000 + Math.cos(i * 0.7) * 250000 + i * 80000,
    Marketing: 600000 + Math.sin(i * 0.3) * 200000 + i * 60000,
    Sales: 1000000 + Math.cos(i * 0.6) * 300000 + i * 90000,
  }));

  // Expense category data for donut chart
  const expenseCategoryData = [
    { name: 'Salaries', value: 1500000, color: MODERN_COLORS.primary },
    { name: 'Operations', value: 800000, color: MODERN_COLORS.secondary },
    { name: 'Marketing', value: 500000, color: MODERN_COLORS.info },
    { name: 'Technology', value: 400000, color: MODERN_COLORS.success },
    { name: 'Other', value: 300000, color: MODERN_COLORS.warning },
  ];

  // Monthly comparison data for combo chart
  const monthlyComparisonData = Array.from({ length: 6 }, (_, i) => ({
    name: ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i],
    Revenue: 2000000 + Math.random() * 500000,
    Expenses: 1200000 + Math.random() * 300000,
    Profit: 800000 + Math.random() * 200000,
  }));

  return (
    <div 
      className="min-h-full"
      style={{
        background: theme === 'dark' ? AXIOM.backgrounds.main : '#f8fafc',
      }}
    >
      {/* Ambient gradient orbs - ONLY IN DARK MODE */}
      {theme === 'dark' && (
        <>
          <div className="fixed top-20 left-20 w-96 h-96 bg-gradient-to-br from-indigo-600/10 to-purple-600/10 rounded-full blur-[120px] animate-pulse pointer-events-none" />
          <div className="fixed bottom-20 right-20 w-96 h-96 bg-gradient-to-br from-blue-600/10 to-cyan-600/10 rounded-full blur-[120px] animate-pulse pointer-events-none" style={{ animationDelay: '1s' }} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-br from-violet-600/5 to-fuchsia-600/5 rounded-full blur-[140px] animate-pulse pointer-events-none" style={{ animationDelay: '0.5s' }} />
        </>
      )}
      
      {/* Top Bar - AXIOM STYLED */}
      <motion.div
        {...AXIOM.animations.fadeInTop}
        className="sticky top-0 z-50 backdrop-blur-lg border-b px-8 py-6"
        style={{
          background: theme === 'dark' 
            ? AXIOM.backgrounds.topBar
            : 'linear-gradient(180deg, rgba(255, 255, 255, 0.95) 0%, rgba(248, 250, 252, 0.9) 100%)',
          borderBottom: theme === 'dark' 
            ? AXIOM.borders.topBar
            : '1px solid rgba(148, 163, 184, 0.2)',
        }}
      >
        <div className="flex items-center justify-between">
          {/* Header with Icon */}
          <div className="flex items-center gap-3">
            <div 
              className="p-3 rounded-xl flex items-center justify-center"
              style={{
                background: AXIOM.iconBoxes.cyan,
                boxShadow: AXIOM.shadows.iconCyan,
              }}
            >
              <BarChart3 className="size-6 text-white" />
            </div>
            <div>
              <h1 
                className="text-4xl font-bold"
                style={AXIOM.text.titleStyle}
              >
                Dashboard
              </h1>
              <p className="text-slate-400 text-sm">Welcome back, here's your financial overview</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3">
            <motion.button
              {...AXIOM.animations.hoverScale}
              onClick={() => navigate('/org/upload-statement')}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={AXIOM.buttons.secondary}
            >
              <Upload className="size-4" />
              Import
            </motion.button>
            <motion.button
              {...AXIOM.animations.hoverScale}
              className="px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2"
              style={AXIOM.buttons.action}
            >
              <Plus className="size-4" />
              Add Transaction
            </motion.button>
            <motion.button
              {...AXIOM.animations.hoverScale}
              className="p-2 rounded-xl"
              style={AXIOM.buttons.secondary}
            >
              <Settings className="size-5" />
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="max-w-[1800px] mx-auto px-6 py-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Left Content - Main Dashboard */}
          <div className="col-span-12 lg:col-span-9 space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <ModernKPICard
                icon={TrendingUp}
                label="Total Balance"
                value={totalBalance}
                currency="PKR"
                percentage="12.5%"
                trend="up"
                delay={0}
              />

              <ModernKPICard
                icon={Wallet}
                label="Cash in Hand"
                value={cashInHand}
                currency="PKR"
                percentage="8.2%"
                trend="up"
                delay={0.1}
              />

              <ModernKPICard
                icon={DollarSign}
                label="Monthly Profit"
                value={monthlyProfit}
                currency="PKR"
                percentage="15.7%"
                trend="up"
                delay={0.2}
              />

              <ModernKPICard
                icon={BarChart3}
                label="Net Worth"
                value={netWorth}
                currency="PKR"
                percentage="9.3%"
                trend="up"
                delay={0.3}
              />
            </div>

            {/* Revenue & Profit Analysis - EXACT FINANCE OS GRAPH */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              whileHover={{ y: -4 }}
              className="relative overflow-hidden rounded-3xl p-8"
              style={{
                background: theme === 'dark' 
                  ? 'linear-gradient(135deg, rgba(15, 30, 60, 0.5) 0%, rgba(5, 10, 30, 0.7) 100%)'
                  : 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                border: theme === 'dark' ? '1px solid rgba(59, 130, 246, 0.2)' : '1px solid rgba(59, 130, 246, 0.15)',
                boxShadow: theme === 'dark' 
                  ? '0 20px 60px -20px rgba(59, 130, 246, 0.5)'
                  : '0 4px 12px -2px rgba(59, 130, 246, 0.1)',
              }}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div
                    className="p-3 rounded-xl flex items-center justify-center"
                    style={{
                      background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
                      boxShadow: '0 10px 30px -10px rgba(59, 130, 246, 0.8)',
                    }}
                  >
                    <Activity className="size-5 text-white" />
                  </div>
                  <div>
                    <h3
                      className="text-xl font-bold"
                      style={{
                        color: theme === 'dark' ? '#ffffff' : '#1e293b',
                      }}
                    >
                      Revenue & Profit Analysis
                    </h3>
                    <p
                      className="text-sm mt-0.5"
                      style={{
                        color: theme === 'dark' ? '#94a3b8' : '#64748b',
                      }}
                    >
                      Track your financial performance over time
                    </p>
                  </div>
                </div>
                
                {/* Period Toggles */}
                <div className="flex items-center gap-1 p-1 rounded-lg border"
                  style={{
                    background: theme === 'dark' ? 'rgba(0, 0, 0, 0.3)' : 'rgb(249, 250, 251)',
                    borderColor: theme === 'dark' ? 'rgba(59, 130, 246, 0.2)' : 'rgb(229, 231, 235)',
                  }}
                >
                  {(['1W', '1M', '3M', '6M', '1Y'] as const).map((period) => (
                    <motion.button
                      key={period}
                      onClick={() => setSelectedPeriod(period)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-3 py-1.5 rounded-md text-xs font-semibold transition-all"
                      style={{
                        background: selectedPeriod === period 
                          ? 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)'
                          : 'transparent',
                        color: selectedPeriod === period 
                          ? '#ffffff'
                          : theme === 'dark' ? '#9ca3af' : '#6b7280',
                        boxShadow: selectedPeriod === period
                          ? '0 4px 12px -2px rgba(59, 130, 246, 0.5)'
                          : 'none',
                      }}
                    >
                      {period}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Finance OS Graph */}
              <div 
                className="relative p-6 rounded-2xl"
                style={{ 
                  minHeight: '400px', 
                  height: '400px',
                  background: theme === 'dark' 
                    ? 'rgba(0, 0, 0, 0.2)'
                    : 'rgba(255, 255, 255, 0.5)',
                  border: theme === 'dark'
                    ? '1px solid rgba(148, 163, 184, 0.1)'
                    : '1px solid rgba(148, 163, 184, 0.15)',
                }}
              >
                <ResponsiveContainer width="100%" height={380}>
                  <RechartsComposedChart data={profitData}>
                    <defs>
                      <linearGradient id="area-gradient-Revenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={MODERN_COLORS.success} stopOpacity={0.6}/>
                        <stop offset="95%" stopColor={MODERN_COLORS.success} stopOpacity={0.02}/>
                      </linearGradient>
                      <linearGradient id="area-gradient-Expenses" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={MODERN_COLORS.warning} stopOpacity={0.6}/>
                        <stop offset="95%" stopColor={MODERN_COLORS.warning} stopOpacity={0.02}/>
                      </linearGradient>
                      <linearGradient id="area-gradient-Profit" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={MODERN_COLORS.primary} stopOpacity={0.6}/>
                        <stop offset="95%" stopColor={MODERN_COLORS.primary} stopOpacity={0.02}/>
                      </linearGradient>
                    </defs>
                    
                    <CartesianGrid 
                      strokeDasharray="3 3" 
                      stroke={theme === 'dark' ? 'rgba(148, 163, 184, 0.05)' : 'rgba(148, 163, 184, 0.1)'}
                      vertical={false}
                    />
                    <XAxis 
                      dataKey="name" 
                      stroke={theme === 'dark' ? 'rgba(148, 163, 184, 0.6)' : 'rgba(100, 116, 139, 0.7)'}
                      style={{ fontSize: '12px', fontWeight: 600 }}
                      tickLine={false}
                      axisLine={{ stroke: theme === 'dark' ? 'rgba(148, 163, 184, 0.2)' : 'rgba(148, 163, 184, 0.3)' }}
                    />
                    <YAxis 
                      stroke={theme === 'dark' ? 'rgba(148, 163, 184, 0.6)' : 'rgba(100, 116, 139, 0.7)'}
                      style={{ fontSize: '12px', fontWeight: 600 }}
                      tickLine={false}
                      axisLine={{ stroke: theme === 'dark' ? 'rgba(148, 163, 184, 0.2)' : 'rgba(148, 163, 184, 0.3)' }}
                      tickFormatter={(value) => `₨${(value / 1000).toFixed(0)}K`}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: theme === 'dark' ? 'rgba(15, 23, 42, 0.98)' : 'rgba(255, 255, 255, 0.98)', 
                        border: `2px solid ${theme === 'dark' ? 'rgba(59, 130, 246, 0.5)' : 'rgba(59, 130, 246, 0.3)'}`,
                        backdropFilter: 'blur(20px)',
                        borderRadius: '12px',
                        padding: '12px 16px',
                        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)',
                      }}
                      labelStyle={{ 
                        color: theme === 'dark' ? '#ffffff' : '#1e293b', 
                        fontWeight: 700, 
                        marginBottom: '8px',
                        fontSize: '13px'
                      }}
                      itemStyle={{
                        color: theme === 'dark' ? '#94a3b8' : '#64748b',
                        fontSize: '12px',
                        fontWeight: 600
                      }}
                      formatter={(value: any) => [`₨${(value / 1000).toFixed(1)}K`, '']}
                    />
                    
                    <Area
                      type="monotone"
                      dataKey="Revenue"
                      stroke={MODERN_COLORS.success}
                      strokeWidth={3}
                      fill="url(#area-gradient-Revenue)"
                      dot={{ 
                        fill: MODERN_COLORS.success, 
                        r: 4,
                        strokeWidth: 2,
                        stroke: theme === 'dark' ? '#0a0a0a' : '#ffffff'
                      }}
                      activeDot={{ 
                        r: 6, 
                        fill: MODERN_COLORS.success,
                        stroke: theme === 'dark' ? '#0a0a0a' : '#ffffff',
                        strokeWidth: 3
                      }}
                      animationDuration={1500}
                    />
                    <Area
                      type="monotone"
                      dataKey="Expenses"
                      stroke={MODERN_COLORS.warning}
                      strokeWidth={3}
                      fill="url(#area-gradient-Expenses)"
                      dot={{ 
                        fill: MODERN_COLORS.warning, 
                        r: 4,
                        strokeWidth: 2,
                        stroke: theme === 'dark' ? '#0a0a0a' : '#ffffff'
                      }}
                      activeDot={{ 
                        r: 6, 
                        fill: MODERN_COLORS.warning,
                        stroke: theme === 'dark' ? '#0a0a0a' : '#ffffff',
                        strokeWidth: 3
                      }}
                      animationDuration={1500}
                    />
                    <Area
                      type="monotone"
                      dataKey="Profit"
                      stroke={MODERN_COLORS.primary}
                      strokeWidth={3}
                      fill="url(#area-gradient-Profit)"
                      dot={{ 
                        fill: MODERN_COLORS.primary, 
                        r: 4,
                        strokeWidth: 2,
                        stroke: theme === 'dark' ? '#0a0a0a' : '#ffffff'
                      }}
                      activeDot={{ 
                        r: 6, 
                        fill: MODERN_COLORS.primary,
                        stroke: theme === 'dark' ? '#0a0a0a' : '#ffffff',
                        strokeWidth: 3
                      }}
                      animationDuration={1500}
                    />
                  </RechartsComposedChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* Grid: Department Performance & Expense Breakdown - BLUE THEME */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Department Performance - Bar Chart */}
              <ChartContainer
                title="Department Performance"
                subtitle="Revenue by department"
                icon={Users}
                borderColor="purple"
                iconColor="purple"
                delay={0.5}
              >
                <ModernBarChart
                  data={departmentData.slice(6)} // Last 6 months
                  dataKeys={[
                    { key: 'Development', color: MODERN_COLORS.primary, name: 'Development' },
                    { key: 'Design', color: MODERN_COLORS.secondary, name: 'Design' },
                    { key: 'Marketing', color: MODERN_COLORS.warning, name: 'Marketing' },
                    { key: 'Sales', color: MODERN_COLORS.success, name: 'Sales' },
                  ]}
                  height={280}
                  stacked={true}
                />
              </ChartContainer>

              {/* Expense Categories - Donut Chart */}
              <ChartContainer
                title="Expense Categories"
                subtitle="Spending breakdown by category"
                icon={PieChartIcon}
                borderColor="pink"
                iconColor="pink"
                delay={0.6}
              >
                <DonutChart
                  data={expenseCategoryData}
                  height={280}
                  innerRadius={70}
                  outerRadius={100}
                />
              </ChartContainer>
            </div>

            {/* Monthly Comparison - Combo Chart - BLUE THEME */}
            <ChartContainer
              title="Monthly Comparison"
              subtitle="Revenue vs Expenses with Profit trend"
              icon={BarChart3}
              borderColor="green"
              iconColor="green"
              delay={0.7}
            >
              <ComboChart
                data={monthlyComparisonData}
                barKeys={[
                  { key: 'Revenue', color: MODERN_COLORS.success, name: 'Revenue' },
                  { key: 'Expenses', color: MODERN_COLORS.danger, name: 'Expenses' },
                ]}
                lineKeys={[
                  { key: 'Profit', color: MODERN_COLORS.primary, name: 'Profit' },
                ]}
                height={300}
              />
            </ChartContainer>

            {/* Account Balances - UNIFIED BLUE THEME */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="relative overflow-hidden rounded-3xl p-8"
              style={{
                background: theme === 'dark' 
                  ? 'linear-gradient(135deg, rgba(15, 30, 60, 0.5) 0%, rgba(5, 10, 30, 0.7) 100%)'
                  : 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                border: theme === 'dark' ? '1px solid rgba(59, 130, 246, 0.2)' : '1px solid rgba(59, 130, 246, 0.15)',
                boxShadow: theme === 'dark' 
                  ? '0 20px 60px -20px rgba(59, 130, 246, 0.5)'
                  : '0 4px 12px -2px rgba(59, 130, 246, 0.1)',
              }}
            >
              {/* Header with Icon Box - BLUE THEME */}
              <div className="flex items-center gap-3 mb-6">
                <div 
                  className="p-3 rounded-xl flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
                    boxShadow: '0 10px 30px -10px rgba(59, 130, 246, 0.8)',
                  }}
                >
                  <Wallet className="size-5 text-white" />
                </div>
                <div>
                  <h3 
                    className="text-xl font-bold"
                    style={{
                      color: theme === 'dark' ? '#ffffff' : '#1e293b',
                    }}
                  >
                    Account Balances
                  </h3>
                  <p className="text-sm" style={{ color: theme === 'dark' ? '#94a3b8' : '#64748b' }}>
                    All connected accounts
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {bankAccounts.slice(0, 4).map((account, index) => (
                  <motion.div
                    key={account.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 + index * 0.05 }}
                    whileHover={{ scale: 1.02, y: -4 }}
                    className="group p-4 rounded-xl border transition-all cursor-pointer"
                    style={{
                      background: theme === 'dark' 
                        ? 'rgba(15, 30, 60, 0.3)'
                        : 'rgba(255, 255, 255, 0.7)',
                      borderColor: theme === 'dark' ? 'rgba(59, 130, 246, 0.3)' : 'rgba(59, 130, 246, 0.2)',
                    }}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="text-sm font-semibold mb-1" style={{ color: theme === 'dark' ? '#e2e8f0' : '#475569' }}>
                          {account.bankName || 'Account'}
                        </p>
                        <p className="text-xs" style={{ color: theme === 'dark' ? '#94a3b8' : '#94a3b8' }}>
                          ••• {account.accountNumber?.slice(-4) || '0000'}
                        </p>
                      </div>
                      <div 
                        className="px-2 py-1 rounded-md text-xs font-bold border"
                        style={{
                          background: account.accountType !== 'credit'
                            ? 'rgba(59, 130, 246, 0.15)'
                            : 'rgba(16, 185, 129, 0.15)',
                          color: account.accountType !== 'credit'
                            ? '#60a5fa'
                            : '#34d399',
                          borderColor: account.accountType !== 'credit'
                            ? 'rgba(59, 130, 246, 0.3)'
                            : 'rgba(16, 185, 129, 0.3)',
                        }}
                      >
                        {account.accountType}
                      </div>
                    </div>

                    <div className="flex items-end justify-between">
                      <div>
                        <p 
                          className="text-xl font-bold"
                          style={{ color: theme === 'dark' ? '#ffffff' : '#1e293b' }}
                        >
                          {formatCurrency(account.balance, account.currency, { compact: true })}
                        </p>
                      </div>
                      <Sparkline 
                        data={[45, 52, 38, 45, 55, 60, 58]} 
                        color={MODERN_COLORS.success}
                        trend="up"
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Right Sidebar - Widgets - BLUE THEME */}
          <div className="col-span-12 lg:col-span-3 space-y-6">
            {/* Quick Actions - BLUE THEME */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              whileHover={{ y: -4 }}
              className="relative overflow-hidden rounded-3xl p-6"
              style={{
                background: theme === 'dark' 
                  ? 'linear-gradient(135deg, rgba(15, 30, 60, 0.5) 0%, rgba(5, 10, 30, 0.7) 100%)'
                  : 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                border: theme === 'dark' ? '1px solid rgba(59, 130, 246, 0.2)' : '1px solid rgba(59, 130, 246, 0.15)',
                boxShadow: theme === 'dark' 
                  ? '0 20px 60px -20px rgba(59, 130, 246, 0.5)'
                  : '0 4px 12px -2px rgba(59, 130, 246, 0.1)',
              }}
            >
              {/* Header with Icon */}
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="p-2.5 rounded-xl flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
                    boxShadow: '0 8px 20px -8px rgba(59, 130, 246, 0.6)',
                  }}
                >
                  <Zap className="w-4 h-4 text-white" />
                </div>
                <h3 
                  className="text-base font-bold"
                  style={{ color: theme === 'dark' ? '#ffffff' : '#1e293b' }}
                >
                  Quick Actions
                </h3>
              </div>
              
              <div className="space-y-3">
                <motion.button 
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full p-3 rounded-xl text-white text-sm font-bold flex items-center justify-between group"
                  style={{
                    background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
                    border: '1px solid rgba(59, 130, 246, 0.5)',
                    boxShadow: '0 4px 16px -4px rgba(59, 130, 246, 0.5)',
                  }}
                >
                  <span>Add Transaction</span>
                  <Plus className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </motion.button>
                <motion.button 
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full p-3 rounded-xl text-sm font-bold flex items-center justify-between group"
                  style={{
                    background: theme === 'dark'
                      ? 'rgba(15, 30, 60, 0.3)'
                      : 'rgba(255, 255, 255, 0.8)',
                    border: theme === 'dark'
                      ? '1px solid rgba(59, 130, 246, 0.3)'
                      : '1px solid rgba(148, 163, 184, 0.2)',
                    color: theme === 'dark' ? '#60a5fa' : '#3b82f6',
                  }}
                >
                  <span>Import Statement</span>
                  <Upload className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </motion.button>
                <motion.button 
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full p-3 rounded-xl text-sm font-bold flex items-center justify-between group"
                  style={{
                    background: theme === 'dark'
                      ? 'rgba(15, 30, 60, 0.3)'
                      : 'rgba(255, 255, 255, 0.8)',
                    border: theme === 'dark'
                      ? '1px solid rgba(59, 130, 246, 0.3)'
                      : '1px solid rgba(148, 163, 184, 0.2)',
                    color: theme === 'dark' ? '#60a5fa' : '#3b82f6',
                  }}
                >
                  <span>View Analytics</span>
                  <BarChart3 className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </motion.button>
              </div>
            </motion.div>

            {/* Progress Rings - Goals - BLUE THEME */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              whileHover={{ y: -4 }}
              className="relative overflow-hidden rounded-3xl p-6"
              style={{
                background: theme === 'dark' 
                  ? 'linear-gradient(135deg, rgba(15, 30, 60, 0.5) 0%, rgba(5, 10, 30, 0.7) 100%)'
                  : 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.9) 100%)',
                border: theme === 'dark' ? '1px solid rgba(59, 130, 246, 0.2)' : '1px solid rgba(59, 130, 246, 0.15)',
                boxShadow: theme === 'dark' 
                  ? '0 20px 60px -20px rgba(59, 130, 246, 0.5)'
                  : '0 4px 12px -2px rgba(59, 130, 246, 0.1)',
              }}
            >
              {/* Header with Icon */}
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="p-2.5 rounded-xl flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
                    boxShadow: '0 8px 20px -8px rgba(59, 130, 246, 0.6)',
                  }}
                >
                  <Target className="w-4 h-4 text-white" />
                </div>
                <h3 
                  className="text-base font-bold"
                  style={{ color: theme === 'dark' ? '#ffffff' : '#1e293b' }}
                >
                  Monthly Goals
                </h3>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <ProgressRing 
                  value={75} 
                  max={100} 
                  label="Revenue"
                  color={MODERN_COLORS.success}
                  size={100}
                />
                <ProgressRing 
                  value={60} 
                  max={100} 
                  label="Savings"
                  color={MODERN_COLORS.primary}
                  size={100}
                />
              </div>
            </motion.div>

            {/* Recent Activity */}
            <ModernSidebarWidget
              title="Recent Activity"
              icon={Activity}
              items={recentTransactions}
              delay={0.6}
            />

            {/* Upcoming Payments */}
            <ModernSidebarWidget
              title="Upcoming Payments"
              icon={Calendar}
              items={upcomingPayments}
              delay={0.7}
            />
          </div>
        </div>
      </div>
    </div>
  );
}