import { motion } from 'motion/react';
import { AXIOM } from '../../../styles/axiom-tokens';
import { Briefcase, Clock, Users, TrendingUp, CheckCircle, AlertCircle, ChevronRight } from 'lucide-react';
import { employeeService } from '@/services/employeeService';
import { useOrgServices } from '@/hooks/useOrgServices';
import { useService } from '@/hooks/useService';

const mockMyProjects = [
  {
    id: 'proj-002', name: 'Mobile App Development', client: 'TechStart Inc', role: 'Lead Developer',
    status: 'active', progress: 52, hoursLogged: 186, hoursEstimated: 360, dueDate: 'Aug 31, 2026',
    team: ['Alex Chen', 'David Park', 'Lisa Kumar'],
    tasks: { total: 24, completed: 12, inProgress: 5, todo: 7 },
    recentMilestones: ['API Integration Complete', 'Push Notifications Shipped'],
  },
  {
    id: 'proj-001', name: 'Website Redesign', client: 'Acme Corporation', role: 'Developer',
    status: 'active', progress: 78, hoursLogged: 64, hoursEstimated: 80, dueDate: 'Jun 30, 2026',
    team: ['Alex Chen', 'Sarah Smith'],
    tasks: { total: 16, completed: 12, inProgress: 3, todo: 1 },
    recentMilestones: ['Frontend Complete', 'CMS Integration'],
  },
  {
    id: 'proj-int', name: 'Internal Tools Migration', client: 'Internal', role: 'Contributor',
    status: 'on_hold', progress: 35, hoursLogged: 28, hoursEstimated: 80, dueDate: 'Dec 31, 2026',
    team: ['Alex Chen', 'Mike Johnson', 'Rachel Green'],
    tasks: { total: 12, completed: 4, inProgress: 1, todo: 7 },
    recentMilestones: ['Planning Phase Complete'],
  },
];

export function MyProjects() {
  const svc = useOrgServices();

  // Service-backed: fetch projects from projectService
  const { data: projectsData } = useService(
    () => svc.projects.getAll(),
    []
  );

  // Use service data or fallback to inline mock
  const projects = projectsData?.length ? projectsData.map((p: any) => ({
    id: p.id,
    name: p.name,
    client: p.clientName || 'Client',
    role: 'Developer',
    status: p.status,
    progress: p.quotedAmount > 0 ? Math.min(Math.round((p.actualCost / p.quotedAmount) * 100), 100) : 0,
    hoursLogged: p.actualCost || 0,
    hoursEstimated: p.quotedAmount || 0,
    dueDate: p.endDate || 'TBD',
    team: [],
    tasks: { total: 0, completed: 0, inProgress: 0, todo: 0 },
    recentMilestones: [],
  })) : mockMyProjects;

  return (
    <div className="p-8 space-y-8" style={{ background: AXIOM.backgrounds.main, minHeight: '100%' }}>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold mb-2" style={AXIOM.text.titleStyle as any}>My Projects</h1>
        <p className="text-slate-400 font-mono">Projects assigned to you and their progress</p>
      </motion.div>

      {/* Summary Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Active Projects', value: '2', color: 'blue', icon: Briefcase },
          { label: 'Hours This Month', value: '34.5h', color: 'green', icon: Clock },
          { label: 'Tasks In Progress', value: '8', color: 'purple', icon: TrendingUp },
          { label: 'Completed Tasks', value: '28', color: 'cyan', icon: CheckCircle },
        ].map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.05 }}
            className="rounded-xl p-5"
            style={{
              background: AXIOM.backgrounds.chartContainer,
              border: AXIOM.borders[item.color as keyof typeof AXIOM.borders],
              boxShadow: AXIOM.shadows[item.color as keyof typeof AXIOM.shadows],
            }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400 font-mono mb-1">{item.label.toUpperCase()}</p>
                <p className="text-2xl font-bold text-white">{item.value}</p>
              </div>
              <div className="size-10 rounded-lg flex items-center justify-center" style={{
                background: AXIOM.iconBoxes[item.color as keyof typeof AXIOM.iconBoxes],
              }}>
                <item.icon className="size-5 text-white" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Project Cards */}
      <div className="space-y-6">
        {projects.map((project, i) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + i * 0.1 }}
            className="rounded-2xl p-6"
            style={{
              background: AXIOM.backgrounds.chartContainer,
              border: project.status === 'active' ? AXIOM.borders.blue : AXIOM.borders.default,
              boxShadow: project.status === 'active' ? AXIOM.shadows.blue : AXIOM.shadows.default,
            }}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl text-white font-bold">{project.name}</h3>
                  <span className="text-xs font-mono px-2 py-1 rounded capitalize" style={{
                    ...(project.status === 'active' ? AXIOM.badges.success : AXIOM.badges.warning),
                  }}>
                    {project.status.replace('_', ' ')}
                  </span>
                </div>
                <p className="text-sm text-slate-400 font-mono">{project.client} - Role: {project.role}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-400 font-mono">Due</p>
                <p className="text-sm text-white font-mono">{project.dueDate}</p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-mono">Progress</span>
                <span className="text-xs text-blue-400 font-mono">{project.progress}%</span>
              </div>
              <div className="h-3 rounded-full overflow-hidden" style={{ background: 'rgba(0, 0, 0, 0.3)' }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${project.progress}%` }}
                  transition={{ delay: 0.4 + i * 0.1, duration: 0.8 }}
                  className="h-full rounded-full"
                  style={{
                    background: project.progress >= 70 ? 'linear-gradient(to right, #10b981, #06b6d4)' :
                      project.progress >= 40 ? 'linear-gradient(to right, #3b82f6, #8b5cf6)' :
                      'linear-gradient(to right, #f59e0b, #ef4444)',
                  }}
                />
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="p-3 rounded-lg" style={{ ...AXIOM.containers.item }}>
                <p className="text-xs text-slate-400 font-mono">Hours</p>
                <p className="text-lg font-bold text-white">{project.hoursLogged}<span className="text-xs text-slate-500">/{project.hoursEstimated}</span></p>
              </div>
              <div className="p-3 rounded-lg" style={{ ...AXIOM.containers.item }}>
                <p className="text-xs text-slate-400 font-mono">Completed</p>
                <p className="text-lg font-bold text-green-400">{project.tasks.completed}</p>
              </div>
              <div className="p-3 rounded-lg" style={{ ...AXIOM.containers.item }}>
                <p className="text-xs text-slate-400 font-mono">In Progress</p>
                <p className="text-lg font-bold text-blue-400">{project.tasks.inProgress}</p>
              </div>
              <div className="p-3 rounded-lg" style={{ ...AXIOM.containers.item }}>
                <p className="text-xs text-slate-400 font-mono">To Do</p>
                <p className="text-lg font-bold text-slate-400">{project.tasks.todo}</p>
              </div>
            </div>

            {/* Team & Milestones */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="size-4 text-slate-400" />
                <div className="flex -space-x-2">
                  {project.team.map((member, j) => (
                    <div key={j} className="size-7 rounded-full flex items-center justify-center text-[10px] text-white font-bold" style={{
                      background: ['#3b82f6', '#a855f7', '#10b981', '#f59e0b'][j % 4],
                      border: '2px solid rgba(10, 10, 10, 0.8)',
                    }}>
                      {member.split(' ').map(n => n[0]).join('')}
                    </div>
                  ))}
                </div>
                <span className="text-xs text-slate-400 font-mono">{project.team.length} members</span>
              </div>
              <div className="flex items-center gap-2">
                {project.recentMilestones.slice(0, 2).map((m, j) => (
                  <span key={j} className="text-[10px] font-mono px-2 py-1 rounded" style={AXIOM.badges.info}>
                    {m}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}