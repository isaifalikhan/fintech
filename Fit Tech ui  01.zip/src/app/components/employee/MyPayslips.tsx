import { motion } from 'motion/react';
import { AXIOM } from '../../../styles/axiom-tokens';
import { FileText, Download, Eye, DollarSign, TrendingUp, Calendar } from 'lucide-react';
import { employeeService } from '@/services/employeeService';
import { useService } from '@/hooks/useService';
import { useAuth } from '@/contexts/AuthContext';

// Service-backed: employeeService.getPayslips(orgId, userId)
// TODO: Replace mockPayslips with useService(() => employeeService.getPayslips(orgId, userId))
const mockPayslips = [
  { id: 'ps-001', period: 'February 2026', date: '2026-02-28', gross: 8500, deductions: 1700, net: 6800, status: 'paid' },
  { id: 'ps-002', period: 'January 2026', date: '2026-01-31', gross: 8500, deductions: 1700, net: 6800, status: 'paid' },
  { id: 'ps-003', period: 'December 2025', date: '2025-12-31', gross: 8500, deductions: 1700, net: 6800, status: 'paid' },
  { id: 'ps-004', period: 'November 2025', date: '2025-11-30', gross: 8500, deductions: 1850, net: 6650, status: 'paid' },
  { id: 'ps-005', period: 'October 2025', date: '2025-10-31', gross: 8500, deductions: 1700, net: 6800, status: 'paid' },
];

export function MyPayslips() {
  // Service-ready: swap with useService(() => employeeService.getPayslips(orgId, userId))
  const payslips = mockPayslips;

  const ytdGross = payslips?.reduce((s, p) => s + p.gross, 0) || 0;
  const ytdNet = payslips?.reduce((s, p) => s + p.net, 0) || 0;

  return (
    <div className="p-8 space-y-8" style={{ background: AXIOM.backgrounds.main, minHeight: '100%' }}>
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-4xl font-bold mb-2" style={AXIOM.text.titleStyle as any}>Payslips</h1>
        <p className="text-slate-400 font-mono">View and download your salary statements</p>
      </motion.div>

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'LAST NET PAY', value: `$${payslips?.[0]?.net.toLocaleString() || '0'}`, sub: payslips?.[0]?.period || 'N/A', color: 'green', icon: DollarSign },
          { label: 'YTD GROSS', value: `$${ytdGross.toLocaleString()}`, sub: `${payslips?.length || 0} payslips`, color: 'blue', icon: TrendingUp },
          { label: 'YTD NET', value: `$${ytdNet.toLocaleString()}`, sub: 'After deductions', color: 'purple', icon: FileText },
        ].map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.05 }}
            className="rounded-2xl p-6 relative overflow-hidden"
            style={{
              background: AXIOM.backgrounds.chartContainer,
              border: AXIOM.borders[item.color as keyof typeof AXIOM.borders],
              boxShadow: AXIOM.shadows[item.color as keyof typeof AXIOM.shadows],
            }}
          >
            <div className="flex items-start justify-between relative z-10">
              <div>
                <p className="text-xs text-slate-400 font-mono mb-2">{item.label}</p>
                <p className="text-3xl font-bold text-white mb-1">{item.value}</p>
                <p className="text-sm text-slate-400 font-mono">{item.sub}</p>
              </div>
              <div className="size-12 rounded-xl flex items-center justify-center" style={{
                background: AXIOM.iconBoxes[item.color as keyof typeof AXIOM.iconBoxes],
              }}>
                <item.icon className="size-6 text-white" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Payslip List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="rounded-2xl overflow-hidden"
        style={{ ...AXIOM.containers.list, borderRadius: '1rem' }}
      >
        <div className="p-6 pb-4 flex items-center justify-between">
          <h3 className="text-white font-bold flex items-center gap-2">
            <Calendar className="size-5 text-blue-400" />
            Pay History
          </h3>
        </div>

        <div className="divide-y" style={{ borderColor: 'rgba(148, 163, 184, 0.1)' }}>
          {payslips?.map((payslip, i) => (
            <motion.div
              key={payslip.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.05 }}
              className="flex items-center gap-6 px-6 py-5 hover:bg-white/5 transition-colors"
            >
              <div className="size-12 rounded-xl flex items-center justify-center" style={{
                background: 'rgba(59, 130, 246, 0.15)',
                border: '1px solid rgba(59, 130, 246, 0.2)',
              }}>
                <FileText className="size-6 text-blue-400" />
              </div>
              
              <div className="flex-1">
                <p className="text-white font-medium">{payslip.period}</p>
                <p className="text-xs text-slate-400 font-mono mt-0.5">Paid: {payslip.date}</p>
              </div>

              <div className="grid grid-cols-3 gap-8 text-right">
                <div>
                  <p className="text-xs text-slate-400 font-mono">Gross</p>
                  <p className="text-sm text-white font-mono">${payslip.gross.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-mono">Deductions</p>
                  <p className="text-sm text-red-400 font-mono">-${payslip.deductions.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-mono">Net Pay</p>
                  <p className="text-sm text-green-400 font-bold font-mono">${payslip.net.toLocaleString()}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button className="p-2 rounded-lg hover:bg-white/10 transition-colors" title="View">
                  <Eye className="size-4 text-blue-400" />
                </button>
                <button className="p-2 rounded-lg hover:bg-white/10 transition-colors" title="Download">
                  <Download className="size-4 text-slate-400" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}